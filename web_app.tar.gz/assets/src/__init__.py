"""Pacman game root source package."""

import os
import sys

_repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_bundled_maze = os.path.join(_repo_root, "mazegenrator")
if os.path.isdir(_bundled_maze) and _bundled_maze not in sys.path:
    sys.path.insert(0, _bundled_maze)
