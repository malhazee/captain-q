"""Collision detection module for entity overlaps and item pick-ups."""

import math
from typing import Any
from src.model.player import Player
from src.model.ghost import Ghost
from src.model.collectible import CollectibleManager
from src.model.math_mission import MathTile


class CollisionDetector:
    """Detects collisions between player, ghosts, and collectible items."""

    GHOST_HITBOX_RADIUS: float = 0.45

    @staticmethod
    def check_ghost_contact(
        player: Player, ghosts: list[Ghost], maze: Any = None
    ) -> Ghost | None:
        """Check if player collides with any active ghost.

        Args:
            player: Player instance.
            ghosts: List of ghost instances.
            maze: Optional maze to check sanctuary immunity.

        Returns:
            The colliding Ghost instance if contact occurred, None otherwise.
        """
        if maze and hasattr(maze, "is_sanctuary"):
            px, py = player.get_position()
            if maze.is_sanctuary(px, py):
                return None
        prx, pry = player.get_render_position()
        for ghost in ghosts:
            if not ghost.is_eaten():
                grx, gry = ghost.get_render_position()
                dist = math.hypot(prx - grx, pry - gry)
                if dist < CollisionDetector.GHOST_HITBOX_RADIUS:
                    return ghost
        return None

    @staticmethod
    def consume_pellet_at_player(
        player: Player, collectibles: CollectibleManager
    ) -> bool:
        """Consume regular pacgum at player position if available."""
        px, py = player.get_position()
        return collectibles.consume_pacgum(px, py)

    @staticmethod
    def consume_super_pellet_at_player(
        player: Player, collectibles: CollectibleManager
    ) -> bool:
        """Consume super pacgum at player position if available."""
        px, py = player.get_position()
        return collectibles.consume_super_pacgum(px, py)

    @staticmethod
    def consume_math_tile_at_player(
        player: Player, collectibles: CollectibleManager
    ) -> MathTile | None:
        """Consume math tile at player position if available."""
        px, py = player.get_position()
        return collectibles.consume_math_tile(px, py)
