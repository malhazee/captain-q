"""Cheat system manager providing debug and inspection commands."""

from src.model.player import Player
from src.model.ghost import Ghost
from src.model.game_state import GameState


class CheatManager:
    """Manages debug cheats: invincibility, level skip, freeze, speed."""

    def __init__(self) -> None:
        """Initialize cheat states."""
        self._ghosts_frozen: bool = False

    def toggle_invincibility(self, player: Player) -> bool:
        """Toggle player invincibility status."""
        new_status = not player.is_invincible()
        player.set_invincible(new_status)
        return new_status

    def toggle_ghost_freeze(self, ghosts: list[Ghost]) -> bool:
        """Freeze or unfreeze all ghosts."""
        self._ghosts_frozen = not self._ghosts_frozen
        for ghost in ghosts:
            ghost.set_frozen(self._ghosts_frozen)
        return self._ghosts_frozen

    def add_extra_life(self, player: Player) -> int:
        """Award one extra life to the player."""
        player.add_life()
        return player.get_lives()

    def toggle_speed(self, player: Player) -> float:
        """Toggle between normal (1.0x) and fast (2.0x) movement speed."""
        new_speed = 2.0 if player.get_speed() == 1.0 else 1.0
        player.set_speed(new_speed)
        return new_speed

    def skip_level(self, state: GameState) -> bool:
        """Advance game immediately to the next level."""
        return state.advance_level()

    def execute_cheat(
        self,
        cheat_id: int,
        player: Player,
        ghosts: list[Ghost],
        state: GameState,
    ) -> str:
        """Dispatch cheat code and return status description message."""
        if cheat_id == 1:
            active = self.toggle_invincibility(player)
            return f"Cheat: Invincibility {'ON' if active else 'OFF'}"
        if cheat_id == 2:
            self.skip_level(state)
            return f"Cheat: Level Skipped -> Level {state.get_level_number()}"
        if cheat_id == 3:
            frozen = self.toggle_ghost_freeze(ghosts)
            return f"Cheat: Ghosts {'FROZEN' if frozen else 'UNFROZEN'}"
        if cheat_id == 4:
            lives = self.add_extra_life(player)
            return f"Cheat: +1 Life -> Total: {lives}"
        if cheat_id == 5:
            spd = self.toggle_speed(player)
            return f"Cheat: Speed -> {spd}x"
        return ""
