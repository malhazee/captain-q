"""Main game controller coordinating Model, View, physics, and input."""

from typing import Any
from src.model.game_state import GameState
from src.view.renderer import Renderer
from src.view.sound_manager import SoundManager
from src.controller.input_handler import InputHandler
from src.controller.collision import CollisionDetector
from src.controller.cheat_manager import CheatManager


class GameController:
    """Coordinates gameplay execution, event handling, and frame rendering."""

    def __init__(
        self,
        state: GameState,
        renderer: Renderer,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Initialize controller subsystems."""
        self._state: GameState = state
        self._renderer: Renderer = renderer
        self._sound: SoundManager = self._init_sound(renderer)
        self._input: InputHandler = InputHandler()
        self._collision: CollisionDetector = CollisionDetector()
        self._cheats: CheatManager = CheatManager()
        self._running: bool = True

    def _init_sound(self, renderer: Renderer) -> SoundManager:
        """Obtain sound manager from renderer or create fallback."""
        if hasattr(renderer, "get_sound_manager"):
            return renderer.get_sound_manager()
        return SoundManager()

    def is_running(self) -> bool:
        """Return whether game execution is active."""
        return self._running

    def exit_game(self) -> None:
        """Terminate the game loop and clean up resources."""
        self._running = False

    def handle_key(self, keycode: int, char: str = "") -> None:
        """Dispatch key input depending on active game state."""
        st = self._state.get_state()
        if st == GameState.STATE_MENU:
            self._handle_menu_key(keycode)
        elif st == GameState.STATE_NAME_ENTRY:
            self._handle_registration_key(keycode, char)
        elif st == GameState.STATE_PLAYING:
            self._handle_playing_key(keycode)
        elif st == GameState.STATE_PAUSED:
            self._handle_paused_key(keycode)
        elif st in (GameState.STATE_GAME_OVER, GameState.STATE_VICTORY):
            self._handle_name_entry_key(keycode, char)
        elif st in (GameState.STATE_HIGHSCORES, GameState.STATE_INSTRUCTIONS):
            if self._input.is_pause_key(keycode) or self._input.is_enter_key(
                keycode
            ):
                self._state.set_state(GameState.STATE_MENU)

    def _handle_menu_key(self, keycode: int) -> None:
        """Handle navigation and selection in main menu."""
        idx = self._state.get_menu_index()
        if keycode in self._input.KEY_UP:
            self._state.set_menu_index((idx - 1) % 4)
        elif keycode in self._input.KEY_DOWN:
            self._state.set_menu_index((idx + 1) % 4)
        elif self._input.is_enter_key(keycode):
            self._execute_menu_choice(idx)

    def _execute_menu_choice(self, index: int) -> None:
        """Execute selected menu action."""
        if index == 0:
            self._state.set_state(GameState.STATE_NAME_ENTRY)
            return
        actions = {
            1: lambda: self._state.set_state(GameState.STATE_HIGHSCORES),
            2: lambda: self._state.set_state(GameState.STATE_INSTRUCTIONS),
            3: self.exit_game,
        }
        action = actions.get(index)
        if action:
            action()

    def _handle_registration_key(
        self, keycode: int, char: str = ""
    ) -> None:
        """Handle student name and section entry before playing."""
        if keycode in self._input.KEY_LEFT or keycode in self._input.KEY_DOWN:
            self._state.cycle_section(-1)
        elif keycode in self._input.KEY_RIGHT or keycode in self._input.KEY_UP:
            self._state.cycle_section(1)
        elif self._input.is_backspace_key(keycode):
            buf = self._state.get_name_buffer()
            self._state.set_name_buffer(buf[:-1])
        elif self._input.is_enter_key(keycode):
            self._state.start_new_game()
            self._sound.play_gameplay_music()
        elif self._input.is_pause_key(keycode):
            self._state.set_state(GameState.STATE_MENU)
        else:
            ch = self._input.get_char_from_input(keycode, char)
            buf = self._state.get_name_buffer()
            if ch and len(buf) < 25:
                self._state.set_name_buffer(buf + ch)

    def _handle_playing_key(self, keycode: int) -> None:
        """Handle directional movement, pause, and cheats during gameplay."""
        level = self._state.get_level()
        if level and level.is_intro_active():
            if self._input.is_enter_key(keycode) or keycode in (32,):
                level.skip_intro()
                return
        if self._input.is_pause_key(keycode):
            self._state.toggle_pause()
            self._sound.pause_music()
            return
        cheat_id = self._input.is_cheat_key(keycode)
        if cheat_id is not None:
            self._apply_cheat_input(cheat_id)
            return
        direction = self._input.get_direction_from_key(keycode)
        if direction.value != 0 and level:
            level.get_player().set_next_direction(direction)

    def _apply_cheat_input(self, cheat_id: int) -> None:
        """Apply requested cheat and update sound effects."""
        level = self._state.get_level()
        if not level:
            return
        self._cheats.execute_cheat(
            cheat_id,
            level.get_player(),
            level.get_ghosts(),
            self._state,
        )
        if cheat_id == 1:
            self._sound.play_invincible(level.get_player().is_invincible())

    def _handle_paused_key(self, keycode: int) -> None:
        """Handle navigation in pause overlay menu."""
        idx = self._state.get_pause_index()
        if self._input.is_pause_key(keycode):
            self._state.toggle_pause()
            self._sound.unpause_music()
        elif keycode in self._input.KEY_UP or keycode in self._input.KEY_DOWN:
            self._state.set_pause_index(1 - idx)
        elif self._input.is_enter_key(keycode):
            if idx == 0:
                self._state.toggle_pause()
                self._sound.unpause_music()
            else:
                self._sound.stop_all()
                self._state.set_state(GameState.STATE_MENU)

    def _handle_name_entry_key(
        self, keycode: int, char: str = ""
    ) -> None:
        """Handle text input when recording highscore nickname."""
        buf = self._state.get_name_buffer()
        if self._input.is_backspace_key(keycode):
            self._state.set_name_buffer(buf[:-1])
        elif self._input.is_enter_key(keycode):
            score_val = self._state.get_score().get_score()
            st_name = self._state.get_analytics_tracker().get_student_name()
            name = buf.strip() if buf.strip() else st_name
            self._state.get_highscore_manager().add_score(name, score_val)
            self._state.set_state(GameState.STATE_HIGHSCORES)
        else:
            ch = self._input.get_char_from_input(keycode, char)
            if ch and len(buf) < 25:
                self._state.set_name_buffer(buf + ch)

    def update(self, delta_time: float) -> None:
        """Advance game physics, timers, collisions, and state checks."""
        if self._state.get_state() != GameState.STATE_PLAYING:
            return
        level = self._state.get_level()
        if not level:
            return
        level.update_floating_texts(delta_time)
        if level.is_intro_active():
            level.update_intro(delta_time)
            return
        if not level.update_time(delta_time):
            self._sound.play_game_over()
            self._state.trigger_game_over()
            return
        self._update_movement_and_items(level, delta_time)
        self._check_ghost_interactions(level)
        self._check_frightened_status(level)
        if level.is_completed():
            self._sound.play_victory()
            self._state.advance_level()

    def _check_frightened_status(self, level: Any) -> None:
        """Stop supergum audio if all ghosts returned to normal."""
        if self._sound.is_supergum_active():
            any_frightened = any(
                g.is_frightened() for g in level.get_ghosts()
            )
            if not any_frightened:
                self._sound.stop_supergum()

    def _update_movement_and_items(
        self, level: Any, delta_time: float
    ) -> None:
        """Move player, collect items, and update ghost positions."""
        player = level.get_player()
        maze = level.get_maze()
        player.move(maze, delta_time)
        self._collect_items(player, level.get_collectibles(), level)
        for ghost in level.get_ghosts():
            ghost.update(
                player.get_position(), player.get_direction(), maze, delta_time
            )

    def _collect_items(
        self, player: Any, collectibles: Any, level: Any
    ) -> None:
        """Consume pacgums, super-pacgums, and math tiles at player tile."""
        if self._collision.consume_pellet_at_player(player, collectibles):
            self._state.get_score().add_pacgum(
                self._state.get_config().get_points_per_pacgum()
            )
        if self._collision.consume_super_pellet_at_player(
            player, collectibles
        ):
            self._state.get_score().add_super_pacgum(
                self._state.get_config().get_points_per_super_pacgum()
            )
            for g in level.get_ghosts():
                g.set_frightened()
            self._sound.play_supergum()
        self._handle_math_tile_collection(player, collectibles, level)

    def _handle_math_tile_collection(
        self, player: Any, collectibles: Any, level: Any
    ) -> None:
        """Collect math tile and spawn floating score feedback."""
        tile = self._collision.consume_math_tile_at_player(
            player, collectibles
        )
        if not tile:
            return
        pts = level.get_mission().record_collection(tile)
        self._state.get_score().add_points(pts)
        self._state.get_analytics_tracker().record_tile_event(
            level.get_level_number(), tile
        )
        px, py = player.get_position()
        c = (50, 255, 80) if pts > 0 else (255, 60, 60)
        prefix = "+" if pts > 0 else ""
        level.add_floating_text(f"{prefix}{pts}", px, py, c)

    def _check_ghost_interactions(self, level: Any) -> None:
        """Check collision with ghosts and apply eating or damage."""
        player = level.get_player()
        hit_ghost = self._collision.check_ghost_contact(
            player, level.get_ghosts(), level.get_maze()
        )
        if not hit_ghost:
            return

        if hit_ghost.is_frightened() or player.is_invincible():
            hit_ghost.eat()
            self._sound.play_eat_ghost()
            self._state.get_score().add_ghost(
                self._state.get_config().get_points_per_ghost()
            )
        else:
            self._handle_player_death(level)

    def _handle_player_death(self, level: Any) -> None:
        """Deduct player life and reset positions or end game."""
        player = level.get_player()
        alive = player.lose_life()
        if alive:
            player.respawn()
            for ghost in level.get_ghosts():
                ghost.respawn()
        else:
            self._sound.play_game_over()
            self._state.trigger_game_over()
