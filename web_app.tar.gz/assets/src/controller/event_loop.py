"""Event loop manager handling Pygame events, clock, and frame cycles."""

from typing import Any
import pygame
from src.model.game_state import GameState
from src.view.renderer import Renderer
from src.controller.game_controller import GameController


class EventLoop:
    """Manages Pygame event pump and continuous 60 FPS frame rendering."""

    TARGET_FRAME_TIME = 1.0 / 60.0
    TARGET_FPS = 60

    def __init__(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Initialize EventLoop with graphics and game components."""
        self._state: GameState = None  # type: ignore
        self._renderer: Renderer = None  # type: ignore
        self._controller: GameController = None  # type: ignore
        self._extract_components(args, kwargs)
        self._clock: pygame.time.Clock = pygame.time.Clock()
        self._running: bool = True

    def _extract_components(
        self, args: tuple[Any, ...], kwargs: dict[str, Any]
    ) -> None:
        """Resolve state, renderer, and controller from positional/kw args."""
        if len(args) >= 6 and isinstance(args[3], GameState):
            self._state = args[3]
            self._renderer = args[4]
            self._controller = args[5]
        elif len(args) >= 3 and isinstance(args[0], GameState):
            self._state = args[0]
            self._renderer = args[1]
            self._controller = args[2]
        else:
            self._state = kwargs.get("state", self._state)
            self._renderer = kwargs.get("renderer", self._renderer)
            self._controller = kwargs.get("controller", self._controller)

    def get_win_ptr(self) -> Any:
        """Return dummy window handle for compatibility."""
        return None

    def _process_events(self) -> None:
        """Poll and dispatch active Pygame events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if self._controller:
                    self._controller.exit_game()
                self._running = False
            elif event.type == pygame.KEYDOWN:
                self._handle_keydown(event)

    def _handle_keydown(self, event: pygame.event.Event) -> None:
        """Dispatch keydown event to controller and display toggles."""
        if event.key == pygame.K_F11:
            try:
                pygame.display.toggle_fullscreen()
            except Exception:
                pass
            return
        if self._controller:
            self._controller.handle_key(
                event.key, getattr(event, "unicode", "")
            )

    def start(self) -> None:
        """Run the main game loop at fixed 60 FPS."""
        while self._running:
            if self._controller and not self._controller.is_running():
                break
            delta_ms = self._clock.tick(self.TARGET_FPS)
            delta = delta_ms / 1000.0
            self._process_events()
            if self._controller:
                self._controller.update(delta)
            if self._renderer and self._state:
                self._renderer.render_frame(self._state, delta)

    async def start_async(self) -> None:
        """Run the main game loop asynchronously for WebAssembly/Pygbag."""
        import asyncio
        while self._running:
            if self._controller and not self._controller.is_running():
                break
            delta_ms = self._clock.tick(self.TARGET_FPS)
            delta = delta_ms / 1000.0
            self._process_events()
            if self._controller:
                self._controller.update(delta)
            if self._renderer and self._state:
                self._renderer.render_frame(self._state, delta)
            await asyncio.sleep(0)

    def stop(self) -> None:
        """Terminate the running event loop."""
        self._running = False
