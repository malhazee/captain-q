# Controller Layer Architecture

The `src/controller/` package bridges the Model and View layers, orchestrating input handling, collision physics, cheat activation, and the Pygame event loop.

## Modules Summary

### 1. `input_handler.py` (`InputHandler`)
- Maps Pygame keycodes to directional movement commands (Arrow keys and WASD).
- Recognizes control triggers (Enter, Escape, Backspace, Pause).
- Maps numeric keys (1-5) to cheat commands.
- Translates keycodes into characters for player name input.

### 2. `collision.py` (`CollisionDetector`)
- Detects player contact with active ghosts using sub-tile Euclidean distance (0.45 tile arcade threshold).
- Tests and consumes regular pacgums and super-pacgums at player coordinates.

### 3. `cheat_manager.py` (`CheatManager`)
- Implements debug and cheat commands required by the specification:
  - `1`: Toggle Invincibility (no lives lost on ghost collision).
  - `2`: Skip Level (advances immediately to next level).
  - `3`: Freeze Ghosts (halts all ghost movement).
  - `4`: Add Extra Life (+1 life).
  - `5`: Increase Speed (2.0x movement speed).

### 4. `game_controller.py` (`GameController`)
- Core game coordinator executing tick updates, collision consequences, life decrements, and level advancement.
- Dispatches state transitions based on menu selection, player death, victory, or pause requests.

### 5. `event_loop.py` (`EventLoop`)
- Manages the Pygame event queue (`pygame.event.get()`).
- Regulates fixed frame rate (60 FPS) with `pygame.time.Clock` and drives frame rendering.
- Handles full-screen toggle via F11 cleanly.
