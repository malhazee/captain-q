"""Controller package coordinating user input, game loop, and updates."""
