"""Keyboard input handler processing keycodes for motion, menus, and cheats."""

import pygame
from src.model.direction import Direction


class InputHandler:
    """Translates keyboard events into game commands and text input."""

    KEY_LEFT = {pygame.K_LEFT, pygame.K_a, 65361, 97, 65, 1588}
    KEY_UP = {pygame.K_UP, pygame.K_w, 65362, 119, 87, 1589}
    KEY_RIGHT = {pygame.K_RIGHT, pygame.K_d, 65363, 100, 68, 1610}
    KEY_DOWN = {pygame.K_DOWN, pygame.K_s, 65364, 115, 83, 1587}
    KEY_PAUSE = {pygame.K_ESCAPE, pygame.K_p, 27, 65307, 112, 80}
    KEY_ENTER = {
        pygame.K_RETURN,
        pygame.K_KP_ENTER,
        13,
        10,
        65293,
        65421,
    }
    KEY_BACKSPACE = {
        pygame.K_BACKSPACE,
        pygame.K_DELETE,
        8,
        127,
        65288,
        65535,
    }
    NAV_LEFT = {pygame.K_LEFT, 65361}
    NAV_RIGHT = {pygame.K_RIGHT, 65363}
    NAV_UP = {pygame.K_UP, 65362}
    NAV_DOWN = {pygame.K_DOWN, 65364}
    NAV_TAB = {pygame.K_TAB, 9}

    X11_LETTER_SCANCODES = {
        24: "Q", 25: "W", 26: "E", 27: "R", 28: "T",
        29: "Y", 30: "U", 31: "I", 32: "O", 33: "P",
        38: "A", 39: "S", 40: "D", 41: "F", 42: "G",
        43: "H", 44: "J", 45: "K", 46: "L",
        52: "Z", 53: "X", 54: "C", 55: "V", 56: "B",
        57: "N", 58: "M",
    }

    ARABIC_TO_LATIN = {
        1590: "Q", 1589: "W", 1579: "E", 1602: "R", 1601: "T",
        1594: "Y", 1593: "U", 1607: "I", 1582: "O", 1581: "P",
        1588: "A", 1587: "S", 1610: "D", 1576: "F", 1604: "G",
        1575: "H", 1571: "H", 1573: "H", 1570: "H", 1578: "J",
        1606: "K", 1605: "L", 1574: "Z", 1569: "X", 1572: "C",
        1585: "V", 65275: "B", 1609: "N", 1577: "M",
    }

    def get_direction_from_key(self, keycode: int) -> Direction:
        """Map keycode to candidate movement direction."""
        if keycode in self.KEY_UP:
            return Direction.NORTH
        if keycode in self.KEY_RIGHT:
            return Direction.EAST
        if keycode in self.KEY_DOWN:
            return Direction.SOUTH
        if keycode in self.KEY_LEFT:
            return Direction.WEST
        return Direction.NONE

    def is_pause_key(self, keycode: int) -> bool:
        """Check if key triggers pause or exit."""
        return keycode in self.KEY_PAUSE

    def is_enter_key(self, keycode: int) -> bool:
        """Check if key is confirmation Enter/Return."""
        return keycode in self.KEY_ENTER

    def is_backspace_key(self, keycode: int) -> bool:
        """Check if key is backspace character."""
        return keycode in self.KEY_BACKSPACE

    def is_nav_left(self, keycode: int) -> bool:
        """Check if key is dedicated left navigation arrow."""
        return keycode in self.NAV_LEFT

    def is_nav_right(self, keycode: int) -> bool:
        """Check if key is dedicated right navigation arrow."""
        return keycode in self.NAV_RIGHT

    def is_nav_up(self, keycode: int) -> bool:
        """Check if key is dedicated up navigation arrow."""
        return keycode in self.NAV_UP

    def is_nav_down(self, keycode: int) -> bool:
        """Check if key is dedicated down navigation arrow."""
        return keycode in self.NAV_DOWN

    def is_tab_key(self, keycode: int) -> bool:
        """Check if key is tab key for cycling."""
        return keycode in self.NAV_TAB

    def is_cheat_key(self, keycode: int) -> int | None:
        """Return cheat ID (1-5) if numeric cheat key pressed."""
        cheat_keys = {
            pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3,
            pygame.K_4: 4, pygame.K_5: 5,
            pygame.K_KP_1: 1, pygame.K_KP_2: 2, pygame.K_KP_3: 3,
            pygame.K_KP_4: 4, pygame.K_KP_5: 5,
            49: 1, 50: 2, 51: 3, 52: 4, 53: 5,
            65457: 1, 65458: 2, 65459: 3, 65460: 4, 65461: 5,
        }
        return cheat_keys.get(keycode)

    def get_char_from_key(self, keycode: int) -> str | None:
        """Convert keycode to printable uppercase character for name entry."""
        if 97 <= keycode <= 122:
            return chr(keycode).upper()
        if 65 <= keycode <= 90 or 48 <= keycode <= 57:
            return chr(keycode)
        if 65456 <= keycode <= 65465:
            return str(keycode - 65456)
        if 1632 <= keycode <= 1641:
            return str(keycode - 1632)
        if keycode in self.ARABIC_TO_LATIN:
            return self.ARABIC_TO_LATIN[keycode]
        if keycode in (32, 95):
            return " " if keycode == 32 else "_"
        if keycode in (45, 65453):
            return "-"
        if keycode in self.X11_LETTER_SCANCODES:
            return self.X11_LETTER_SCANCODES[keycode]
        return None

    def get_char_from_input(
        self, keycode: int, char: str = ""
    ) -> str | None:
        """Extract printable character from unicode text or keycode."""
        if char and char.isprintable():
            if (
                char.isalnum()
                or "\u0600" <= char <= "\u06FF"
                or char in (" ", "-", "_")
            ):
                return char
        return self.get_char_from_key(keycode)
