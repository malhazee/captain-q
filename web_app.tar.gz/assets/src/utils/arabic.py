"""Arabic text reshaping and font utilities for Pygame."""

import pygame

_FORMS: dict[str, tuple[int, int, int, int]] = {
    '\u0621': (0xFE80, 0xFE80, 0xFE80, 0xFE80),
    '\u0622': (0xFE81, 0xFE82, 0xFE81, 0xFE82),
    '\u0623': (0xFE83, 0xFE84, 0xFE83, 0xFE84),
    '\u0624': (0xFE85, 0xFE86, 0xFE85, 0xFE86),
    '\u0625': (0xFE87, 0xFE88, 0xFE87, 0xFE88),
    '\u0626': (0xFE89, 0xFE8A, 0xFE8B, 0xFE8C),
    '\u0627': (0xFE8D, 0xFE8E, 0xFE8D, 0xFE8E),
    '\u0628': (0xFE8F, 0xFE90, 0xFE91, 0xFE92),
    '\u0629': (0xFE93, 0xFE94, 0xFE93, 0xFE94),
    '\u062A': (0xFE95, 0xFE96, 0xFE97, 0xFE98),
    '\u062B': (0xFE99, 0xFE9A, 0xFE9B, 0xFE9C),
    '\u062C': (0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0),
    '\u062D': (0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4),
    '\u062E': (0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8),
    '\u062F': (0xFEA9, 0xFEAA, 0xFEA9, 0xFEAA),
    '\u0630': (0xFEAB, 0xFEAC, 0xFEAB, 0xFEAC),
    '\u0631': (0xFEAD, 0xFEAE, 0xFEAD, 0xFEAE),
    '\u0632': (0xFEAF, 0xFEB0, 0xFEAF, 0xFEB0),
    '\u0633': (0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4),
    '\u0634': (0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8),
    '\u0635': (0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC),
    '\u0636': (0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0),
    '\u0637': (0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4),
    '\u0638': (0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8),
    '\u0639': (0xFEC9, 0xFECA, 0xFECB, 0xFECC),
    '\u063A': (0xFECD, 0xFECE, 0xFECF, 0xFED0),
    '\u0641': (0xFED1, 0xFED2, 0xFED3, 0xFED4),
    '\u0642': (0xFED5, 0xFED6, 0xFED7, 0xFED8),
    '\u0643': (0xFED9, 0xFEDA, 0xFEDB, 0xFEDC),
    '\u0644': (0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0),
    '\u0645': (0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4),
    '\u0646': (0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8),
    '\u0647': (0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC),
    '\u0648': (0xFEED, 0xFEEE, 0xFEED, 0xFEEE),
    '\u0649': (0xFEEF, 0xFEF0, 0xFEEF, 0xFEF0),
    '\u064A': (0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4),
}

_NON_FWD = set(
    '\u0621\u0622\u0623\u0624\u0625\u0627\u0629\u062F'
    '\u0630\u0631\u0632\u0648\u0649\uFEF5\uFEF6\uFEF7'
    '\uFEF8\uFEF9\uFEFA\uFEFB\uFEFC'
)

_LIG_CHARS = set(
    '\uFEF5\uFEF6\uFEF7\uFEF8\uFEF9\uFEFA\uFEFB\uFEFC'
)


def is_arabic(text: str) -> bool:
    """Check if string contains Arabic unicode characters."""
    return any(
        '\u0600' <= c <= '\u06FF'
        or '\uFB50' <= c <= '\uFDFF'
        or '\uFE70' <= c <= '\uFEFF'
        for c in text
    )


def _replace_ligatures(text: str) -> str:
    """Replace common Arabic ligatures like Lam-Alef."""
    return (
        text.replace('\u0644\u0622', '\uFEF5')
        .replace('\u0644\u0623', '\uFEF7')
        .replace('\u0644\u0625', '\uFEF9')
        .replace('\u0644\u0627', '\uFEFB')
    )


def _get_glyph_form(text: str, i: int, ch: str) -> str:
    """Determine contextual glyph shape (isolated, final, initial, medial)."""
    if ch not in _FORMS:
        return ch
    prev_ok = (
        i > 0
        and (text[i - 1] in _FORMS or text[i - 1] in _LIG_CHARS)
        and text[i - 1] not in _NON_FWD
    )
    next_ok = (
        i < len(text) - 1
        and text[i + 1] in _FORMS
        and ch not in _NON_FWD
    )
    idx = (2 if next_ok else 0) + (1 if prev_ok else 0)
    return chr(_FORMS[ch][idx])


def reshape_arabic(text: str) -> str:
    """Reshape Arabic text to connected presentation forms."""
    cleaned = _replace_ligatures(text)
    return ''.join(
        _get_glyph_form(cleaned, i, c) for i, c in enumerate(cleaned)
    )


def format_arabic(text: str) -> str:
    """Format Arabic or mixed text for proper RTL display in Pygame."""
    if not is_arabic(text):
        return text
    reshaped = reshape_arabic(text)
    words = reshaped.split(' ')
    out = []
    for w in words:
        if is_arabic(w):
            out.append(w[::-1])
        else:
            out.append(w)
    return ' '.join(reversed(out))


def get_ui_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Return a system font capable of rendering Arabic and English glyphs."""
    if not pygame.font.get_init():
        pygame.font.init()
    family = 'tahoma,segoeui,arial,dejavusans,notosansarabic'
    return pygame.font.SysFont(family, size, bold=bold)
