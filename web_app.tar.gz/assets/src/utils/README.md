# Utilities Layer Architecture

The `src/utils/` package provides reusable parsing and algorithmic helpers.

## Modules Summary

### 1. `json_parser.py`
- Implements robust JSON deserialization supporting full-line comments starting with `#`.
- Uses safe context managers (`with open(...)`).
- Intercepts file missing, permission, and syntax errors without crashing or dumping Python tracebacks.

### 2. `pathfinding.py`
- Implements Breadth-First Search (BFS) pathfinding through the braided maze grid.
- Computes shortest coordinate sequences between arbitrary open corridor points.

