"""Utility package containing JSON parsing and pathfinding algorithms."""
