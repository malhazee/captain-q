"""Pathfinding utilities including BFS shortest path computation in mazes."""

from collections import deque
from src.model.direction import Direction
from src.model.maze import Maze


def find_shortest_path_bfs(
    maze: Maze, start: tuple[int, int], goal: tuple[int, int]
) -> list[tuple[int, int]]:
    """Compute shortest path between start and goal using BFS."""
    if start == goal:
        return [start]
    if not maze.is_corridor(*start) or not maze.is_corridor(*goal):
        return []
    parent: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    queue: deque[tuple[int, int]] = deque([start])
    _run_bfs(maze, goal, parent, queue)
    return _reconstruct_path(parent, goal) if goal in parent else []


def _run_bfs(
    maze: Maze,
    goal: tuple[int, int],
    parent: dict[tuple[int, int], tuple[int, int] | None],
    queue: deque[tuple[int, int]],
) -> None:
    """Expand queue until goal reached or queue exhausted."""
    while queue:
        cx, cy = queue.popleft()
        if (cx, cy) == goal:
            break
        _explore_neighbors(maze, (cx, cy), parent, queue)


def _explore_neighbors(
    maze: Maze,
    curr: tuple[int, int],
    parent: dict[tuple[int, int], tuple[int, int] | None],
    queue: deque[tuple[int, int]],
) -> None:
    """Explore adjacent cells for valid unobstructed corridor steps."""
    cx, cy = curr
    directions = [
        Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST
    ]
    chk = getattr(maze, "can_ghost_move", maze.can_move)
    for d in directions:
        if chk(cx, cy, d):
            dx, dy = d.delta()
            nxt = (cx + dx, cy + dy)
            if nxt not in parent:
                parent[nxt] = curr
                queue.append(nxt)


def _reconstruct_path(
    parent: dict[tuple[int, int], tuple[int, int] | None],
    goal: tuple[int, int],
) -> list[tuple[int, int]]:
    """Trace back path from goal to origin using parent mapping."""
    path: list[tuple[int, int]] = []
    curr: tuple[int, int] | None = goal
    while curr is not None:
        path.append(curr)
        curr = parent[curr]
    path.reverse()
    return path
