"""HTML and CSV diagnostic report generator for Teacher Dashboard."""

import glob
import json
import os
from typing import Any


class ReportGenerator:
    """Compiles session data into an interactive Arabic Teacher Dashboard."""

    def __init__(self, reports_dir: str = "reports") -> None:
        """Initialize generator with source reports directory."""
        self._reports_dir: str = reports_dir
        self._sessions_dir: str = os.path.join(reports_dir, "sessions")

    def load_all_sessions(self) -> list[dict[str, Any]]:
        """Load and parse all saved student session JSON records."""
        pattern = os.path.join(self._sessions_dir, "*.json")
        sessions: list[dict[str, Any]] = []
        for path in sorted(glob.glob(pattern)):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    sessions.append(json.load(f))
            except Exception:
                continue
        return sessions

    def _compute_metrics(
        self, sessions: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Compute aggregate metrics from student session records."""
        if not sessions:
            return {
                "total": 0, "avg_score": 0, "avg_acc": 0.0, "miscs": {}
            }
        tot = len(sessions)
        avg_sc = sum(s.get("final_score", 0) for s in sessions) // tot
        avg_acc = round(
            sum(s.get("accuracy_percentage", 0.0) for s in sessions) / tot, 1
        )
        misc_counts: dict[str, int] = {}
        for s in sessions:
            for m in s.get("misconceptions", []):
                misc_counts[m] = misc_counts.get(m, 0) + 1
        sorted_m = dict(sorted(misc_counts.items(), key=lambda x: -x[1]))
        return {
            "total": tot, "avg_score": avg_sc, "avg_acc": avg_acc,
            "miscs": sorted_m,
        }

    def _acc_color(self, acc: float) -> str:
        """Determine hex color code based on accuracy percentage."""
        if acc >= 80:
            return "#00e676"
        if acc >= 60:
            return "#ffab00"
        return "#ff5252"

    def _format_student_row(self, s: dict[str, Any]) -> str:
        """Format a single student session dictionary into an HTML row."""
        acc = s.get("accuracy_percentage", 0.0)
        clr = self._acc_color(acc)
        misc_tags = "".join(
            f'<span class="badge badge-warn">{m}</span>'
            for m in s.get("misconceptions", [])
        ) or '<span class="badge badge-ok">إتقان كامل</span>'
        return (
            f"<tr><td><b>{s.get('student_name', '')}</b></td>"
            f"<td>{s.get('section', '')}</td>"
            f"<td>{s.get('final_score', 0)}</td>"
            f"<td>{s.get('levels_cleared', 0)}/6</td>"
            f"<td style='color:{clr};font-weight:bold;'>{acc}%</td>"
            f"<td>{misc_tags}</td><td>{s.get('date', '')}</td></tr>"
        )

    def _generate_student_rows(self, sessions: list[dict[str, Any]]) -> str:
        """Generate HTML table rows for individual student records."""
        if not sessions:
            return "<tr><td colspan='7'>لا توجد سجلات بعد.</td></tr>"
        return "\n".join(self._format_student_row(s) for s in sessions)

    def _generate_misc_bars(self, miscs: dict[str, int], total: int) -> str:
        """Generate HTML progress bars for most frequent misconceptions."""
        if not miscs or total == 0:
            return "<p>لم يتم رصد أي فجوات مفاهيمية متكررة حتى الآن.</p>"
        bars = []
        for m, count in list(miscs.items())[:6]:
            pct = round((count / total) * 100, 1)
            item = (
                f'<div class="misc-item">'
                f'<div class="misc-header"><span>{m}</span>'
                f'<span>{count} طلاب ({pct}%)</span></div>'
                f'<div class="bar-bg">'
                f'<div class="bar-fill" style="width:{pct}%"></div>'
                f'</div></div>'
            )
            bars.append(item)
        return "\n".join(bars)

    def _load_template(self) -> str:
        """Load the HTML template from disk."""
        cur_dir = os.path.dirname(os.path.abspath(__file__))
        tmpl_path = os.path.join(cur_dir, "dashboard_template.html")
        with open(tmpl_path, "r", encoding="utf-8") as f:
            return f.read()

    def generate_html_dashboard(self) -> str:
        """Compile complete HTML dashboard file and return absolute path."""
        sessions = self.load_all_sessions()
        m = self._compute_metrics(sessions)
        rows = self._generate_student_rows(sessions)
        bars = self._generate_misc_bars(m["miscs"], m["total"])
        tmpl = self._load_template()
        html = tmpl.replace("{total}", str(m["total"]))
        html = html.replace("{avg_score}", str(m["avg_score"]))
        html = html.replace("{avg_acc}", str(m["avg_acc"]))
        html = html.replace("{miscs_count}", str(len(m["miscs"])))
        html = html.replace("{bars}", bars)
        html = html.replace("{rows}", rows)
        os.makedirs(self._reports_dir, exist_ok=True)
        out_path = os.path.join(self._reports_dir, "teacher_dashboard.html")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)
        return out_path
