"""JSON parsing utility supporting comments starting with hash (#)."""

import json
from typing import Any


def strip_comments_from_text(raw_text: str) -> str:
    """Strip comment lines starting with hash (#) from JSON content.

    Args:
        raw_text: The raw JSON string containing comment lines.

    Returns:
        The cleaned JSON string with comment lines removed.
    """
    clean_lines: list[str] = []
    for line in raw_text.splitlines():
        if not line.strip().startswith("#"):
            clean_lines.append(line)
    return "\n".join(clean_lines)


def read_file_safe(filepath: str) -> str | None:
    """Read file content safely without throwing uncaught exceptions.

    Args:
        filepath: Path to the target file.

    Returns:
        String content if successful, None if reading failed.
    """
    try:
        with open(filepath, "r", encoding="utf-8") as file_handle:
            return file_handle.read()
    except (FileNotFoundError, PermissionError, OSError) as read_error:
        print(f"Error accessing file '{filepath}': {read_error}")
        return None


def parse_json_with_comments(filepath: str) -> dict[str, Any]:
    """Read and parse a JSON file with comment support.

    Args:
        filepath: Path to the JSON configuration file.

    Returns:
        Parsed dictionary, or empty dict if invalid.
    """
    content = read_file_safe(filepath)
    if content is None:
        return {}
    cleaned = strip_comments_from_text(content)
    try:
        data = json.loads(cleaned)
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError as decode_error:
        print(f"Error parsing JSON in '{filepath}': {decode_error}")
        return {}
