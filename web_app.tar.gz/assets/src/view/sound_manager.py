"""Sound manager handling background music, sound effects, and audio states."""

import os
import pygame


class SoundManager:
    """Manages audio playback, track cycling, and sound effects."""

    def __init__(self, assets_root: str = "pacman-assets") -> None:
        """Initialize audio subsystem and preload game sound effects.

        Args:
            assets_root: Directory containing sound files.
        """
        self._assets_root: str = assets_root
        self._available: bool = False
        self._opening_played: bool = False
        self._current_track_idx: int = 0
        self._sounds: dict[str, pygame.mixer.Sound] = {}
        self._channels: dict[str, pygame.mixer.Channel | None] = {}
        self._in_supergum: bool = False
        self._in_invincible: bool = False
        self._init_mixer()
        self._load_sound_effects()

    def _init_mixer(self) -> None:
        """Initialize Pygame mixer safely with error handling."""
        import sys
        if sys.platform == "emscripten" or os.environ.get("DISABLE_AUDIO") == "1":
            self._available = False
            return
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(
                    frequency=44100, size=-16, channels=2, buffer=512
                )
            self._available = True
        except Exception:
            self._available = False

    def is_available(self) -> bool:
        """Return whether audio playback is supported and active."""
        return self._available

    def _resolve_path(self, filename: str) -> str | None:
        """Find audio file path in assets directory."""
        path = os.path.join(self._assets_root, filename)
        if os.path.exists(path):
            return path
        return None

    def _load_single_sound(self, name: str, filename: str) -> None:
        """Load an individual sound effect file into cache."""
        path = self._resolve_path(filename)
        if not path or not self._available:
            return
        try:
            snd = pygame.mixer.Sound(path)
            snd.set_volume(0.8)
            self._sounds[name] = snd
        except Exception:
            pass

    def _load_sound_effects(self) -> None:
        """Preload all short audio and effect files."""
        effects = [
            ("opening", "opening.mp3"),
            ("eat_ghost", "eat_gosts.mp3"),
            ("supergum", "eat_supergum.mp3"),
            ("invincible", "invenceble_mode.mp3"),
            ("victory", "vectory.mp3"),
        ]
        for name, filename in effects:
            self._load_single_sound(name, filename)

    def play_opening(self) -> None:
        """Play opening intro fanfare once on launch."""
        if not self._available or self._opening_played:
            return
        snd = self._sounds.get("opening")
        if snd:
            try:
                snd.play()
                self._opening_played = True
            except Exception:
                pass

    def _get_current_gameplay_path(self) -> str | None:
        """Return file path for active in-game music track."""
        tracks = ["in_game_1.mp3", "in_game_2.mp3"]
        track_name = tracks[self._current_track_idx % 2]
        return self._resolve_path(track_name)

    def play_gameplay_music(self) -> None:
        """Start streaming active in-game gameplay music."""
        if not self._available or self._in_supergum or self._in_invincible:
            return
        path = self._get_current_gameplay_path()
        if not path:
            return
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0.6)
            pygame.mixer.music.play()
        except Exception:
            pass

    def advance_gameplay_track(self) -> None:
        """Cycle to the next in-game track and begin playback."""
        self._current_track_idx = (self._current_track_idx + 1) % 2
        self.play_gameplay_music()

    def update(self, is_playing: bool) -> None:
        """Check background music status and cycle tracks on completion."""
        if not self._available or not is_playing:
            return
        if (
            self._in_supergum
            or self._in_invincible
            or self._is_victory_active()
        ):
            return
        try:
            if not pygame.mixer.music.get_busy():
                self.advance_gameplay_track()
        except Exception:
            pass

    def _is_victory_active(self) -> bool:
        """Return whether victory fanfare is still playing."""
        ch = self._channels.get("victory")
        if ch is not None:
            try:
                return bool(ch.get_busy())
            except Exception:
                return False
        return False

    def is_supergum_active(self) -> bool:
        """Return True if supergum chase audio is currently playing."""
        return self._in_supergum

    def play_supergum(self) -> None:
        """Play super-pacgum chase sound and suspend gameplay music."""
        if not self._available:
            return
        self._in_supergum = True
        self._pause_bgm()
        snd = self._sounds.get("supergum")
        if snd:
            try:
                ch = snd.play()
                self._channels["supergum"] = ch
            except Exception:
                pass

    def stop_supergum(self) -> None:
        """Stop super-pacgum siren and resume gameplay music."""
        if not self._in_supergum:
            return
        self._in_supergum = False
        ch = self._channels.get("supergum")
        if ch:
            try:
                ch.stop()
            except Exception:
                pass
        self._resume_bgm()

    def play_invincible(self, active: bool) -> None:
        """Toggle invincible mode theme and manage BGM state."""
        if not self._available:
            return
        snd = self._sounds.get("invincible")
        if active:
            self._in_invincible = True
            self._pause_bgm()
            if snd:
                try:
                    self._channels["invincible"] = snd.play(loops=-1)
                except Exception:
                    pass
        else:
            self._in_invincible = False
            ch = self._channels.get("invincible")
            if ch:
                try:
                    ch.stop()
                except Exception:
                    pass
            self._resume_bgm()

    def play_eat_ghost(self) -> None:
        """Play sound effect for consuming an edible ghost."""
        if not self._available:
            return
        snd = self._sounds.get("eat_ghost")
        if snd:
            try:
                snd.play()
            except Exception:
                pass

    def play_victory(self) -> None:
        """Play victory celebration fanfare."""
        if not self._available:
            return
        self._pause_bgm()
        snd = self._sounds.get("victory")
        if snd:
            try:
                self._channels["victory"] = snd.play()
            except Exception:
                pass

    def play_game_over(self) -> None:
        """Stop game sounds and stream defeat music."""
        if not self._available:
            return
        self.stop_all()
        path = self._resolve_path("lose_game.mp3")
        if path:
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.set_volume(0.7)
                pygame.mixer.music.play()
            except Exception:
                pass

    def _pause_bgm(self) -> None:
        """Safely pause active background music."""
        try:
            pygame.mixer.music.pause()
        except Exception:
            pass

    def _resume_bgm(self) -> None:
        """Safely resume paused background music if not overridden."""
        if self._in_supergum or self._in_invincible:
            return
        try:
            pygame.mixer.music.unpause()
            if not pygame.mixer.music.get_busy():
                self.play_gameplay_music()
        except Exception:
            pass

    def pause_music(self) -> None:
        """Pause all music and active sound channels."""
        self._pause_bgm()

    def unpause_music(self) -> None:
        """Resume paused music and sound channels."""
        self._resume_bgm()

    def stop_all(self) -> None:
        """Halt all active sound effects and background music."""
        if not self._available:
            return
        try:
            pygame.mixer.music.stop()
            for ch in self._channels.values():
                if ch:
                    ch.stop()
        except Exception:
            pass

    def cleanup(self) -> None:
        """Release audio resources and stop mixer playback."""
        self.stop_all()
        self._sounds.clear()
        self._channels.clear()
