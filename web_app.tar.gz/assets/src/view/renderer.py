"""Composite renderer coordinating sprite, maze, HUD, and menu drawing."""

import os
from typing import Any
import pygame
from src.model.game_state import GameState
from src.model.player import Player
from src.model.ghost import Ghost
from src.view.colors import Colors
from src.view.sprite_manager import SpriteManager
from src.view.sound_manager import SoundManager
from src.view.animation import AnimationManager
from src.view.maze_renderer import MazeRenderer
from src.view.hud_renderer import HudRenderer
from src.view.menu_renderer import MenuRenderer


class Renderer:
    """Primary View facade directing Pygame rendering based on GameState."""

    SPRITE_SIZE: int = 48

    def __init__(
        self,
        target_surface: Any = None,
        *args: Any,
        assets_root: str = "pacman-assets",
        **kwargs: Any,
    ) -> None:
        """Initialize renderer subsystems."""
        is_surf = isinstance(target_surface, pygame.Surface)
        self._surface: pygame.Surface | None = (
            target_surface if is_surf else None
        )
        self._sprites = SpriteManager(
            assets_root, sprite_size=self.SPRITE_SIZE
        )
        self._sound_manager = SoundManager(assets_root)
        self._anim = AnimationManager()
        self._maze_renderer = MazeRenderer(self._sprites, self._surface)
        self._hud_renderer = HudRenderer(self._surface)
        self._menu_renderer = MenuRenderer(self._surface)
        self._bg_image: pygame.Surface | None = None
        self._cached_bg: pygame.Surface | None = None
        self._load_backdrop(assets_root)

    def _load_backdrop(self, assets_root: str) -> None:
        """Load ambient gameplay backdrop image safely."""
        path = os.path.join(assets_root, "gameplay_backdrop.png")
        if not os.path.exists(path):
            return
        try:
            surf = pygame.image.load(path)
            if pygame.display.get_surface() is not None:
                surf = surf.convert()
            self._bg_image = surf
        except Exception:
            self._bg_image = None

    def get_sprites(self) -> SpriteManager:
        """Return the SpriteManager instance."""
        return self._sprites

    def get_sound_manager(self) -> SoundManager:
        """Return the SoundManager instance."""
        return self._sound_manager

    def set_surface(self, target_surface: pygame.Surface | None) -> None:
        """Update window surface and cascade to subsystems."""
        self._surface = target_surface
        self._maze_renderer.set_surface(target_surface)
        self._hud_renderer.set_surface(target_surface)
        self._menu_renderer.set_surface(target_surface)

    def set_window(self, win_ptr: Any) -> None:
        """Compatibility shim for window/surface updates."""
        if isinstance(win_ptr, pygame.Surface):
            self.set_surface(win_ptr)

    def clear(self) -> None:
        """Clear the window surface with dark navy background."""
        if self._surface:
            self._surface.fill(Colors.DARK_NAVY)

    def render_frame(self, state: GameState, delta_time: float) -> None:
        """Render complete frame based on active game state."""
        self._anim.update(delta_time)
        self.clear()
        current_state = state.get_state()
        self._sound_manager.update(current_state == GameState.STATE_PLAYING)

        dispatch = {
            GameState.STATE_MENU: self._render_menu_state,
            GameState.STATE_NAME_ENTRY: self._render_registration_state,
            GameState.STATE_PLAYING: self._render_playing_state,
            GameState.STATE_PAUSED: self._render_paused_state,
            GameState.STATE_GAME_OVER: self._render_game_over_state,
            GameState.STATE_VICTORY: self._render_victory_state,
            GameState.STATE_HIGHSCORES: self._render_highscores_state,
            GameState.STATE_INSTRUCTIONS: self._render_instructions_state,
        }
        handler = dispatch.get(current_state, self._render_menu_state)
        handler(state)
        self._sync()

    def _render_menu_state(self, state: GameState) -> None:
        """Render the main title menu."""
        self._sound_manager.play_opening()
        self._menu_renderer.render_main_menu(
            state.get_menu_index(), self._surface
        )

    def _render_registration_state(self, state: GameState) -> None:
        """Render student registration screen."""
        self._sound_manager.play_opening()
        self._menu_renderer.render_registration(state, self._surface)

    def _render_gameplay_background(self) -> None:
        """Render cached ambient arcade background if available."""
        if not self._surface or not self._bg_image:
            return
        w, h = self._surface.get_size()
        if self._cached_bg is None or self._cached_bg.get_size() != (w, h):
            try:
                self._cached_bg = pygame.transform.smoothscale(
                    self._bg_image, (w, h)
                )
            except Exception:
                self._cached_bg = self._bg_image
        if self._cached_bg:
            self._surface.blit(self._cached_bg, (0, 0))

    def _render_playing_state(self, state: GameState) -> None:
        """Render active maze, player, ghosts, and HUD."""
        level = state.get_level()
        if not level or not self._surface:
            return
        self._render_gameplay_background()
        maze = level.get_maze()
        win_w, win_h = self._surface.get_width(), self._surface.get_height()
        self._maze_renderer.calculate_offsets(maze, win_w, win_h)
        maze_w = maze.get_width() * self._maze_renderer.get_tile_size()
        self._maze_renderer.render_maze(maze, self._surface)
        self._maze_renderer.render_collectibles(
            level.get_collectibles(), self._surface
        )
        self._render_player(level.get_player())
        self._render_ghosts(level.get_ghosts())
        self._maze_renderer.render_floating_texts(
            level.get_floating_texts(), self._surface
        )
        self._hud_renderer.render_hud(state, maze_w, win_w, self._surface)
        if level.is_intro_active():
            self._hud_renderer.render_mission_intro(level, self._surface)

    def _render_paused_state(self, state: GameState) -> None:
        """Render underlying game scene overlayed with pause menu."""
        self._render_playing_state(state)
        self._menu_renderer.render_pause_menu(
            state.get_pause_index(), self._surface
        )

    def _render_game_over_state(self, state: GameState) -> None:
        """Render game over screen with score and name prompt."""
        self._render_gameplay_background()
        diag = state.get_analytics_tracker().get_session_summary()
        self._menu_renderer.render_game_over(
            state.get_score().get_score(),
            state.get_name_buffer(),
            self._surface,
            diag,
        )

    def _render_victory_state(self, state: GameState) -> None:
        """Render victory screen with score and name prompt."""
        self._render_gameplay_background()
        diag = state.get_analytics_tracker().get_session_summary()
        self._menu_renderer.render_victory(
            state.get_score().get_score(),
            state.get_name_buffer(),
            self._surface,
            diag,
        )

    def _render_highscores_state(self, state: GameState) -> None:
        """Render highscore leaderboard."""
        self._render_gameplay_background()
        self._menu_renderer.render_highscores(state, self._surface)

    def _render_instructions_state(self, state: GameState) -> None:
        """Render instructions screen."""
        self._render_gameplay_background()
        self._menu_renderer.render_instructions(self._surface)

    def _render_player(self, player: Player) -> None:
        """Render Pacman sprite with directional mouth animation."""
        if not self._surface:
            return
        rx, ry = player.get_render_position()
        ox = self._maze_renderer.get_offset_x()
        oy = self._maze_renderer.get_offset_y()
        ts = self._maze_renderer.get_tile_size()
        px = int(ox + rx * ts)
        py = int(oy + ry * ts)
        off = (ts - self.SPRITE_SIZE) // 2
        sprite = self._sprites.get_pacman_sprite(
            player.get_facing_direction(), self._anim.get_frame()
        )
        if sprite:
            self._surface.blit(sprite, (px + off, py + off))
        else:
            self._maze_renderer._draw_rect(
                px + off, py + off,
                self.SPRITE_SIZE, self.SPRITE_SIZE,
                Colors.YELLOW, self._surface,
            )
        self._render_invincible_aura(player, px + off, py + off)

    def _render_invincible_aura(
        self, player: Player, px: int, py: int
    ) -> None:
        """Render a golden protective aura circle when invincible."""
        if not self._surface or not player.is_invincible():
            return
        center = (px + self.SPRITE_SIZE // 2, py + self.SPRITE_SIZE // 2)
        pygame.draw.circle(
            self._surface, Colors.WHITE, center, self.SPRITE_SIZE // 2 + 3, 2
        )

    def _render_ghosts(self, ghosts: list[Ghost]) -> None:
        """Render all active ghosts using normal or frightened sprites."""
        for ghost in ghosts:
            if not ghost.is_eaten():
                self._render_single_ghost(ghost)

    def _render_single_ghost(self, ghost: Ghost) -> None:
        """Draw a single ghost sprite or fallback colored block."""
        if not self._surface:
            return
        rx, ry = ghost.get_render_position()
        ox = self._maze_renderer.get_offset_x()
        oy = self._maze_renderer.get_offset_y()
        ts = self._maze_renderer.get_tile_size()
        px = int(ox + rx * ts)
        py = int(oy + ry * ts)
        off = (ts - self.SPRITE_SIZE) // 2
        sprite = self._sprites.get_ghost_sprite(
            ghost.get_name(), ghost.is_frightened()
        )
        if sprite:
            self._surface.blit(sprite, (px + off, py + off))
        else:
            self._draw_ghost_fallback(ghost, px, py)

    def _draw_ghost_fallback(self, ghost: Ghost, px: int, py: int) -> None:
        """Draw fallback rectangle if sprite is not present."""
        colors_map = {
            "blinky": Colors.BLINKY_RED,
            "pinky": Colors.PINKY_PINK,
            "inky": Colors.INKY_CYAN,
            "clyde": Colors.CLYDE_ORANGE,
        }
        color = (
            Colors.FRIGHTENED_BLUE
            if ghost.is_frightened()
            else colors_map.get(ghost.get_name(), Colors.WHITE)
        )
        ts = self._maze_renderer.get_tile_size()
        off = (ts - self.SPRITE_SIZE) // 2
        self._maze_renderer._draw_rect(
            px + off, py + off,
            self.SPRITE_SIZE, self.SPRITE_SIZE,
            color, self._surface,
        )

    def _sync(self) -> None:
        """Flip Pygame display buffers."""
        if pygame.display.get_init():
            try:
                pygame.display.flip()
            except Exception:
                pass

    def cleanup(self) -> None:
        """Release sprite, maze, hud, sound, and menu resources."""
        self._sound_manager.cleanup()
        self._sprites.cleanup()
        self._maze_renderer.cleanup()
        self._hud_renderer.cleanup()
        self._menu_renderer.cleanup()
        self._bg_image = None
        self._cached_bg = None
