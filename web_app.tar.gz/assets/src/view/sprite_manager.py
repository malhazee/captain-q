"""Sprite manager loading, caching, and releasing Pygame image assets."""

import os
from typing import Any
import pygame
from src.model.direction import Direction


class SpriteManager:
    """Manages loading, retrieving, and caching Pygame graphic sprites."""

    DEFAULT_SPRITE_SIZE = 48

    def __init__(
        self,
        assets_root: str = "pacman-assets",
        sprite_size: int = DEFAULT_SPRITE_SIZE,
    ) -> None:
        """Initialize SpriteManager and preload all game sprites.

        Args:
            assets_root: Directory containing image asset folders.
            sprite_size: Target dimension in pixels for character sprites.
        """
        self._assets_root: str = assets_root
        self._sprite_size: int = sprite_size
        self._sprites: dict[str, pygame.Surface] = {}
        self._load_all_sprites()

    def _load_all_sprites(self) -> None:
        """Load character, ghost, and item sprites from disk."""
        self._load_pacman_sprites()
        self._load_ghost_sprites()
        self._load_item_sprites()

    def _load_single_png(
        self,
        key: str,
        relative_path: str,
        target_size: tuple[int, int] | None = None,
    ) -> None:
        """Load a single PNG asset safely into cache."""
        full_path = os.path.join(self._assets_root, relative_path)
        if not os.path.exists(full_path):
            return
        try:
            surf = pygame.image.load(full_path)
            if pygame.display.get_surface() is not None:
                surf = surf.convert_alpha()
            if target_size is not None:
                if (surf.get_width(), surf.get_height()) != target_size:
                    surf = pygame.transform.smoothscale(surf, target_size)
            self._sprites[key] = surf
        except Exception as load_err:
            print(f"Warning: Could not load sprite '{full_path}': {load_err}")

    def _load_pacman_sprites(self) -> None:
        """Preload all 12 Pacman directional animation frames."""
        dirs = [
            ("right", Direction.EAST),
            ("left", Direction.WEST),
            ("up", Direction.NORTH),
            ("down", Direction.SOUTH),
        ]
        tgt = (self._sprite_size, self._sprite_size)
        for folder_name, direction in dirs:
            for frame_idx in range(3):
                key = f"pacman_{direction.value}_{frame_idx}"
                rel_path = os.path.join(
                    f"pacman-{folder_name}", f"{frame_idx + 1}.png"
                )
                self._load_single_png(key, rel_path, tgt)

    def _load_ghost_sprites(self) -> None:
        """Preload the 4 main ghost sprites and the frightened ghost."""
        ghost_names = ["blinky", "pinky", "inky", "clyde", "blue_ghost"]
        tgt = (self._sprite_size, self._sprite_size)
        for name in ghost_names:
            rel_path = os.path.join("ghosts", f"{name}.png")
            self._load_single_png(name, rel_path, tgt)

    def _load_item_sprites(self) -> None:
        """Preload pacgum dot, super dot, and bonus item sprites."""
        items = [
            "dot", "super_dot", "wall_block", "floor_tile",
            "apple", "strawberry",
        ]
        for item in items:
            rel_path = os.path.join("other", f"{item}.png")
            self._load_single_png(item, rel_path)
        self._load_single_png("math_center_emblem", "math_center_emblem.png")

    def get_pacman_sprite(
        self, direction: Direction, frame: int
    ) -> Any | None:
        """Return sprite surface for given direction and animation frame."""
        key = f"pacman_{direction.value}_{frame % 3}"
        if key not in self._sprites:
            key = f"pacman_{Direction.EAST.value}_{frame % 3}"
        return self._sprites.get(key)

    def get_ghost_sprite(
        self, name: str, is_frightened: bool
    ) -> Any | None:
        """Return sprite surface for normal or frightened ghost."""
        if is_frightened:
            return self._sprites.get("blue_ghost")
        return self._sprites.get(name)

    def get_item_sprite(self, item_name: str) -> Any | None:
        """Return sprite surface for collectible item."""
        return self._sprites.get(item_name)

    def cleanup(self) -> None:
        """Clear all cached sprite surfaces."""
        self._sprites.clear()
