"""Menu rendering module drawing menus, overlays, and instructions."""

import os
from typing import Any
import pygame
from src.model.game_state import GameState
from src.view.colors import Colors
from src.utils.arabic import format_arabic, get_ui_font


class MenuRenderer:
    """Renders menus, pause overlays, victory/defeat screens, and help."""

    def __init__(self, target_surface: pygame.Surface | None = None) -> None:
        """Initialize MenuRenderer with Pygame surface."""
        self._surface: pygame.Surface | None = target_surface
        self._font: pygame.font.Font | None = None
        self._title_font: pygame.font.Font | None = None
        self._cover_image: pygame.Surface | None = None
        self._game_over_image: pygame.Surface | None = None
        self._victory_image: pygame.Surface | None = None
        self._cached_wallpaper: pygame.Surface | None = None
        self._cached_banners: dict[tuple[int, int, int], pygame.Surface] = {}
        self._bottom_vignette: pygame.Surface | None = None
        self._init_fonts()
        self._load_cover_image()
        self._load_modal_images()

    def set_surface(self, target_surface: pygame.Surface | None) -> None:
        """Update the rendering target surface."""
        self._surface = target_surface

    def set_window(self, win_ptr: Any) -> None:
        """Compatibility shim for window/surface updates."""
        if isinstance(win_ptr, pygame.Surface):
            self._surface = win_ptr

    def _init_fonts(self) -> None:
        """Initialize Pygame fonts for titles and options."""
        try:
            self._font = get_ui_font(17, bold=True)
            self._title_font = get_ui_font(28, bold=True)
        except Exception:
            self._font = None
            self._title_font = None

    def _get_center_x(self) -> int:
        """Calculate dynamic center x coordinate from surface dimensions."""
        if not self._surface:
            return 512
        return self._surface.get_width() // 2

    def _render_text(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        color: tuple[int, int, int],
        text: str,
        is_title: bool = False,
    ) -> None:
        """Draw text using Pygame font."""
        font = (
            self._title_font if is_title and self._title_font else self._font
        )
        if not font:
            return
        formatted = format_arabic(text)
        txt_surf = font.render(formatted, True, color)
        surface.blit(txt_surf, (x, y))

    def _render_centered_text(
        self,
        surface: pygame.Surface,
        cx: int,
        y: int,
        color: tuple[int, int, int],
        text: str,
        is_title: bool = False,
    ) -> None:
        """Draw horizontally centered text using Pygame font."""
        font = (
            self._title_font if is_title and self._title_font else self._font
        )
        if not font:
            return
        formatted = format_arabic(text)
        txt_surf = font.render(formatted, True, color)
        surface.blit(txt_surf, (cx - txt_surf.get_width() // 2, y))

    def _draw_glass_panel(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        w: int,
        h: int,
        border_color: tuple[int, int, int] = Colors.GLASS_BORDER,
        bg_alpha: int = 220,
    ) -> None:
        """Draw rounded translucent glass card with glowing border."""
        panel = pygame.Surface((w, h), pygame.SRCALPHA)
        panel.fill((12, 18, 38, bg_alpha))
        pygame.draw.rect(
            panel, border_color, (0, 0, w, h), 2, border_radius=12
        )
        surface.blit(panel, (x, y))

    def _render_button(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        w: int,
        h: int,
        text: str,
        tag: str,
        is_selected: bool,
    ) -> None:
        """Render styled cyber arcade button card with active glow."""
        btn = pygame.Surface((w, h), pygame.SRCALPHA)
        bg = (28, 70, 150, 240) if is_selected else (15, 22, 45, 210)
        border = (
            Colors.BUTTON_BORDER_ACTIVE
            if is_selected
            else Colors.BUTTON_BORDER_IDLE
        )
        btn.fill(bg)
        pygame.draw.rect(btn, border, (0, 0, w, h), 2, border_radius=10)
        surface.blit(btn, (x, y))
        self._render_button_labels(surface, x, y, text, tag, is_selected)

    def _render_button_labels(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        text: str,
        tag: str,
        is_selected: bool,
    ) -> None:
        """Render tag and text on button."""
        color = (
            Colors.BUTTON_TEXT_ACTIVE
            if is_selected
            else Colors.BUTTON_TEXT_IDLE
        )
        tag_color = Colors.NEON_CYAN if is_selected else (120, 160, 210)
        self._render_text(surface, x + 16, y + 14, tag_color, tag)
        arrow = "> " if is_selected else "  "
        self._render_text(surface, x + 70, y + 14, color, f"{arrow}{text}")

    def _load_cover_image(self) -> None:
        """Load 42 Pac-Man menu cover image safely."""
        paths = [
            os.path.join("pacman-assets", "menu_wallpaper.png"),
            os.path.join("pacman-assets", "menu_cover.png"),
        ]
        for p in paths:
            if os.path.exists(p):
                try:
                    surf = pygame.image.load(p)
                    if pygame.display.get_surface() is not None:
                        surf = surf.convert()
                    self._cover_image = surf
                    return
                except Exception:
                    pass
        self._cover_image = None

    def _load_modal_images(self) -> None:
        """Load Game Over and Victory samurai theme illustrations."""
        go_path = os.path.join("pacman-assets", "game_over_card.png")
        vic_path = os.path.join("pacman-assets", "victory_card.png")
        self._game_over_image = self._load_single_image(go_path)
        self._victory_image = self._load_single_image(vic_path)

    def _load_single_image(self, path: str) -> pygame.Surface | None:
        """Load and convert an image file safely if present."""
        if not os.path.exists(path):
            return None
        try:
            surf = pygame.image.load(path)
            if pygame.display.get_surface() is not None:
                return surf.convert()
            return surf
        except Exception:
            return None

    def _get_scaled_banner(
        self, img: pygame.Surface, bw: int, bh: int
    ) -> pygame.Surface:
        """Return cached banner surface scaled to target dimensions."""
        key = (id(img), bw, bh)
        if key not in self._cached_banners:
            self._cached_banners[key] = pygame.transform.smoothscale(
                img, (bw, bh)
            )
        return self._cached_banners[key]

    def _draw_modal_banner(
        self,
        surface: pygame.Surface,
        img: pygame.Surface | None,
        x: int,
        y: int,
        bw: int,
        bh: int,
        border_color: tuple[int, int, int],
    ) -> None:
        """Render banner artwork with glowing border inside modal."""
        if not img:
            return
        scaled = self._get_scaled_banner(img, bw, bh)
        surface.blit(scaled, (x, y))
        pygame.draw.rect(
            surface, border_color, (x, y, bw, bh), 2, border_radius=10
        )

    def _render_wallpaper_background(
        self, surface: pygame.Surface, target_w: int, target_h: int
    ) -> None:
        """Draw cached full-bleed wallpaper with bottom vignette."""
        if not self._cover_image:
            return
        cached = self._cached_wallpaper
        if not cached or cached.get_size() != (target_w, target_h):
            self._cached_wallpaper = pygame.transform.smoothscale(
                self._cover_image, (target_w, target_h)
            )
        if self._cached_wallpaper:
            surface.blit(self._cached_wallpaper, (0, 0))
        half_h = target_h // 2
        vig = self._bottom_vignette
        if not vig or vig.get_size() != (target_w, half_h):
            self._create_bottom_vignette(target_w, half_h)
        if self._bottom_vignette:
            surface.blit(self._bottom_vignette, (0, half_h))

    def _create_bottom_vignette(self, w: int, h: int) -> None:
        """Create gradient overlay for bottom half of main menu."""
        vig = pygame.Surface((w, h), pygame.SRCALPHA)
        for y in range(h):
            alpha = int(235 * (y / h) ** 1.3)
            pygame.draw.line(vig, (8, 12, 24, alpha), (0, y), (w, y))
        self._bottom_vignette = vig

    def render_main_menu(
        self, selected_index: int, surface: pygame.Surface | None = None
    ) -> None:
        """Draw main menu cover banner and selectable options."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        w = target.get_width()
        h = target.get_height()
        self._render_wallpaper_background(target, w, h)
        if not self._cover_image:
            self._render_text(
                target, cx - 60, 120, Colors.YELLOW, "PAC-MAN", True
            )
        self._render_menu_options(target, cx, selected_index)
        self._render_menu_nav_hint(target, cx, h)

    def _render_menu_nav_hint(
        self, target: pygame.Surface, cx: int, h: int
    ) -> None:
        """Render frosted glass navigation pill at the bottom."""
        hint = "[ ▲ / ▼ ] Navigate   [ ENTER ] Confirm"
        tw, th = self._font.size(hint) if self._font else (420, 20)
        pw, ph = tw + 44, max(34, th + 14)
        px = cx - pw // 2
        py = min(h - 55, 910)
        pill = pygame.Surface((pw, ph), pygame.SRCALPHA)
        pill.fill((10, 16, 32, 190))
        pygame.draw.rect(
            pill, Colors.GLASS_BORDER, (0, 0, pw, ph), 1, border_radius=ph // 2
        )
        target.blit(pill, (px, py))
        tx = cx - tw // 2
        ty = py + (ph - th) // 2
        self._render_text(target, tx, ty, Colors.DIM_GRAY, hint)

    def _render_menu_options(
        self, surface: pygame.Surface, cx: int, selected_index: int
    ) -> None:
        """Render selectable main menu navigation options."""
        options = [
            ("PLAY GAME", "[ 1 ]"),
            ("HIGH SCORES", "[ 2 ]"),
            ("INSTRUCTIONS", "[ 3 ]"),
            ("EXIT GAME", "[ 4 ]"),
        ]
        bw, bh = 340, 46
        bx = cx - bw // 2
        base_y = 670 if self._cover_image else 220
        spacing = 54
        for i, (opt, tag) in enumerate(options):
            self._render_button(
                surface, bx, base_y + i * spacing, bw, bh, opt, tag,
                i == selected_index
            )

    def render_registration(
        self, state: GameState, surface: pygame.Surface | None = None
    ) -> None:
        """Draw student name and section entry screen."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        w, h = target.get_width(), target.get_height()
        self._render_wallpaper_background(target, w, h)
        pw, ph = 540, 390
        px, py = cx - pw // 2, (h - ph) // 2
        self._draw_glass_panel(target, px, py, pw, ph, Colors.NEON_CYAN)
        title = "تسجيل بيانات بطل الرياضيات - الصف السابع"
        self._render_centered_text(
            target, cx, py + 22, Colors.GOLD, title, True
        )
        self._render_registration_inputs(target, cx, py, state)
        self._render_registration_footer(target, cx, py + ph)

    def _render_registration_inputs(
        self, surface: pygame.Surface, cx: int, py: int, state: GameState
    ) -> None:
        """Render name input box and classroom section selector."""
        self._render_centered_text(
            surface, cx, py + 80, (200, 225, 255), "اسم الطالب / البطل:"
        )
        box_w, box_h = 440, 46
        box_x = cx - box_w // 2
        self._draw_glass_panel(
            surface, box_x, py + 110, box_w, box_h, Colors.NEON_CYAN, 240
        )
        buf = state.get_name_buffer()
        name_disp = f"{buf}_" if buf else "(اكتب اسمك الثلاثي هنا...)"
        name_clr = Colors.WHITE if buf else Colors.DIM_GRAY
        self._render_centered_text(
            surface, cx, py + 122, name_clr, name_disp
        )
        self._render_section_selector(surface, cx, py + 175, state)

    def _render_section_selector(
        self, surface: pygame.Surface, cx: int, y: int, state: GameState
    ) -> None:
        """Render classroom section selector box and arrows."""
        self._render_centered_text(
            surface, cx, y, (200, 225, 255), "الشعبة الدراسية:"
        )
        box_w, box_h = 440, 46
        box_x = cx - box_w // 2
        self._draw_glass_panel(
            surface, box_x, y + 30, box_w, box_h, Colors.GOLD, 240
        )
        sec_text = f"◄   {state.get_student_section()}   ►"
        self._render_centered_text(
            surface, cx, y + 42, Colors.GOLD, sec_text
        )

    def _render_registration_footer(
        self, surface: pygame.Surface, cx: int, bottom_y: int
    ) -> None:
        """Render navigation and confirmation hints for registration."""
        hint_sec = "◄  استخدم الأسهم لتغيير الشعبة  ►"
        self._render_centered_text(
            surface, cx, bottom_y - 110, (150, 190, 240), hint_sec
        )
        hint_go = "[ ENTER ] تأكيد وبدء المغامرة     [ ESC ] رجوع للقائمة"
        self._render_centered_text(
            surface, cx, bottom_y - 70, Colors.NEON_CYAN, hint_go
        )
        hint_del = "[ BACKSPACE ] مسح حرف"
        self._render_centered_text(
            surface, cx, bottom_y - 40, Colors.DIM_GRAY, hint_del
        )

    def render_pause_menu(
        self, selected_index: int, surface: pygame.Surface | None = None
    ) -> None:
        """Draw pause overlay menu with semi-transparent background."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        pw, ph = 400, 230
        px = cx - pw // 2
        py = 280
        self._draw_glass_panel(target, px, py, pw, ph, Colors.NEON_CYAN)
        self._render_text(
            target, cx - 110, py + 25, Colors.GOLD, "== GAME PAUSED ==", True
        )
        options = [("RESUME", "[ 1 ]"), ("QUIT TO MENU", "[ 2 ]")]
        bw, bh = 300, 46
        bx = cx - bw // 2
        for i, (opt, tag) in enumerate(options):
            self._render_button(
                target, bx, py + 85 + i * 58, bw, bh, opt, tag,
                i == selected_index
            )

    def render_game_over(
        self, score: int, name_buffer: str,
        surface: pygame.Surface | None = None,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Draw game over screen with samurai artwork and score prompt."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        pw, ph = (500, 560) if self._game_over_image else (460, 360)
        px, py = cx - pw // 2, (target.get_height() - ph) // 2
        self._draw_glass_panel(target, px, py, pw, ph, Colors.BLINKY_RED)
        if self._game_over_image:
            self._draw_modal_banner(target, self._game_over_image,
                                    px + 20, py + 20, 460, 240,
                                    Colors.BLINKY_RED)
            self._render_game_over_body(target, cx, py + 275,
                                        score, name_buffer, diag)
            return
        self._render_compact_game_over(
            target, cx, py, score, name_buffer, diag
        )

    def _diag_color(self, acc: float) -> tuple[int, int, int]:
        """Return status color based on diagnostic accuracy."""
        if acc >= 80:
            return Colors.YELLOW
        return (255, 170, 0) if acc >= 60 else Colors.BLINKY_RED

    def _render_diagnostic_summary(
        self,
        surface: pygame.Surface,
        cx: int,
        y: int,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Render student diagnostic accuracy and identified misconception."""
        if not diag:
            return
        acc = diag.get("accuracy_percentage", 100.0)
        line1 = f"الدقة: {acc}% | تم توثيق الشواهد في لوحة المعلم"
        self._render_text(surface, cx - 180, y, self._diag_color(acc), line1)
        miscs = diag.get("misconceptions", [])
        msg = (
            f"فجوة مرصودة: {miscs[0]}" if miscs
            else "إتقان كامل لكافة معايير الأعداد النسبية!"
        )
        clr = (255, 130, 130) if miscs else (100, 255, 150)
        self._render_text(surface, cx - 170, y + 24, clr, msg)

    def _render_game_over_body(
        self,
        surface: pygame.Surface,
        cx: int,
        y: int,
        score: int,
        name: str,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Render defeat quote, score, and input box."""
        quote = "PRACTICE MAKES PERFECT! TRY AGAIN, HERO!"
        self._render_text(surface, cx - 180, y, Colors.BLINKY_RED, quote)
        self._render_text(
            surface, cx - 60, y + 30, Colors.WHITE, f"SCORE: {score}"
        )
        self._render_diagnostic_summary(surface, cx, y + 55, diag)
        self._render_name_input_field(surface, cx, y + 115, name)
        hint = "[ENTER] Save Score   [ESC] Menu"
        self._render_text(surface, cx - 140, y + 175, Colors.DIM_GRAY, hint)

    def _render_compact_game_over(
        self,
        surface: pygame.Surface,
        cx: int,
        py: int,
        score: int,
        name: str,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Fallback game over layout when artwork is unavailable."""
        self._render_text(
            surface, cx - 80, py + 20, Colors.BLINKY_RED, "GAME OVER", True
        )
        self._render_text(
            surface, cx - 60, py + 65, Colors.WHITE, f"SCORE: {score}"
        )
        self._render_diagnostic_summary(surface, cx, py + 95, diag)
        self._render_name_input_field(surface, cx, py + 155, name)
        hint = "[ENTER] Save Score   [ESC] Menu"
        self._render_text(surface, cx - 140, py + 215, Colors.DIM_GRAY, hint)

    def _render_name_input_field(
        self, surface: pygame.Surface, cx: int, y: int, name_buffer: str
    ) -> None:
        """Render high-tech player name entry field with glowing cursor."""
        fw, fh = 340, 48
        fx = cx - fw // 2
        box = pygame.Surface((fw, fh), pygame.SRCALPHA)
        box.fill((10, 16, 32, 230))
        pygame.draw.rect(
            box, Colors.NEON_CYAN, (0, 0, fw, fh), 2, border_radius=8
        )
        surface.blit(box, (fx, y))
        label = f"الاسم: {name_buffer}_" if name_buffer else "الاسم: _"
        self._render_centered_text(surface, cx, y + 14, Colors.GOLD, label)

    def render_victory(
        self, score: int, name_buffer: str,
        surface: pygame.Surface | None = None,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Draw victory screen with triumphant shogun artwork."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()

        pw, ph = (500, 560) if self._victory_image else (480, 360)
        px, py = cx - pw // 2, (target.get_height() - ph) // 2
        self._draw_glass_panel(target, px, py, pw, ph, Colors.GOLD)
        if self._victory_image:
            self._draw_modal_banner(
                target, self._victory_image, px + 20, py + 20, 460, 240,
                Colors.GOLD
            )
            self._render_victory_body(
                target, cx, py + 275, score, name_buffer, diag
            )
            return
        self._render_compact_victory(target, cx, py, score, name_buffer, diag)

    def _render_victory_body(
        self,
        surface: pygame.Surface,
        cx: int,
        y: int,
        score: int,
        name: str,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Render victory quote, final score, and input box."""
        quote = "VICTORY! 7TH-GRADE RATIONAL NUMBERS HERO!"
        self._render_text(surface, cx - 185, y, Colors.GOLD, quote)
        self._render_text(
            surface, cx - 75, y + 30, Colors.WHITE, f"FINAL SCORE: {score}"
        )
        self._render_diagnostic_summary(surface, cx, y + 55, diag)
        self._render_name_input_field(surface, cx, y + 115, name)
        hint = "[ENTER] Save Score   [ESC] Menu"
        self._render_text(surface, cx - 140, y + 175, Colors.DIM_GRAY, hint)

    def _render_compact_victory(
        self,
        surface: pygame.Surface,
        cx: int,
        py: int,
        score: int,
        name: str,
        diag: dict[str, Any] | None = None,
    ) -> None:
        """Fallback victory layout when artwork is unavailable."""
        self._render_text(
            surface, cx - 110, py + 20, Colors.GOLD, "* VICTORY! *", True
        )
        self._render_text(
            surface, cx - 75, py + 65, Colors.WHITE, f"FINAL SCORE: {score}"
        )
        self._render_diagnostic_summary(surface, cx, py + 95, diag)
        self._render_name_input_field(surface, cx, py + 155, name)
        hint = "[ENTER] Save Score   [ESC] Menu"
        self._render_text(surface, cx - 140, py + 215, Colors.DIM_GRAY, hint)

    def render_highscores(
        self, state: GameState, surface: pygame.Surface | None = None
    ) -> None:
        """Display the top 10 local leaderboard records."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        pw, ph = 520, 520
        px, py = cx - pw // 2, 100
        self._draw_glass_panel(target, px, py, pw, ph, Colors.NEON_CYAN)
        title = "★ TOP 10 HIGHSCORES ★"
        self._render_text(target, cx - 130, py + 25, Colors.GOLD, title, True)
        self._render_highscore_rows(target, cx, py + 80, state)
        hint = "Press ESC or ENTER to return to menu"
        self._render_text(
            target, cx - 150, py + ph - 35, Colors.DIM_GRAY, hint
        )

    def _render_highscore_rows(
        self, surface: pygame.Surface, cx: int, start_y: int, state: GameState
    ) -> None:
        """Render leaderboard row entries with rank medals."""
        scores = state.get_highscore_manager().get_scores()
        if not scores:
            self._render_text(
                surface, cx - 90, start_y + 40, Colors.WHITE,
                "No scores recorded yet."
            )
            return
        medals = {0: "1. [GOLD]  ", 1: "2. [SILVER]", 2: "3. [BRONZE]"}
        colors = {0: Colors.GOLD, 1: (200, 220, 240), 2: (220, 160, 100)}
        for i, entry in enumerate(scores[:10]):
            rank = medals.get(i, f"{i + 1:2d}.        ")
            color = colors.get(i, Colors.WHITE)
            line = f"{rank} {entry['name']:<10s}  {entry['score']:>6d} pts"
            self._render_text(surface, cx - 190, start_y + i * 36, color, line)

    def _get_instruction_lines(self) -> list[str]:
        """Return tutorial, controls, and cheat instruction lines."""
        return [
            "= CONTROLS =",
            "Movement: ARROW KEYS or W/A/S/D | Pause: ESC or P",
            "= 7TH GRADE RATIONAL NUMBERS MISSION =",
            "Collect 4 correct target math tiles to clear mission!",
            "Target math tile = +100 pts | Trap tile = -30 pts",
            "Corner Super-Pacgums make fallacy ghosts edible!",
            "Devour frightened fallacy ghosts for +200 points!",
            "= TEACHER / CHEAT CODES (Keys 1-5) =",
            "1: Invincible | 2: Skip Level | 3: Freeze Ghosts",
            "4: +1 Life   | 5: Speed 2x",
        ]

    def render_instructions(
        self, surface: pygame.Surface | None = None
    ) -> None:
        """Display control bindings, rules, and cheat commands."""
        target = surface or self._surface
        if not target:
            return
        cx = self._get_center_x()
        pw, ph = 620, 560
        px, py = cx - pw // 2, 80
        self._draw_glass_panel(target, px, py, pw, ph, Colors.NEON_CYAN)
        self._render_text(
            target, cx - 120, py + 25, Colors.GOLD, "* INSTRUCTIONS *", True
        )

        for i, line in enumerate(self._get_instruction_lines()):
            color = Colors.NEON_CYAN if line.startswith("=") else Colors.WHITE
            self._render_text(target, px + 35, py + 80 + i * 38, color, line)
        hint = "Press ESC or ENTER to return to menu"
        self._render_text(
            target, cx - 150, py + ph - 35, Colors.DIM_GRAY, hint
        )

    def cleanup(self) -> None:
        """Release menu resources and surfaces."""
        self._cover_image = None
        self._game_over_image = None
        self._victory_image = None
        self._cached_wallpaper = None
        self._cached_banners.clear()
        self._bottom_vignette = None
