"""Color definitions in RGB tuple format for Pygame-CE display."""


class Colors:
    """Standard RGB color constants for game rendering."""

    BLACK: tuple[int, int, int] = (0, 0, 0)
    WHITE: tuple[int, int, int] = (255, 255, 255)
    YELLOW: tuple[int, int, int] = (255, 255, 0)
    WALL_BLUE: tuple[int, int, int] = (33, 33, 222)
    WALL_DARK: tuple[int, int, int] = (11, 11, 107)
    BLOCK_42: tuple[int, int, int] = (66, 66, 160)
    BLINKY_RED: tuple[int, int, int] = (255, 0, 0)
    PINKY_PINK: tuple[int, int, int] = (255, 184, 222)
    INKY_CYAN: tuple[int, int, int] = (0, 255, 255)
    CLYDE_ORANGE: tuple[int, int, int] = (255, 184, 71)
    FRIGHTENED_BLUE: tuple[int, int, int] = (33, 33, 222)
    PACGUM_COLOR: tuple[int, int, int] = (255, 184, 174)
    SUPER_PACGUM_COLOR: tuple[int, int, int] = (255, 255, 0)
    HUD_TEXT: tuple[int, int, int] = (255, 255, 255)
    SELECTION_COLOR: tuple[int, int, int] = (255, 255, 0)
    DIM_GRAY: tuple[int, int, int] = (102, 102, 102)
    GREEN: tuple[int, int, int] = (50, 255, 50)
    NEON_CYAN: tuple[int, int, int] = (0, 255, 255)
    NEON_YELLOW: tuple[int, int, int] = (255, 235, 50)
    GOLD: tuple[int, int, int] = (255, 215, 0)

    DARK_NAVY: tuple[int, int, int] = (10, 14, 28)
    GLASS_BORDER: tuple[int, int, int] = (45, 95, 175)
    GLASS_BORDER_GLOW: tuple[int, int, int] = (0, 220, 255)
    BUTTON_BORDER_IDLE: tuple[int, int, int] = (50, 90, 150)
    BUTTON_BORDER_ACTIVE: tuple[int, int, int] = (0, 255, 255)
    BUTTON_TEXT_IDLE: tuple[int, int, int] = (225, 235, 250)
    BUTTON_TEXT_ACTIVE: tuple[int, int, int] = (255, 225, 50)
