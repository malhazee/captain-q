"""View package containing Pygame-CE rendering and UI components."""
