"""Animation cycle controller for sprites and entity visual states."""


class AnimationManager:
    """Controls frame cycles for character mouth animation and effects."""

    FRAME_DURATION = 0.12

    def __init__(self) -> None:
        """Initialize frame counters and timers."""
        self._elapsed: float = 0.0
        self._current_frame: int = 0
        self._total_frames: int = 3

    def update(self, delta_time: float) -> None:
        """Advance animation timer and wrap frame index.

        Args:
            delta_time: Elapsed seconds since last update.
        """
        self._elapsed += delta_time
        if self._elapsed >= self.FRAME_DURATION:
            self._elapsed = 0.0
            self._current_frame = (
                (self._current_frame + 1) % self._total_frames
            )

    def get_frame(self) -> int:
        """Return the current frame index (0, 1, or 2)."""
        return self._current_frame

    def reset(self) -> None:
        """Reset animation cycle to frame 0."""
        self._elapsed = 0.0
        self._current_frame = 0
