"""Maze rendering module drawing walls, corridors, and collectibles."""

from typing import Any
import pygame
from src.model.maze import Maze
from src.model.collectible import CollectibleManager
from src.view.colors import Colors
from src.view.sprite_manager import SpriteManager


class MazeRenderer:
    """Renders the maze grid and collectible pellets using Pygame."""

    TILE_SIZE = 68
    OFFSET_X = 24
    OFFSET_Y = 96
    DOT_SIZE = 10
    SUPER_DOT_SIZE = 20
    WALL_OUTER = (0, 70, 255)
    WALL_INNER = (60, 220, 255)

    def __init__(
        self,
        sprites: SpriteManager,
        target_surface: pygame.Surface | None = None,
    ) -> None:
        """Initialize MazeRenderer with sprites and display surface."""
        self._sprites: SpriteManager = sprites
        self._surface: pygame.Surface | None = target_surface
        self._tile_size: int = self.TILE_SIZE
        self._offset_x: int = self.OFFSET_X
        self._offset_y: int = self.OFFSET_Y
        self._maze_surf: pygame.Surface | None = None
        self._dots_surf: pygame.Surface | None = None
        self._cached_maze_id: int | None = None
        self._cached_coll_id: int | None = None
        self._active_dots: set[tuple[int, int]] = set()
        self._maze_w: int = 540
        self._maze_h: int = 540
        self._math_font: pygame.font.Font | None = None
        self._update_math_font()

    def _update_math_font(self) -> None:
        """Update font size proportionally to active tile size."""
        try:
            if not pygame.font.get_init():
                pygame.font.init()
            fsize = max(15, int(self._tile_size * 0.35))
            self._math_font = pygame.font.SysFont("arial", fsize, bold=True)
        except Exception:
            self._math_font = None

    def get_tile_size(self) -> int:
        """Return the active tile size in pixels."""
        return self._tile_size

    def set_surface(self, target_surface: pygame.Surface | None) -> None:
        """Update the rendering target surface."""
        self._surface = target_surface

    def set_window(self, win_ptr: Any) -> None:
        """Compatibility shim for window/surface updates."""
        if isinstance(win_ptr, pygame.Surface):
            self._surface = win_ptr

    def get_offset_x(self) -> int:
        """Return current horizontal render offset."""
        return self._offset_x

    def get_offset_y(self) -> int:
        """Return current vertical render offset."""
        return self._offset_y

    def calculate_offsets(
        self, maze: Maze | None, win_w: int, win_h: int
    ) -> tuple[int, int]:
        """Calculate dynamic center offsets for current maze and window."""
        if not maze:
            self._offset_x = self.OFFSET_X
            self._offset_y = self.OFFSET_Y
            return (self._offset_x, self._offset_y)
        max_ts_w = (win_w - 70) // maze.get_width()
        max_ts_h = (win_h - self.OFFSET_Y - 70) // maze.get_height()
        self._tile_size = max(36, min(72, min(max_ts_w, max_ts_h)))
        self._update_math_font()
        self._maze_w = maze.get_width() * self._tile_size
        self._maze_h = maze.get_height() * self._tile_size
        self._offset_x = max(10, (win_w - self._maze_w) // 2)
        top_bar = self.OFFSET_Y
        avail_h = max(0, win_h - top_bar - self._maze_h)
        self._offset_y = max(top_bar, top_bar + avail_h // 2)
        return (self._offset_x, self._offset_y)

    def render_maze(
        self, maze: Maze, surface: pygame.Surface | None = None
    ) -> None:
        """Render cached walls and obstacles across the maze grid."""
        target = surface or self._surface
        if not target:
            return
        self._draw_maze_bezel(target, maze)
        if self._cached_maze_id != id(maze) or self._maze_surf is None:
            self._maze_surf = self._build_maze_surface(maze)
            self._cached_maze_id = id(maze)
        target.blit(self._maze_surf, (self._offset_x, self._offset_y))

    def _draw_maze_bezel(self, surface: pygame.Surface, maze: Maze) -> None:
        """Draw high-tech outer glowing bezel frame around maze boundaries."""
        w = maze.get_width() * self._tile_size
        h = maze.get_height() * self._tile_size
        ox, oy = self._offset_x, self._offset_y
        bezel_rect = pygame.Rect(ox - 6, oy - 6, w + 12, h + 12)
        pygame.draw.rect(surface, (10, 20, 45), bezel_rect, border_radius=8)
        pygame.draw.rect(
            surface, (30, 80, 180), bezel_rect, 2, border_radius=8
        )
        inner_rect = pygame.Rect(ox - 2, oy - 2, w + 4, h + 4)
        pygame.draw.rect(
            surface, Colors.NEON_CYAN, inner_rect, 1, border_radius=4
        )

    def _build_maze_surface(self, maze: Maze) -> pygame.Surface:
        """Create a cached surface with all wall lines and obstacle blocks."""
        w = maze.get_width() * self._tile_size
        h = maze.get_height() * self._tile_size
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        for y in range(maze.get_height()):
            for x in range(maze.get_width()):
                self._draw_cell_to_surface(surf, maze, x, y)
        self._draw_central_emblem(surf, maze)
        return surf

    def _draw_central_emblem(self, surf: pygame.Surface, maze: Maze) -> None:
        """Draw central mathematical sanctuary floor and 4-in-1 emblem."""
        if not hasattr(maze, "get_sanctuary_rect"):
            return
        x1, x2, y1, y2 = maze.get_sanctuary_rect()
        ts = self._tile_size
        rx, ry = x1 * ts, y1 * ts
        rw, rh = (x2 - x1 + 1) * ts, (y2 - y1 + 1) * ts
        r = pygame.Rect(rx, ry, rw, rh)
        pygame.draw.rect(surf, (10, 20, 45), r, border_radius=8)
        pygame.draw.rect(surf, Colors.NEON_CYAN, r, 2, border_radius=8)
        emblem = self._sprites.get_item_sprite("math_center_emblem")
        if emblem:
            pad = max(4, int(min(rw, rh) * 0.08))
            ew, eh = rw - 2 * pad, rh - 2 * pad
            scaled = pygame.transform.smoothscale(emblem, (ew, eh))
            surf.blit(scaled, (rx + pad, ry + pad))

    def _draw_cell_to_surface(
        self, surf: pygame.Surface, maze: Maze, x: int, y: int
    ) -> None:
        """Draw walls, floor tile, or obstacle block for a single cell."""
        ts = self._tile_size
        px, py = x * ts, y * ts
        if maze.is_wall_block(x, y):
            self._draw_obstacle_block(surf, px, py, ts)
            return
        self._draw_floor_tile(surf, px, py, ts)
        self._draw_cell_borders(surf, maze.get_cell(x, y), px, py)

    def _draw_obstacle_block(
        self, surf: pygame.Surface, px: int, py: int, ts: int
    ) -> None:
        """Draw a '42' circuit obstacle block with optional sprite."""
        wall_sprite = self._sprites.get_item_sprite("wall_block")
        if wall_sprite:
            if wall_sprite.get_size() != (ts, ts):
                wall_sprite = pygame.transform.smoothscale(
                    wall_sprite, (ts, ts)
                )
            surf.blit(wall_sprite, (px, py))
        else:
            rect = pygame.Rect(px + 2, py + 2, ts - 4, ts - 4)
            pygame.draw.rect(surf, Colors.BLOCK_42, rect)

    def _draw_floor_tile(
        self, surf: pygame.Surface, px: int, py: int, ts: int
    ) -> None:
        """Draw subtle tech floor tile on walkable corridor cell."""
        tile_sprite = self._sprites.get_item_sprite("floor_tile")
        if tile_sprite:
            if tile_sprite.get_size() != (ts, ts):
                tile_sprite = pygame.transform.smoothscale(
                    tile_sprite, (ts, ts)
                )
            surf.blit(tile_sprite, (px, py))
        else:
            pygame.draw.rect(surf, (12, 18, 36), (px, py, ts, ts))

    def _draw_cell_borders(
        self, surf: pygame.Surface, cell: int, px: int, py: int
    ) -> None:
        """Draw boundary border lines based on cell bitmask."""
        ts = self._tile_size
        out_c, in_c = self.WALL_OUTER, self.WALL_INNER
        if cell & 1:  # NORTH
            pygame.draw.line(surf, out_c, (px, py), (px + ts - 1, py), 4)
            pygame.draw.line(surf, in_c, (px, py), (px + ts - 1, py), 2)
        if cell & 2:  # EAST
            p1, p2 = (px + ts - 1, py), (px + ts - 1, py + ts - 1)
            pygame.draw.line(surf, out_c, p1, p2, 4)
            pygame.draw.line(surf, in_c, p1, p2, 2)
        if cell & 4:  # SOUTH
            p1, p2 = (px, py + ts - 1), (px + ts - 1, py + ts - 1)
            pygame.draw.line(surf, out_c, p1, p2, 4)
            pygame.draw.line(surf, in_c, p1, p2, 2)
        if cell & 8:  # WEST
            pygame.draw.line(surf, out_c, (px, py), (px, py + ts - 1), 4)
            pygame.draw.line(surf, in_c, (px, py), (px, py + ts - 1), 2)

    def render_collectibles(
        self,
        collectibles: CollectibleManager,
        surface: pygame.Surface | None = None,
    ) -> None:
        """Draw regular pacgum dots, math tiles, and super pacgums."""
        target = surface or self._surface
        if not target:
            return
        self._update_dots_surface(collectibles)
        if self._dots_surf:
            target.blit(self._dots_surf, (self._offset_x, self._offset_y))
        if hasattr(collectibles, "get_all_math_tiles"):
            self._render_math_tiles(target, collectibles.get_all_math_tiles())
        self._render_super_dots(target, collectibles.get_super_pacgums())

    def render_floating_texts(
        self, texts: list[Any], surface: pygame.Surface | None = None
    ) -> None:
        """Render floating score popups above collected tiles."""
        target = surface or self._surface
        if not target or not texts or not self._math_font:
            return
        ts = self._tile_size
        for ft in texts:
            lift = int(ft.get_progress() * 26)
            px = self._offset_x + ft.grid_x * ts + ts // 2
            py = self._offset_y + ft.grid_y * ts + ts // 2 - lift
            txt = self._math_font.render(ft.text, True, ft.color)
            target.blit(txt, txt.get_rect(center=(px, py)))

    def _update_dots_surface(self, collectibles: CollectibleManager) -> None:
        """Update or refresh the cached dots surface."""
        current_dots = collectibles.get_pacgums()
        coll_id = id(collectibles)
        is_new = (
            self._dots_surf is None or self._cached_coll_id != coll_id
        )
        if is_new or len(current_dots) > len(self._active_dots):
            self._build_dots_surface(current_dots)
            self._cached_coll_id = coll_id
        elif self._active_dots != current_dots:
            self._erase_consumed_dots(current_dots)
        self._active_dots = set(current_dots)

    def _render_math_tiles(
        self, surface: pygame.Surface, math_tiles: dict[tuple[int, int], Any]
    ) -> None:
        """Render distinct mathematical fraction and number cards in cells."""
        ts = self._tile_size
        cw, ch = int(ts * 0.88), int(ts * 0.72)
        off_x = (ts - cw) // 2
        off_y = (ts - ch) // 2
        for (x, y), tile in math_tiles.items():
            px = self._offset_x + x * ts + off_x
            py = self._offset_y + y * ts + off_y
            r = pygame.Rect(px, py, cw, ch)
            pygame.draw.rect(surface, (15, 24, 48), r, border_radius=4)
            pygame.draw.rect(
                surface, Colors.NEON_YELLOW, r, 1, border_radius=4
            )
            if self._math_font:
                txt = self._math_font.render(tile.label, True, (255, 255, 255))
                surface.blit(txt, txt.get_rect(center=r.center))

    def _build_dots_surface(self, dots: set[tuple[int, int]]) -> None:
        """Bake all active pacgum dots into a single transparent surface."""
        ts = self._tile_size
        d_off = (ts - self.DOT_SIZE) // 2
        w, h = max(540, self._maze_w), max(540, self._maze_h)
        self._dots_surf = pygame.Surface((w, h), pygame.SRCALPHA)
        dot_sprite = self._sprites.get_item_sprite("dot")
        for x, y in dots:
            px, py = x * ts + d_off, y * ts + d_off
            if dot_sprite:
                self._dots_surf.blit(dot_sprite, (px, py))
            else:
                rect = (px, py, self.DOT_SIZE, self.DOT_SIZE)
                pygame.draw.rect(self._dots_surf, Colors.PACGUM_COLOR, rect)
        self._active_dots = set(dots)

    def _erase_consumed_dots(
        self, current_dots: set[tuple[int, int]]
    ) -> None:
        """Erase consumed dots from the cached surface using clear rects."""
        if not self._dots_surf:
            return
        ts = self._tile_size
        d_off = (ts - self.DOT_SIZE) // 2
        consumed = self._active_dots - current_dots
        clear_color = (0, 0, 0, 0)
        for x, y in consumed:
            px, py = x * ts + d_off, y * ts + d_off
            rect = (px, py, self.DOT_SIZE, self.DOT_SIZE)
            self._dots_surf.fill(clear_color, rect)

    def _render_super_dots(
        self, surface: pygame.Surface, super_dots: set[tuple[int, int]]
    ) -> None:
        """Render all super pacgum corner pellets."""
        ts = self._tile_size
        s_off = (ts - self.SUPER_DOT_SIZE) // 2
        super_sprite = self._sprites.get_item_sprite("super_dot")
        for x, y in super_dots:
            px = self._offset_x + x * ts + s_off
            py = self._offset_y + y * ts + s_off
            if super_sprite:
                surface.blit(super_sprite, (px, py))
            else:
                rect = (px, py, self.SUPER_DOT_SIZE, self.SUPER_DOT_SIZE)
                pygame.draw.rect(surface, Colors.SUPER_PACGUM_COLOR, rect)

    def _draw_rect(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        color: tuple[int, int, int],
        surface: pygame.Surface | None = None,
    ) -> None:
        """Draw a filled rectangle on the active surface."""
        target = surface or self._surface
        if target:
            pygame.draw.rect(target, color, (x, y, w, h))

    def cleanup(self) -> None:
        """Release cached surfaces."""
        self._maze_surf = None
        self._dots_surf = None
        self._cached_maze_id = None
        self._cached_coll_id = None
        self._active_dots.clear()
