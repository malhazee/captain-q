"""HUD rendering module displaying score, lives, level, timer, and high-visibility math missions."""

import math
from typing import Any
import pygame
from src.model.game_state import GameState
from src.view.colors import Colors
from src.utils.arabic import format_arabic, get_ui_font


class HudRenderer:
    """Renders the in-game heads-up display overlay with enhanced legibility."""

    def __init__(self, target_surface: pygame.Surface | None = None) -> None:
        """Initialize HudRenderer with Pygame surface."""
        self._surface: pygame.Surface | None = target_surface
        self._font: pygame.font.Font | None = None
        self._title_font: pygame.font.Font | None = None
        self._big_font: pygame.font.Font | None = None
        self._prompt_font: pygame.font.Font | None = None
        self._banner_font: pygame.font.Font | None = None
        self._heart_surf: pygame.Surface | None = None
        self._last_synced_mission: str = ""
        self._init_font()
        self._init_heart_image()

    def set_surface(self, target_surface: pygame.Surface | None) -> None:
        """Update the rendering target surface."""
        self._surface = target_surface

    def set_window(self, win_ptr: Any) -> None:
        """Compatibility shim for window/surface updates."""
        if isinstance(win_ptr, pygame.Surface):
            self._surface = win_ptr

    def _init_font(self) -> None:
        """Initialize Pygame fonts for HUD text with clear high-visibility sizes."""
        try:
            self._font = get_ui_font(18, bold=True)
            self._title_font = get_ui_font(24, bold=True)
            self._big_font = get_ui_font(32, bold=True)
            self._prompt_font = get_ui_font(28, bold=True)
            self._banner_font = get_ui_font(22, bold=True)
        except Exception:
            self._font = None
            self._title_font = None
            self._big_font = None
            self._prompt_font = None
            self._banner_font = None

    def _init_heart_image(self) -> None:
        """Create and cache a small heart icon surface."""
        try:
            surf = pygame.Surface((11, 9), pygame.SRCALPHA)
            rows = (
                " 0110 0110 ", "11111111111", "11111111111", "11111111111",
                " 111111111 ", "  1111111  ", "   11111   ", "    111    ",
                "     1     ",
            )
            for dy, row in enumerate(rows):
                for dx, ch in enumerate(row):
                    if ch == "1":
                        surf.set_at((dx, dy), Colors.BLINKY_RED)
            self._heart_surf = surf
        except Exception:
            self._heart_surf = None

    def _render_text(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        color: tuple[int, int, int],
        text: str,
    ) -> None:
        """Draw string on the Pygame surface."""
        if not self._font:
            return
        formatted = format_arabic(text)
        txt_surf = self._font.render(formatted, True, color)
        surface.blit(txt_surf, (x, y))

    def _render_text_with_font(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        color: tuple[int, int, int],
        text: str,
        font: pygame.font.Font | None,
    ) -> None:
        """Draw string on the Pygame surface with specified font."""
        f = font or self._font
        if not f:
            return
        formatted = format_arabic(text)
        txt_surf = f.render(formatted, True, color)
        surface.blit(txt_surf, (x, y))

    def render_hud(
        self,
        state: GameState,
        maze_w: int = 420,
        win_w: int = 780,
        surface: pygame.Surface | None = None,
    ) -> None:
        """Render in-game HUD score header, mission banner, and active badges."""
        target = surface or self._surface
        if not target:
            return
        w = max(420, maze_w)
        hx = max(10, (win_w - w) // 2)
        self._render_top_bar(target, state, hx, w)
        self._render_mission_banner(target, state.get_level(), hx, w)
        self._render_active_badges(target, state, state.get_level(), hx, w)

    def _render_mission_banner(
        self, target: pygame.Surface, level: Any, hx: int, w: int
    ) -> None:
        """Render active curriculum mission prompt and goal counter in high contrast."""
        if not level or not hasattr(level, "get_mission"):
            return
        m = level.get_mission()
        if not m:
            return
        f_banner = self._banner_font or self._font
        if not f_banner:
            return
        bar_h = 36
        bar = pygame.Surface((w + 20, bar_h), pygame.SRCALPHA)
        bar.fill((12, 22, 54, 235))
        pygame.draw.rect(
            bar, Colors.GOLD, (0, 0, w + 20, bar_h), 2, border_radius=8
        )
        target.blit(bar, (hx - 10, 48))
        txt = format_arabic(
            f"🎯 المهمة: {m.get_prompt()}   [{m.get_collected_count()}/{m.get_needed_count()}]"
        )
        t_surf = f_banner.render(txt, True, Colors.GOLD)
        target.blit(t_surf, t_surf.get_rect(center=(hx + w // 2, 48 + bar_h // 2)))

    def _render_top_bar(
        self, target: pygame.Surface, state: GameState, hx: int, w: int
    ) -> None:
        """Render score, lives, current level, and remaining time on HUD."""
        self._draw_hud_cockpit_bar(target, hx - 10, 10, w + 20, 34)
        lvl = state.get_level()
        sc = state.get_score().get_score()
        liv = lvl.get_player().get_lives() if lvl else 0
        rem = int(lvl.get_time_remaining()) if lvl else 0
        self._render_text(target, hx + 10, 18, Colors.GOLD, f"SCORE: {sc}")
        self._render_lives(target, hx + int(w * 0.28), 18, liv)
        self._render_text(
            target, hx + int(w * 0.58), 18, Colors.NEON_CYAN,
            f"LEVEL: {state.get_level_number()}"
        )
        t_color = Colors.BLINKY_RED if rem < 15 else Colors.WHITE
        self._render_text(
            target, hx + w - 95, 18, t_color, f"TIME: {rem}s"
        )

    def _draw_hud_cockpit_bar(
        self, surface: pygame.Surface, x: int, y: int, w: int, h: int
    ) -> None:
        """Draw high-tech translucent cockpit glass frame for HUD."""
        bar = pygame.Surface((w, h), pygame.SRCALPHA)
        bar.fill((10, 16, 36, 215))
        pygame.draw.rect(
            bar, Colors.GLASS_BORDER, (0, 0, w, h), 1, border_radius=8
        )
        surface.blit(bar, (x, y))

    def _get_active_badges(
        self, state: GameState, level: Any
    ) -> list[tuple[str, tuple[int, int, int]]]:
        """Collect active status and cheat badges with styling colors."""
        badges: list[tuple[str, tuple[int, int, int]]] = []
        if state.is_paused():
            badges.append(("[PAUSED]", Colors.BLINKY_RED))
        if not level:
            return badges
        player = level.get_player()
        if player and player.is_invincible():
            badges.append(("[INVINCIBLE]", Colors.YELLOW))
        ghosts = level.get_ghosts()
        if ghosts and any(g.is_frozen() for g in ghosts):
            badges.append(("[FROZEN]", Colors.INKY_CYAN))
        if player and player.get_speed() > 1.0:
            badges.append(("[SPEED 2x]", Colors.GREEN))
        return badges

    def _render_active_badges(
        self,
        surface: pygame.Surface,
        state: GameState,
        level: Any,
        hx: int,
        w: int,
    ) -> None:
        """Render active mode badges in a centered, non-overlapping row."""
        badges = self._get_active_badges(state, level)
        if not badges or not self._font:
            return
        gap = 14
        widths = [self._font.size(text)[0] for text, _ in badges]
        total_w = sum(widths) + (gap + 12) * (len(badges) - 1)
        curr_x = hx + (w - total_w) // 2
        for (text, color), b_w in zip(badges, widths):
            self._render_badge_capsule(
                surface, curr_x - 6, 88, b_w + 12, 22, color
            )
            self._render_text(surface, curr_x, 91, color, text)
            curr_x += b_w + gap + 12

    def _render_badge_capsule(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        w: int,
        h: int,
        color: tuple[int, int, int],
    ) -> None:
        """Render rounded glowing pill capsule for an active badge."""
        cap = pygame.Surface((w, h), pygame.SRCALPHA)
        cap.fill((10, 16, 34, 210))
        pygame.draw.rect(cap, color, (0, 0, w, h), 1, border_radius=5)
        surface.blit(cap, (x, y))

    def _render_lives(
        self, surface: pygame.Surface, x: int, y: int, lives: int
    ) -> None:
        """Render lives label, pixel heart icon, and multiplier count."""
        self._render_text(surface, x, y, Colors.HUD_TEXT, "LIVES:")
        if self._heart_surf:
            surface.blit(self._heart_surf, (x + 68, y + 2))
        self._render_text(surface, x + 85, y, Colors.YELLOW, f"x{lives}")

    def render_mission_intro(
        self, level: Any, surface: pygame.Surface | None = None
    ) -> None:
        """Render 10-second mission briefing overlay card with enlarged question."""
        target = surface or self._surface
        if not target or not level or not hasattr(level, "get_mission"):
            return
        mission = level.get_mission()
        if not mission:
            return
        sw, sh = target.get_size()
        dim_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
        dim_surf.fill((5, 10, 24, 225))
        target.blit(dim_surf, (0, 0))
        cw, ch = min(740, sw - 40), 450
        cx, cy = (sw - cw) // 2, max(20, (sh - ch) // 2 - 20)
        self._draw_intro_card_bg(target, cx, cy, cw, ch)
        self._render_intro_content(target, mission, level, cx, cy, cw)

    def _draw_intro_card_bg(
        self, surf: pygame.Surface, x: int, y: int, w: int, h: int
    ) -> None:
        """Draw illuminated tech modal background for intro card."""
        card = pygame.Surface((w, h), pygame.SRCALPHA)
        card.fill((12, 20, 48, 245))
        pygame.draw.rect(
            card, Colors.GOLD, (0, 0, w, h), 3, border_radius=14
        )
        pygame.draw.rect(
            card,
            Colors.NEON_CYAN,
            (4, 4, w - 8, h - 8),
            1,
            border_radius=12,
        )
        surf.blit(card, (x, y))

    def _render_intro_content(
        self,
        surf: pygame.Surface,
        mission: Any,
        level: Any,
        cx: int,
        cy: int,
        cw: int,
    ) -> None:
        """Render text, targets, traps, and countdown timer in intro card."""
        cd = int(math.ceil(level.get_intro_timer()))
        self._render_intro_headers(surf, mission, cx, cy, cw)
        self._render_intro_examples(surf, mission, cx, cy + 185)
        self._render_intro_timer_bar(surf, level, cd, cx, cy + 325, cw)

    def _render_intro_headers(
        self, surf: pygame.Surface, mission: Any, cx: int, cy: int, cw: int
    ) -> None:
        """Render level title and prominent highlighted question in modal card."""
        f_title = self._title_font or self._font
        f_prompt = self._prompt_font or self._big_font or self._font
        f_body = self._font
        if not f_title or not f_body or not f_prompt:
            return
        title_str = format_arabic(
            f"المرحلة {mission._level_num}: {mission.get_title()}"
        )
        t_s = f_title.render(title_str, True, Colors.NEON_CYAN)
        if t_s.get_width() > cw - 40:
            scale = (cw - 40) / t_s.get_width()
            t_s = pygame.transform.smoothscale(
                t_s, (int(t_s.get_width() * scale), int(t_s.get_height() * scale))
            )
        surf.blit(t_s, t_s.get_rect(center=(cx + cw // 2, cy + 30)))

        # Highlighted Question Box with Golden Glowing Frame
        bw, bh = cw - 60, 80
        bx, by = cx + 30, cy + 58
        q_box = pygame.Surface((bw, bh), pygame.SRCALPHA)
        q_box.fill((18, 35, 78, 245))
        pygame.draw.rect(q_box, Colors.GOLD, (0, 0, bw, bh), 2, border_radius=10)
        surf.blit(q_box, (bx, by))

        prompt_str = format_arabic(mission.get_prompt())
        p_s = f_prompt.render(prompt_str, True, Colors.GOLD)
        if p_s.get_width() > bw - 24:
            scale = (bw - 24) / p_s.get_width()
            p_s = pygame.transform.smoothscale(
                p_s, (int(p_s.get_width() * scale), int(p_s.get_height() * scale))
            )
        surf.blit(p_s, p_s.get_rect(center=(bx + bw // 2, by + bh // 2)))

        info = format_arabic(
            f"التقط جميع الأهداف المطابقة ({mission.get_needed_count()}) للتقدم للمرحلة التالية!"
        )
        i_s = f_body.render(info, True, Colors.WHITE)
        if i_s.get_width() > cw - 40:
            scale = (cw - 40) / i_s.get_width()
            i_s = pygame.transform.smoothscale(
                i_s, (int(i_s.get_width() * scale), int(i_s.get_height() * scale))
            )
        surf.blit(i_s, i_s.get_rect(center=(cx + cw // 2, cy + 154)))

    def _render_intro_examples(
        self, surf: pygame.Surface, mission: Any, cx: int, cy: int
    ) -> None:
        """Render target and trap examples centered inside intro card."""
        f_ex = self._banner_font or self._font
        if not f_ex:
            return
        cw = 740
        tg = ",  ".join(mission.get_targets()[:5])
        tr = ",  ".join(mission.get_traps()[:4])
        t_str = f"الأهداف (+100):  {tg}"
        e_str = f"الفخاخ  (-30):   {tr}"

        t_surf = f_ex.render(format_arabic(t_str), True, Colors.GREEN)
        if t_surf.get_width() > cw - 60:
            scale = (cw - 60) / t_surf.get_width()
            t_surf = pygame.transform.smoothscale(
                t_surf, (int(t_surf.get_width() * scale), int(t_surf.get_height() * scale))
            )
        surf.blit(t_surf, t_surf.get_rect(center=(cx + cw // 2, cy + 10)))

        e_surf = f_ex.render(format_arabic(e_str), True, Colors.BLINKY_RED)
        if e_surf.get_width() > cw - 60:
            scale = (cw - 60) / e_surf.get_width()
            e_surf = pygame.transform.smoothscale(
                e_surf, (int(e_surf.get_width() * scale), int(e_surf.get_height() * scale))
            )
        surf.blit(e_surf, e_surf.get_rect(center=(cx + cw // 2, cy + 44)))

        hint = "الملاذ الآمن: لا يمكن للأشباح دخول شعار المنتصف!"
        h_surf = self._font.render(format_arabic(hint), True, Colors.INKY_CYAN) if self._font else None
        if h_surf:
            if h_surf.get_width() > cw - 60:
                scale = (cw - 60) / h_surf.get_width()
                h_surf = pygame.transform.smoothscale(
                    h_surf, (int(h_surf.get_width() * scale), int(h_surf.get_height() * scale))
                )
            surf.blit(h_surf, h_surf.get_rect(center=(cx + cw // 2, cy + 78)))

    def _render_intro_timer_bar(
        self, surf: pygame.Surface, level: Any, cd: int, cx: int, cy: int, cw: int
    ) -> None:
        """Render countdown and skip prompt on intro card with anti-skip protection."""
        f_big = self._big_font or self._font
        f_sub = self._font
        if not f_big or not f_sub:
            return
        cd_str = format_arabic(f"تبدأ المرحلة خلال: {cd} ثوانٍ")
        c_surf = f_big.render(cd_str, True, Colors.GOLD)
        surf.blit(c_surf, c_surf.get_rect(center=(cx + cw // 2, cy + 18)))

        can_skip = hasattr(level, "can_skip_intro") and level.can_skip_intro()
        if can_skip:
            hint = format_arabic("[ اضغط المسافة أو ENTER للبدء فوراً ]")
            h_color = Colors.NEON_YELLOW
        else:
            hint = format_arabic("[ اقرأ السؤال والأهداف جيداً قبل الانطلاق ]")
            h_color = (180, 205, 235)
        h_surf = f_sub.render(hint, True, h_color)
        surf.blit(h_surf, h_surf.get_rect(center=(cx + cw // 2, cy + 54)))

    def cleanup(self) -> None:
        """Release HUD resources."""
        self._heart_surf = None
