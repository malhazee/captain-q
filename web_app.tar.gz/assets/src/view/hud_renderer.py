"""HUD rendering module displaying score, lives, level, and timer."""

import math
from typing import Any
import pygame
from src.model.game_state import GameState
from src.view.colors import Colors
from src.utils.arabic import format_arabic, get_ui_font


class HudRenderer:
    """Renders the in-game heads-up display overlay."""

    def __init__(self, target_surface: pygame.Surface | None = None) -> None:
        """Initialize HudRenderer with Pygame surface."""
        self._surface: pygame.Surface | None = target_surface
        self._font: pygame.font.Font | None = None
        self._title_font: pygame.font.Font | None = None
        self._big_font: pygame.font.Font | None = None
        self._heart_surf: pygame.Surface | None = None
        self._init_font()
        self._init_heart_image()

    def set_surface(self, target_surface: pygame.Surface | None) -> None:
        """Update the rendering target surface."""
        self._surface = target_surface

    def set_window(self, win_ptr: Any) -> None:
        """Compatibility shim for window/surface updates."""
        if isinstance(win_ptr, pygame.Surface):
            self._surface = win_ptr

    def _init_font(self) -> None:
        """Initialize Pygame font for HUD text."""
        try:
            self._font = get_ui_font(16, bold=True)
            self._title_font = get_ui_font(20, bold=True)
            self._big_font = get_ui_font(30, bold=True)
        except Exception:
            self._font = None
            self._title_font = None
            self._big_font = None

    def _init_heart_image(self) -> None:
        """Create and cache a small heart icon surface."""
        try:
            surf = pygame.Surface((11, 9), pygame.SRCALPHA)
            rows = (
                " 0110 0110 ", "11111111111", "11111111111", "11111111111",
                " 111111111 ", "  1111111  ", "   11111   ", "    111    ",
                "     1     ",
            )
            for dy, row in enumerate(rows):
                for dx, ch in enumerate(row):
                    if ch == "1":
                        surf.set_at((dx, dy), Colors.BLINKY_RED)
            self._heart_surf = surf
        except Exception:
            self._heart_surf = None

    def _render_text(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        color: tuple[int, int, int],
        text: str,
    ) -> None:
        """Draw string on the Pygame surface."""
        if not self._font:
            return
        formatted = format_arabic(text)
        txt_surf = self._font.render(formatted, True, color)
        surface.blit(txt_surf, (x, y))

    def render_hud(
        self,
        state: GameState,
        maze_w: int = 420,
        win_w: int = 780,
        surface: pygame.Surface | None = None,
    ) -> None:
        """Render in-game HUD score header and active status badges."""
        target = surface or self._surface
        if not target:
            return
        w = max(420, maze_w)
        hx = max(10, (win_w - w) // 2)
        self._render_top_bar(target, state, hx, w)
        self._render_mission_banner(target, state.get_level(), hx, w)
        self._render_active_badges(target, state, state.get_level(), hx, w)

    def _render_mission_banner(
        self, target: pygame.Surface, level: Any, hx: int, w: int
    ) -> None:
        """Render active curriculum mission prompt and goal counter."""
        if not level or not hasattr(level, "get_mission") or not self._font:
            return
        m = level.get_mission()
        if not m:
            return
        bar = pygame.Surface((w + 20, 24), pygame.SRCALPHA)
        bar.fill((16, 26, 56, 220))
        pygame.draw.rect(
            bar, Colors.NEON_YELLOW, (0, 0, w + 20, 24), 1, border_radius=6
        )
        target.blit(bar, (hx - 10, 50))
        txt = format_arabic(
            f"الهدف: {m.get_prompt()}  "
            f"[{m.get_collected_count()}/{m.get_needed_count()}]"
        )
        t_surf = self._font.render(txt, True, Colors.NEON_YELLOW)
        target.blit(t_surf, t_surf.get_rect(center=(hx + w // 2, 62)))

    def _render_top_bar(
        self, target: pygame.Surface, state: GameState, hx: int, w: int
    ) -> None:
        """Render score, lives, current level, and remaining time on HUD."""
        self._draw_hud_cockpit_bar(target, hx - 10, 12, w + 20, 34)
        lvl = state.get_level()
        sc = state.get_score().get_score()
        liv = lvl.get_player().get_lives() if lvl else 0
        rem = int(lvl.get_time_remaining()) if lvl else 0
        self._render_text(target, hx + 10, 20, Colors.GOLD, f"SCORE: {sc}")
        self._render_lives(target, hx + int(w * 0.28), 20, liv)
        self._render_text(
            target, hx + int(w * 0.58), 20, Colors.NEON_CYAN,
            f"LEVEL: {state.get_level_number()}"
        )
        t_color = Colors.BLINKY_RED if rem < 15 else Colors.WHITE
        self._render_text(
            target, hx + w - 95, 20, t_color, f"TIME: {rem}s"
        )

    def _draw_hud_cockpit_bar(
        self, surface: pygame.Surface, x: int, y: int, w: int, h: int
    ) -> None:
        """Draw high-tech translucent cockpit glass frame for HUD."""
        bar = pygame.Surface((w, h), pygame.SRCALPHA)
        bar.fill((10, 16, 36, 215))
        pygame.draw.rect(
            bar, Colors.GLASS_BORDER, (0, 0, w, h), 1, border_radius=8
        )
        surface.blit(bar, (x, y))

    def _get_active_badges(
        self, state: GameState, level: Any
    ) -> list[tuple[str, tuple[int, int, int]]]:
        """Collect active status and cheat badges with styling colors."""
        badges: list[tuple[str, tuple[int, int, int]]] = []
        if state.is_paused():
            badges.append(("[PAUSED]", Colors.BLINKY_RED))
        if not level:
            return badges
        player = level.get_player()
        if player and player.is_invincible():
            badges.append(("[INVINCIBLE]", Colors.YELLOW))
        ghosts = level.get_ghosts()
        if ghosts and any(g.is_frozen() for g in ghosts):
            badges.append(("[FROZEN]", Colors.INKY_CYAN))
        if player and player.get_speed() > 1.0:
            badges.append(("[SPEED 2x]", Colors.GREEN))
        return badges

    def _render_active_badges(
        self,
        surface: pygame.Surface,
        state: GameState,
        level: Any,
        hx: int,
        w: int,
    ) -> None:
        """Render active mode badges in a centered, non-overlapping row."""
        badges = self._get_active_badges(state, level)
        if not badges or not self._font:
            return
        gap = 14
        widths = [self._font.size(text)[0] for text, _ in badges]
        total_w = sum(widths) + (gap + 12) * (len(badges) - 1)
        curr_x = hx + (w - total_w) // 2
        for (text, color), b_w in zip(badges, widths):
            self._render_badge_capsule(
                surface, curr_x - 6, 50, b_w + 12, 22, color
            )
            self._render_text(surface, curr_x, 53, color, text)
            curr_x += b_w + gap + 12

    def _render_badge_capsule(
        self,
        surface: pygame.Surface,
        x: int,
        y: int,
        w: int,
        h: int,
        color: tuple[int, int, int],
    ) -> None:
        """Render rounded glowing pill capsule for an active badge."""
        cap = pygame.Surface((w, h), pygame.SRCALPHA)
        cap.fill((10, 16, 34, 210))
        pygame.draw.rect(cap, color, (0, 0, w, h), 1, border_radius=5)
        surface.blit(cap, (x, y))

    def _render_lives(
        self, surface: pygame.Surface, x: int, y: int, lives: int
    ) -> None:
        """Render lives label, pixel heart icon, and multiplier count."""
        self._render_text(surface, x, y, Colors.HUD_TEXT, "LIVES:")
        if self._heart_surf:
            surface.blit(self._heart_surf, (x + 68, y + 2))
        self._render_text(surface, x + 85, y, Colors.YELLOW, f"x{lives}")

    def render_mission_intro(
        self, level: Any, surface: pygame.Surface | None = None
    ) -> None:
        """Render 10-second mission briefing overlay card."""
        target = surface or self._surface
        if not target or not level or not hasattr(level, "get_mission"):
            return
        mission = level.get_mission()
        if not mission:
            return
        sw, sh = target.get_size()
        dim_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
        dim_surf.fill((5, 10, 24, 215))
        target.blit(dim_surf, (0, 0))
        cw, ch = min(660, sw - 40), 340
        cx, cy = (sw - cw) // 2, (sh - ch) // 2
        self._draw_intro_card_bg(target, cx, cy, cw, ch)
        self._render_intro_content(target, mission, level, cx, cy, cw)

    def _draw_intro_card_bg(
        self, surf: pygame.Surface, x: int, y: int, w: int, h: int
    ) -> None:
        """Draw illuminated tech modal background for intro card."""
        card = pygame.Surface((w, h), pygame.SRCALPHA)
        card.fill((12, 20, 44, 245))
        pygame.draw.rect(
            card, Colors.NEON_CYAN, (0, 0, w, h), 3, border_radius=12
        )
        pygame.draw.rect(
            card,
            Colors.GLASS_BORDER,
            (4, 4, w - 8, h - 8),
            1,
            border_radius=10,
        )
        surf.blit(card, (x, y))

    def _render_intro_content(
        self,
        surf: pygame.Surface,
        mission: Any,
        level: Any,
        cx: int,
        cy: int,
        cw: int,
    ) -> None:
        """Render text, targets, traps, and countdown timer in intro card."""
        cd = int(math.ceil(level.get_intro_timer()))
        self._render_intro_headers(surf, mission, cx, cy, cw)
        self._render_intro_examples(surf, mission, cx, cy + 124)
        self._render_intro_timer_bar(surf, cd, cx, cy + 245, cw)

    def _render_intro_headers(
        self, surf: pygame.Surface, mission: Any, cx: int, cy: int, cw: int
    ) -> None:
        """Render level title and mission prompt in modal card."""
        f_title = self._title_font or self._font
        f_body = self._font
        if not f_title or not f_body:
            return
        title_str = format_arabic(
            f"المرحلة {mission._level_num}: {mission.get_title()}"
        )
        t_s = f_title.render(title_str, True, Colors.NEON_YELLOW)
        surf.blit(t_s, t_s.get_rect(center=(cx + cw // 2, cy + 32)))
        prompt_str = format_arabic(mission.get_prompt())
        p_s = f_body.render(prompt_str, True, Colors.WHITE)
        surf.blit(p_s, p_s.get_rect(center=(cx + cw // 2, cy + 68)))
        info = format_arabic(
            f"التقط جميع الأهداف ({mission.get_needed_count()}) للتقدم!"
        )
        i_s = f_body.render(info, True, Colors.NEON_CYAN)
        surf.blit(i_s, i_s.get_rect(center=(cx + cw // 2, cy + 96)))

    def _render_intro_examples(
        self, surf: pygame.Surface, mission: Any, cx: int, cy: int
    ) -> None:
        """Render target and trap examples for mission intro."""
        if not self._font:
            return
        tg = ", ".join(mission.get_targets()[:4])
        tr = ", ".join(mission.get_traps()[:4])
        t_str = f"الأهداف (+100):  {tg}"
        e_str = f"الفخاخ  (-30):   {tr}"
        self._render_text(surf, cx + 40, cy, Colors.GREEN, t_str)
        self._render_text(surf, cx + 40, cy + 32, Colors.BLINKY_RED, e_str)
        hint = "الملاذ الآمن: لا يمكن للأشباح دخول شعار المنتصف!"
        self._render_text(surf, cx + 40, cy + 64, Colors.INKY_CYAN, hint)

    def _render_intro_timer_bar(
        self, surf: pygame.Surface, cd: int, cx: int, cy: int, cw: int
    ) -> None:
        """Render countdown and skip prompt on intro card."""
        f_big = self._big_font or self._font
        f_sub = self._font
        if not f_big or not f_sub:
            return
        cd_str = format_arabic(f"تبدأ المرحلة خلال: {cd} ثوانٍ")
        c_surf = f_big.render(cd_str, True, Colors.GOLD)
        surf.blit(c_surf, c_surf.get_rect(center=(cx + cw // 2, cy + 18)))
        hint = format_arabic("[ اضغط المسافة أو ENTER للبدء فوراً ]")
        h_surf = f_sub.render(hint, True, Colors.HUD_TEXT)
        surf.blit(h_surf, h_surf.get_rect(center=(cx + cw // 2, cy + 55)))

    def cleanup(self) -> None:
        """Release HUD resources."""
        self._heart_surf = None
