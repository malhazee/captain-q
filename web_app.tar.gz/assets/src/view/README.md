# View Layer (Frontend Architecture)

The `src/view/` package handles all visual rendering and UI presentation using the **Pygame-CE** graphics library.

## Modules Summary

### 1. `colors.py` (`Colors`)
- Defines standard RGB tuple color values for maze walls, pellets, ghosts, and text overlays.

### 2. `sprite_manager.py` (`SpriteManager`)
- Preloads, caches, and manages PNG sprite surfaces via Pygame.
- Manages 12 directional Pac-Man animation frames, 5 ghost sprites, and bonus items.
- Provides fallback rendering if an asset file is unavailable.

### 3. `animation.py` (`AnimationManager`)
- Drives timed 3-frame sprite cycles for Pac-Man's opening and closing mouth.

### 4. `maze_renderer.py` (`MazeRenderer`)
- Renders blue maze walls, central "42" obstacle blocks, pacgums, and super-pacgums.
- Pre-bakes high-tech metallic floor tiles (`floor_tile.png`) across all walkable corridors.
- Draws outer glowing cyber bezel around maze boundaries with neon cyan accents.

### 5. `hud_renderer.py` (`HudRenderer`)
- Draws translucent glass cockpit bar with gold score, cyan level, and live timer.
- Renders active cheat modes as glowing pill badge capsules (`[INVINCIBLE]`, `[FROZEN]`, etc.) without text overlap.

### 6. `menu_renderer.py` (`MenuRenderer`)
- Draws modern glassmorphic menus and screens:
  - Main Menu with full-bleed cached wallpaper, cyber buttons, and active neon hover states
  - Pause Menu modal with translucent glass backdrop
  - Game Over and Victory screens with tech-styled name entry prompt
  - Top 10 Highscore leaderboard with gold/silver/bronze badges
  - Interactive instructions and controls guide

### 7. `sound_manager.py` (`SoundManager`)
- Manages all audio playback, background music cycling, and sound effects via `pygame.mixer`.
- Alternates `in_game_1.mp3` and `in_game_2.mp3` continuously during gameplay.
- Manages priority sound cues for super-pacgum chase, invincible mode loop, eating ghosts, victory fanfares, and defeat music.
- Fail-safe architecture preventing crashes in headless or mute environments.

### 8. `renderer.py` (`Renderer`)
- Composite facade delegating drawing and audio operations based on `GameState.get_state()`.
- Renders atmospheric retro-futuristic arcade hall backdrop during gameplay and modal states.
