"""Persistent highscore manager maintaining top 10 player records."""

import json
import os
import re
from typing import Any
from src.utils.json_parser import parse_json_with_comments


class HighscoreManager:
    """Manages loading, updating, and saving top 10 high scores."""

    MAX_ENTRIES = 10
    MAX_NAME_LENGTH = 25

    def __init__(self, filepath: str = "highscores.json") -> None:
        """Initialize manager with target JSON persistence path.

        Args:
            filepath: Path to the highscores file.
        """
        self._filepath: str = filepath
        self._scores: list[dict[str, Any]] = []
        self.load()

    def get_scores(self) -> list[dict[str, Any]]:
        """Return shallow copy of current top scores."""
        return [dict(entry) for entry in self._scores]

    def is_valid_name(self, name: str) -> bool:
        """Verify name is non-empty, <= 25 chars, alphanumeric and spaces.

        Args:
            name: Candidate player name.

        Returns:
            True if valid, False otherwise.
        """
        if not name or len(name) > self.MAX_NAME_LENGTH:
            return False
        return bool(re.match(r"^[A-Za-z0-9 _\-\u0600-\u06FF]+$", name))

    def sanitize_name(self, name: str) -> str:
        """Sanitize name to valid format with fallback to 'طالب متميز'."""
        cleaned = re.sub(r"[^A-Za-z0-9 _\-\u0600-\u06FF]", "", name).strip()
        if not cleaned:
            return "طالب متميز"
        return cleaned[: self.MAX_NAME_LENGTH]

    def is_highscore(self, score: int) -> bool:
        """Check if score qualifies for the top 10 leaderboard."""
        if score <= 0:
            return False
        if len(self._scores) < self.MAX_ENTRIES:
            return True
        return bool(score > int(self._scores[-1]["score"]))

    def add_score(self, name: str, score: int) -> bool:
        """Add record if it qualifies for top 10 and save to file.

        Args:
            name: Player nickname.
            score: Final accumulated points.

        Returns:
            True if saved to leaderboard, False if not high enough.
        """
        if not self.is_highscore(score):
            return False
        valid_name = self.sanitize_name(name)
        self._scores.append({"name": valid_name, "score": score})
        self._scores.sort(key=lambda item: item["score"], reverse=True)
        self._scores = self._scores[: self.MAX_ENTRIES]
        self.save()
        return True

    def load(self) -> None:
        """Load and sanitize leaderboard entries from disk."""
        if not os.path.exists(self._filepath):
            self._scores = []
            return
        data = parse_json_with_comments(self._filepath)
        raw_list = data.get("highscores", [])
        if not isinstance(raw_list, list):
            self._scores = []
            return
        sanitized: list[dict[str, Any]] = []
        for item in raw_list:
            if isinstance(item, dict) and "name" in item and "score" in item:
                if isinstance(item["score"], int) and item["score"] >= 0:
                    sanitized.append({
                        "name": self.sanitize_name(str(item["name"])),
                        "score": item["score"],
                    })
        sanitized.sort(key=lambda s: s["score"], reverse=True)
        self._scores = sanitized[: self.MAX_ENTRIES]

    def save(self) -> None:
        """Persist current top 10 records safely using context manager."""
        try:
            payload = {"highscores": self._scores}
            with open(self._filepath, "w", encoding="utf-8") as file_handle:
                json.dump(payload, file_handle, indent=2)
        except (OSError, PermissionError) as write_error:
            print(f"Warning: Could not save highscores: {write_error}")
