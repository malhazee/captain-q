"""Floating text feedback model for in-game score notifications."""

from dataclasses import dataclass


@dataclass
class FloatingText:
    """Represents a temporary floating text popup rendered above a cell."""

    text: str
    grid_x: int
    grid_y: int
    color: tuple[int, int, int]
    lifetime: float = 0.9
    max_lifetime: float = 0.9

    def update(self, delta_time: float) -> bool:
        """Decrease remaining lifetime and return True if still active."""
        self.lifetime -= delta_time
        return self.lifetime > 0.0

    def get_progress(self) -> float:
        """Return 0.0 to 1.0 progress from spawn to expiration."""
        return max(0.0, min(1.0, 1.0 - (self.lifetime / self.max_lifetime)))
