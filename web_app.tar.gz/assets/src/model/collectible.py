"""Collectible management for regular pacgums and math tiles."""

from src.model.maze import Maze
from src.model.math_mission import MathTile, MathMission


class CollectibleManager:
    """Tracks and manages remaining pacgums and math tiles on the board."""

    def __init__(self) -> None:
        """Initialize empty sets for regular and super pacgum items."""
        self._pacgums: set[tuple[int, int]] = set()
        self._super_pacgums: set[tuple[int, int]] = set()
        self._math_tiles: dict[tuple[int, int], MathTile] = {}
        self._total_count: int = 0

    def populate_from_maze(
        self,
        maze: Maze,
        corners: list[tuple[int, int]],
        max_dots: int | None = None,
        mission: MathMission | None = None,
    ) -> None:
        """Populate pacgums, corner super pacgums, and math tiles."""
        self._super_pacgums = set(corners)
        self._math_tiles.clear()
        center = maze.get_center()
        valid = [
            p for p in sorted(maze.get_corridors())
            if p not in self._super_pacgums
            and p != center
            and not (hasattr(maze, "is_sanctuary") and maze.is_sanctuary(*p))
        ]

        self._select_dots(valid, max_dots)
        if mission:
            self._assign_math_tiles(mission)
        self._total_count = len(self._pacgums) + len(self._super_pacgums)

    def _select_dots(
        self, valid: list[tuple[int, int]], max_dots: int | None
    ) -> None:
        """Filter corridor points down to max_dots."""
        if max_dots is not None and 0 <= max_dots < len(valid):
            step = len(valid) / max_dots if max_dots > 0 else 1.0
            chosen = [valid[int(i * step)] for i in range(max_dots)]
            self._pacgums = set(chosen)
        else:
            self._pacgums = set(valid)

    def _select_spaced_positions(
        self, candidates: list[tuple[int, int]], count: int
    ) -> list[tuple[int, int]]:
        """Select positions maximizing minimum distance between tiles."""
        if not candidates or count <= 0:
            return []
        chosen = [candidates[0]]
        while len(chosen) < count:
            best_pos = None
            best_dist = -1
            for pos in candidates:
                if pos in chosen:
                    continue
                min_d = min(
                    abs(pos[0] - c[0]) + abs(pos[1] - c[1]) for c in chosen
                )
                if min_d > best_dist:
                    best_dist = min_d
                    best_pos = pos
            if not best_pos:
                break
            chosen.append(best_pos)
        return chosen

    def _assign_math_tiles(self, mission: MathMission) -> None:
        """Distribute curriculum math tiles over selected pacgum cells."""
        dots_list = sorted(self._pacgums)
        num_tiles = min(10, len(dots_list))
        pool = mission.generate_tile_pool(num_tiles)
        positions = self._select_spaced_positions(dots_list, len(pool))
        for pos, tile in zip(positions, pool):
            self._math_tiles[pos] = tile
        targets_placed = sum(
            1 for t in self._math_tiles.values() if t.is_target
        )
        mission.set_needed_count(targets_placed)

    def has_pacgum_at(self, x: int, y: int) -> bool:
        """Check if an uneaten regular pacgum exists at (x, y)."""
        return (x, y) in self._pacgums

    def consume_pacgum(self, x: int, y: int) -> bool:
        """Eat regular pacgum at (x, y) if present."""
        if (x, y) in self._pacgums:
            self._pacgums.remove((x, y))
            return True
        return False

    def consume_math_tile(self, x: int, y: int) -> MathTile | None:
        """Eat and return MathTile at (x, y) if present."""
        return self._math_tiles.pop((x, y), None)

    def get_math_tile_at(self, x: int, y: int) -> MathTile | None:
        """Return MathTile at (x, y) without consuming."""
        return self._math_tiles.get((x, y))

    def get_all_math_tiles(self) -> dict[tuple[int, int], MathTile]:
        """Return copy of active math tiles."""
        return dict(self._math_tiles)

    def has_super_pacgum_at(self, x: int, y: int) -> bool:
        """Check if an uneaten super pacgum exists at (x, y)."""
        return (x, y) in self._super_pacgums

    def consume_super_pacgum(self, x: int, y: int) -> bool:
        """Eat super pacgum at (x, y) if present."""
        if (x, y) in self._super_pacgums:
            self._super_pacgums.remove((x, y))
            return True
        return False

    def get_remaining_count(self) -> int:
        """Return total number of remaining items to eat."""
        return len(self._pacgums) + len(self._super_pacgums)

    def is_cleared(self) -> bool:
        """Return True when all pacgums have been collected."""
        return self.get_remaining_count() == 0

    def get_pacgums(self) -> set[tuple[int, int]]:
        """Return shallow copy of all regular pacgum positions."""
        return set(self._pacgums)

    def get_super_pacgums(self) -> set[tuple[int, int]]:
        """Return shallow copy of all super pacgum positions."""
        return set(self._super_pacgums)
