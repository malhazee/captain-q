"""Strategy pattern implementations for distinct ghost navigation AI."""

from abc import ABC, abstractmethod
from src.model.direction import Direction
from src.model.maze import Maze
from src.utils.pathfinding import find_shortest_path_bfs


class GhostBehavior(ABC):
    """Abstract Strategy defining ghost target calculation and movement."""

    @abstractmethod
    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Compute the target cell for the ghost navigation.

        Args:
            ghost_pos: Current position of the ghost.
            player_pos: Current position of the player.
            player_dir: Facing direction of the player.
            corner_pos: Home corner assigned to this ghost.

        Returns:
            Coordinates (tx, ty) the ghost attempts to reach.
        """
        pass

    def select_best_direction(
        self,
        current_pos: tuple[int, int],
        target_pos: tuple[int, int],
        current_dir: Direction,
        maze: Maze,
    ) -> Direction:
        """Choose valid direction minimizing path distance to target."""
        valid_dirs = self._get_valid_turns(current_pos, current_dir, maze)
        if not valid_dirs:
            return Direction.NONE
        if maze.is_corridor(*target_pos):
            path = find_shortest_path_bfs(maze, current_pos, target_pos)
            if len(path) >= 2:
                step_dir = self._path_step_to_direction(current_pos, path[1])
                if step_dir in valid_dirs:
                    return step_dir
        return self._find_closest_direction(
            valid_dirs, current_pos, target_pos
        )

    def _path_step_to_direction(
        self, curr: tuple[int, int], nxt: tuple[int, int]
    ) -> Direction:
        """Derive Direction from adjacent grid step."""
        return Direction.from_delta(nxt[0] - curr[0], nxt[1] - curr[1])

    def _find_closest_direction(
        self,
        directions: list[Direction],
        pos: tuple[int, int],
        target: tuple[int, int],
    ) -> Direction:
        """Find candidate direction with smallest squared distance."""
        best_dir = directions[0]
        min_dist = float("inf")
        tx, ty = target
        for direction in directions:
            dx, dy = direction.delta()
            nx, ny = pos[0] + dx, pos[1] + dy
            dist = (nx - tx) ** 2 + (ny - ty) ** 2
            if dist < min_dist:
                min_dist = dist
                best_dir = direction
        return best_dir

    def _get_valid_turns(
        self, pos: tuple[int, int], cur_dir: Direction, maze: Maze
    ) -> list[Direction]:
        """Get open directions, avoiding immediate 180-degree reversal."""
        candidates = [
            Direction.NORTH,
            Direction.EAST,
            Direction.SOUTH,
            Direction.WEST,
        ]
        reverse = cur_dir.opposite()
        chk = getattr(maze, "can_ghost_move", maze.can_move)
        valid = [d for d in candidates if chk(pos[0], pos[1], d)]
        filtered = [d for d in valid if d != reverse]
        return filtered if filtered else valid


class BlinkyBehavior(GhostBehavior):
    """Aggressive pursuit strategy directly targeting player coordinates."""

    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Target the player's exact position."""
        return player_pos


class PinkyBehavior(GhostBehavior):
    """Ambush strategy targeting 4 cells ahead of the player."""

    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Target 4 cells in front of the player's heading."""
        dx, dy = player_dir.delta()
        return (player_pos[0] + dx * 4, player_pos[1] + dy * 4)


class InkyBehavior(GhostBehavior):
    """Flanking strategy targeting intermediate point offset from player."""

    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Target 2 cells ahead of player mirrored with corner."""
        dx, dy = player_dir.delta()
        lead_x = player_pos[0] + dx * 2
        lead_y = player_pos[1] + dy * 2
        return (lead_x * 2 - corner_pos[0], lead_y * 2 - corner_pos[1])


class ClydeBehavior(GhostBehavior):
    """Distance-dependent strategy: chases when far, retreats when close."""

    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Chase if farther than 4 cells or near corner, otherwise retreat."""
        dist_sq = (
            (ghost_pos[0] - player_pos[0]) ** 2
            + (ghost_pos[1] - player_pos[1]) ** 2
        )
        corner_dist_sq = (
            (ghost_pos[0] - corner_pos[0]) ** 2
            + (ghost_pos[1] - corner_pos[1]) ** 2
        )
        if corner_dist_sq <= 4:
            return player_pos
        return player_pos if dist_sq > 16 else corner_pos


class FrightenedBehavior(GhostBehavior):
    """Direct evasion strategy fleeing away from player when edible."""

    def calculate_target(
        self,
        ghost_pos: tuple[int, int],
        player_pos: tuple[int, int],
        player_dir: Direction,
        corner_pos: tuple[int, int],
    ) -> tuple[int, int]:
        """Target projected directly away from player."""
        dx = ghost_pos[0] - player_pos[0]
        dy = ghost_pos[1] - player_pos[1]
        if dx == 0 and dy == 0:
            pdx, pdy = player_dir.delta()
            return (ghost_pos[0] - pdx * 4, ghost_pos[1] - pdy * 4)
        return (ghost_pos[0] + dx * 4, ghost_pos[1] + dy * 4)

    def select_best_direction(
        self,
        current_pos: tuple[int, int],
        target_pos: tuple[int, int],
        current_dir: Direction,
        maze: Maze,
    ) -> Direction:
        """Select valid direction leading directly away from player."""
        valid_dirs = self._get_valid_turns(current_pos, current_dir, maze)
        if not valid_dirs:
            return Direction.NONE
        return self._find_closest_direction(
            valid_dirs, current_pos, target_pos
        )
