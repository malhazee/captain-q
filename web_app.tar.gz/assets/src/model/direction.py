"""Direction enumeration and vector utilities matching maze bitmasks."""

from enum import IntEnum


class Direction(IntEnum):
    """Movement directions encoded with matching maze wall bitmasks."""

    NONE = 0
    NORTH = 1
    EAST = 2
    SOUTH = 4
    WEST = 8

    def opposite(self) -> "Direction":
        """Return the opposite direction for bouncing or reverse paths.

        Returns:
            The opposite Direction enum member.
        """
        opposites = {
            Direction.NORTH: Direction.SOUTH,
            Direction.SOUTH: Direction.NORTH,
            Direction.EAST: Direction.WEST,
            Direction.WEST: Direction.EAST,
            Direction.NONE: Direction.NONE,
        }
        return opposites[self]

    def delta(self) -> tuple[int, int]:
        """Return the grid displacement (dx, dy) for this direction.

        Returns:
            A tuple of (delta_x, delta_y).
        """
        deltas = {
            Direction.NORTH: (0, -1),
            Direction.SOUTH: (0, 1),
            Direction.EAST: (1, 0),
            Direction.WEST: (-1, 0),
            Direction.NONE: (0, 0),
        }
        return deltas[self]

    @classmethod
    def from_delta(cls, dx: int, dy: int) -> "Direction":
        """Convert a coordinate displacement (dx, dy) to Direction.

        Args:
            dx: Horizontal displacement (-1, 0, or 1).
            dy: Vertical displacement (-1, 0, or 1).

        Returns:
            The corresponding Direction enum member, or Direction.NONE.
        """
        mapping = {
            (0, -1): cls.NORTH,
            (0, 1): cls.SOUTH,
            (1, 0): cls.EAST,
            (-1, 0): cls.WEST,
        }
        return mapping.get((dx, dy), cls.NONE)
