"""Player entity model managing position, lives, and smooth movement."""

from src.model.direction import Direction
from src.model.maze import Maze


class Player:
    """Represents player Pacman character with smooth movement."""

    BASE_SPEED: float = 60.0 / 28.0

    def __init__(
        self, start_x: int, start_y: int, lives: int = 3
    ) -> None:
        """Initialize Player with starting location and lives count."""
        self._start_x: int = start_x
        self._start_y: int = start_y
        self._x: int = start_x
        self._y: int = start_y
        self._target_x: int = start_x
        self._target_y: int = start_y
        self._progress: float = 0.0
        self._lives: int = max(0, lives)
        self._direction: Direction = Direction.NONE
        self._next_direction: Direction = Direction.NONE
        self._facing_direction: Direction = Direction.EAST
        self._speed: float = 1.0
        self._invincible: bool = False

    def get_position(self) -> tuple[int, int]:
        """Return closest integer grid coordinate (x, y)."""
        rx, ry = self.get_render_position()
        return (round(rx), round(ry))

    def get_render_position(self) -> tuple[float, float]:
        """Return exact sub-tile coordinates for smooth rendering."""
        if self._progress <= 0.0 or self._direction == Direction.NONE:
            return (float(self._x), float(self._y))
        dx, dy = self._direction.delta()
        return (
            self._x + dx * self._progress,
            self._y + dy * self._progress,
        )

    def set_position(self, x: int, y: int) -> None:
        """Set player grid coordinate and reset transition progress."""
        self._x = x
        self._y = y
        self._target_x = x
        self._target_y = y
        self._progress = 0.0

    def get_direction(self) -> Direction:
        """Return current movement direction."""
        return self._direction

    def get_facing_direction(self) -> Direction:
        """Return persistent orientation for sprite rendering."""
        return self._facing_direction

    def set_direction(self, direction: Direction) -> None:
        """Set current direction and update orientation."""
        self._direction = direction
        if direction != Direction.NONE:
            self._facing_direction = direction

    def get_next_direction(self) -> Direction:
        """Return buffered input direction."""
        return self._next_direction

    def set_next_direction(self, direction: Direction) -> None:
        """Buffer next desired direction from user input."""
        self._next_direction = direction

    def get_lives(self) -> int:
        """Return current remaining lives count."""
        return self._lives

    def set_lives(self, lives: int) -> None:
        """Update player lives count."""
        self._lives = max(0, lives)

    def lose_life(self) -> bool:
        """Deduct one life if not invincible."""
        if not self._invincible and self._lives > 0:
            self._lives -= 1
        return self._lives > 0

    def add_life(self) -> None:
        """Grant an extra life to the player."""
        self._lives += 1

    def is_alive(self) -> bool:
        """Check if player has remaining lives."""
        return self._lives > 0

    def is_invincible(self) -> bool:
        """Return whether invincibility cheat is active."""
        return self._invincible

    def set_invincible(self, status: bool) -> None:
        """Toggle invincibility cheat status."""
        self._invincible = status

    def get_speed(self) -> float:
        """Return current movement speed multiplier."""
        return self._speed

    def set_speed(self, speed: float) -> None:
        """Set movement speed multiplier."""
        self._speed = max(0.5, speed)

    def respawn(self) -> None:
        """Reset player position and direction to initial spawn point."""
        self.set_position(self._start_x, self._start_y)
        self._direction = Direction.NONE
        self._next_direction = Direction.NONE

    def move(self, maze: Maze, delta_time: float = 0.0) -> bool:
        """Advance player with sub-tile progression or discrete step."""
        self._check_immediate_reversal()
        self._check_cornering_turn(maze)
        if delta_time <= 0.0:
            return self._discrete_move(maze)
        return self._advance_progress(maze, delta_time)

    def _discrete_move(self, maze: Maze) -> bool:
        """Perform legacy discrete full-tile movement step."""
        moved = self._try_turn(maze) or self._continue_current_direction(maze)
        if moved:
            self._x = self._target_x
            self._y = self._target_y
            self._progress = 0.0
        return moved

    def _advance_progress(self, maze: Maze, delta_time: float) -> bool:
        """Advance fractional movement along active corridor."""
        if self._direction == Direction.NONE:
            if not self._try_turn(maze):
                self._continue_current_direction(maze)
        if self._direction == Direction.NONE:
            return False

        step = self.BASE_SPEED * self._speed * delta_time
        self._progress += step
        if self._progress >= 1.0:
            self._snap_and_pick_next(maze)
        return True

    def _check_immediate_reversal(self) -> bool:
        """Reverse direction immediately if moving and opposite key pressed."""
        if (
            self._progress > 0.0
            and self._direction != Direction.NONE
            and self._next_direction == self._direction.opposite()
        ):
            self._x, self._target_x = self._target_x, self._x
            self._y, self._target_y = self._target_y, self._y
            self._direction = self._next_direction
            self._facing_direction = self._direction
            self._next_direction = Direction.NONE
            self._progress = 1.0 - self._progress
            return True
        return False

    def _check_cornering_turn(self, maze: Maze) -> bool:
        """Allow tight cornering if player left a valid intersection."""
        if (
            0.0 < self._progress <= 0.35
            and self._direction != Direction.NONE
            and self._next_direction != Direction.NONE
            and self._next_direction != self._direction
            and self._next_direction != self._direction.opposite()
            and maze.can_move(self._x, self._y, self._next_direction)
        ):
            self._direction = self._next_direction
            self._facing_direction = self._direction
            self._next_direction = Direction.NONE
            dx, dy = self._direction.delta()
            self._target_x = self._x + dx
            self._target_y = self._y + dy
            self._progress = 0.0
            return True
        return False

    def _snap_and_pick_next(self, maze: Maze) -> None:
        """Snap to target grid tile and evaluate next movement corridor."""
        self._x = self._target_x
        self._y = self._target_y
        self._progress = 0.0
        if not self._try_turn(maze):
            if not self._continue_current_direction(maze):
                self._direction = Direction.NONE

    def _try_turn(self, maze: Maze) -> bool:
        """Attempt to turn into the buffered next direction if path is open."""
        if self._next_direction != Direction.NONE and maze.can_move(
            self._x, self._y, self._next_direction
        ):
            self._direction = self._next_direction
            self._facing_direction = self._direction
            self._next_direction = Direction.NONE
            dx, dy = self._direction.delta()
            self._target_x = self._x + dx
            self._target_y = self._y + dy
            return True
        return False

    def _continue_current_direction(self, maze: Maze) -> bool:
        """Continue moving along current direction if unobstructed."""
        if self._direction != Direction.NONE and maze.can_move(
            self._x, self._y, self._direction
        ):
            self._facing_direction = self._direction
            dx, dy = self._direction.delta()
            self._target_x = self._x + dx
            self._target_y = self._y + dy
            return True
        return False
