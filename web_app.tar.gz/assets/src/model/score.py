"""Score tracking model ensuring non-decreasing score progression."""


class Score:
    """Manages player score accumulation with validation."""

    def __init__(self, initial_score: int = 0) -> None:
        """Initialize Score counter.

        Args:
            initial_score: Starting points (must be >= 0).
        """
        self._score: int = max(0, initial_score)

    def get_score(self) -> int:
        """Return the current non-negative score total."""
        return self._score

    def add_points(self, points: int) -> None:
        """Add points to the score if positive.

        Args:
            points: Amount of points to award.
        """
        if points > 0:
            self._score += points

    def add_pacgum(self, value: int = 10) -> None:
        """Award points for eating a regular pacgum."""
        self.add_points(value)

    def add_super_pacgum(self, value: int = 50) -> None:
        """Award points for eating a super pacgum."""
        self.add_points(value)

    def add_ghost(self, value: int = 200) -> None:
        """Award points for devouring a frightened ghost."""
        self.add_points(value)

    def reset(self) -> None:
        """Reset score total to zero."""
        self._score = 0
