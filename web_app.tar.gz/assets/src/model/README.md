# Model Layer (Backend Architecture)

The `src/model/` package encapsulates all game entities, data structures, state machines, and business rules, strictly decoupled from graphical presentation.

## Modules Summary

### 1. `config.py` (`GameConfig`)
- Parses JSON configuration files supporting hash (`#`) line comments.
- Validates game parameters with safe defaults for missing or out-of-range keys.
- Manages multi-level configuration maps (minimum 10 levels).

### 2. `direction.py` (`Direction`)
- `IntEnum` matching the 4-bit maze wall bitmasks:
  - `NORTH = 1` (bit 0)
  - `EAST = 2` (bit 1)
  - `SOUTH = 4` (bit 2)
  - `WEST = 8` (bit 3)
- Provides coordinate vectors (`delta()`) and opposite directions (`opposite()`).

### 3. `maze.py` (`Maze`)
- Encapsulates the external `mazegenerator.MazeGenerator` package without modifications.
- Generates playable braided mazes (`perfect=False`) containing the central "42" obstacle pattern.
- Offers fast corridor queries, collision tests (`can_move`), and corner/center detection.

### 4. `player.py` (`Player`)
- Models the Pac-Man character: grid coordinates, life pool, buffered movement direction, and speed multiplier.
- Encapsulates cheat-mode invincibility flags and respawn resets.

### 5. `ghost_behavior.py` (`GhostBehavior`)
- Implements the **Strategy Pattern** for autonomous ghost AI navigation:
  - `BlinkyBehavior`: direct aggressive chase.
  - `PinkyBehavior`: ambush targeting 4 cells ahead of player.
  - `InkyBehavior`: tactical flanking targeting vector offset.
  - `ClydeBehavior`: proximity-based territorial evasion / chase.
  - `FrightenedBehavior`: direct evasion fleeing away from player when edible.

### 6. `ghost.py` (`Ghost`)
- Models individual ghosts with states: normal, frightened, eaten, frozen.
- Dispatches target calculation to its active strategy object.

### 7. `collectible.py` (`CollectibleManager`)
- Maintains constant-time set lookups for corridor pacgums and corner super-pacgums.
- Handles pellet consumption and level clear verification.

### 8. `score.py` (`Score`)
- Accumulates points strictly monotonically (scores never decrease).
- Tracks pacgums (+10), super-pacgums (+50), and devoured ghosts (+200).

### 9. `highscore.py` (`HighscoreManager`)
- Manages persistent JSON storage of top 10 scores.
- Enforces player name validation (alphanumeric and spaces, max 10 characters).

### 10. `level.py` (`Level`)
- Bundles a level's maze, entities, collectibles, and countdown timer.

### 11. `game_state.py` (`GameState`)
- Implements the **State Pattern** governing game phases:
  - `MENU`, `PLAYING`, `PAUSED`, `GAME_OVER`, `VICTORY`, `HIGHSCORES`, `INSTRUCTIONS`.
