"""Student performance analytics, error tracking, and diagnostic reporting."""

import csv
import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Any
from src.model.math_mission import MathTile


@dataclass
class StudentProfile:
    """Represents the student identity and classroom section."""

    name: str = "طالب متميز"
    section: str = "سابع أ"
    session_id: str = ""
    start_timestamp: str = ""

    def __post_init__(self) -> None:
        """Initialize session id and timestamp if empty."""
        if not self.session_id:
            now = time.strftime("%Y%m%d_%H%M%S")
            self.session_id = f"session_{now}"
            self.start_timestamp = time.strftime("%Y-%m-%d %H:%M:%S")


@dataclass
class TileResponseEvent:
    """Individual tile collection action with pedagogical diagnostics."""

    level_num: int
    tile_label: str
    is_target: bool
    points: int
    misconception: str
    time_spent: float
    timestamp: str = field(
        default_factory=lambda: time.strftime("%H:%M:%S")
    )


class AnalyticsTracker:
    """Tracks continuous student responses and exports diagnostic reports."""

    def __init__(self, reports_dir: str = "reports") -> None:
        """Initialize analytics tracker with destination storage directory."""
        self._reports_dir: str = reports_dir
        self._sessions_dir: str = os.path.join(reports_dir, "sessions")
        self._profile: StudentProfile = StudentProfile()
        self._events: list[TileResponseEvent] = []
        self._levels_cleared: int = 0
        self._final_score: int = 0
        self._ensure_directories()

    def _ensure_directories(self) -> None:
        """Create storage directories for reports if nonexistent."""
        os.makedirs(self._sessions_dir, exist_ok=True)

    def set_student(self, name: str, section: str = "سابع أ") -> None:
        """Update active student identity and classroom section."""
        clean_name = name.strip() or "طالب متميز"
        clean_sec = section.strip() or "سابع أ"
        self._profile = StudentProfile(name=clean_name, section=clean_sec)

    def get_student(self) -> StudentProfile:
        """Return shallow copy of active student profile."""
        return self._profile

    def get_student_name(self) -> str:
        """Return name of the active student."""
        return self._profile.name

    def record_tile_event(
        self, level_num: int, tile: MathTile, time_spent: float = 0.0
    ) -> None:
        """Record an eaten tile event and its pedagogical classification."""
        misc = getattr(tile, "misconception", "")
        evt = TileResponseEvent(
            level_num=level_num,
            tile_label=tile.label,
            is_target=tile.is_target,
            points=tile.points,
            misconception=misc,
            time_spent=round(time_spent, 2),
        )
        self._events.append(evt)

    def record_level_completion(self, level_num: int, score: int) -> None:
        """Record level progression and updated total score."""
        self._levels_cleared = max(self._levels_cleared, level_num)
        self._final_score = score

    def get_accuracy_rate(self) -> float:
        """Calculate percentage of target selections out of total eaten."""
        if not self._events:
            return 100.0
        correct = sum(1 for e in self._events if e.is_target)
        return round((correct / len(self._events)) * 100.0, 1)

    def get_identified_misconceptions(self) -> list[str]:
        """Return unique list of misconceptions encountered in session."""
        unique_misc: list[str] = []
        for e in self._events:
            if not e.is_target and e.misconception:
                if e.misconception not in unique_misc:
                    unique_misc.append(e.misconception)
        return unique_misc

    def get_remedial_recommendations(self) -> list[str]:
        """Generate targeted remedial action points based on errors."""
        miscs = self.get_identified_misconceptions()
        if not miscs:
            return ["ممتاز! أتقن الطالب كافة معايير الأعداد النسبية بنجاح."]
        return [f"خطة علاجية مقترحة: مراجعة {m}" for m in miscs]

    def get_session_summary(self) -> dict[str, Any]:
        """Compile comprehensive diagnostic performance metrics."""
        targets = sum(1 for e in self._events if e.is_target)
        traps = sum(1 for e in self._events if not e.is_target)
        return {
            "student_name": self._profile.name,
            "section": self._profile.section,
            "session_id": self._profile.session_id,
            "date": self._profile.start_timestamp,
            "final_score": self._final_score,
            "levels_cleared": self._levels_cleared,
            "total_tiles_eaten": len(self._events),
            "correct_targets": targets,
            "mistakes_traps": traps,
            "accuracy_percentage": self.get_accuracy_rate(),
            "misconceptions": self.get_identified_misconceptions(),
            "recommendations": self.get_remedial_recommendations(),
        }

    def _read_webhook_url(self) -> str:
        """Retrieve configured webhook URL from config or environment."""
        env_url = os.environ.get("QRAEE_WEBHOOK_URL", "").strip()
        if env_url:
            return env_url
        cfg_file = os.path.join(self._reports_dir, "webhook_config.json")
        if os.path.exists(cfg_file):
            try:
                with open(cfg_file, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                    return str(cfg.get("webhook_url", "")).strip()
            except Exception:
                return ""
        return ""

    def _post_payload(self, url: str, payload: dict[str, Any]) -> None:
        """Send JSON payload via HTTP POST without raising exceptions."""
        try:
            import requests  # type: ignore
            requests.post(url, json=payload, timeout=10)
        except Exception:
            try:
                import urllib.request
                data_bytes = json.dumps(
                    payload, ensure_ascii=False
                ).encode("utf-8")
                req = urllib.request.Request(
                    url,
                    data=data_bytes,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=10):
                    pass
            except Exception:
                pass

    def sync_to_cloud(self, summary: dict[str, Any]) -> None:
        """Dispatch session summary asynchronously to cloud webhook."""
        import sys
        if sys.platform == "emscripten":
            try:
                import platform
                if hasattr(platform, "window"):
                    win = platform.window
                    if hasattr(win, "sendStudentReport"):
                        p_str = json.dumps(summary, ensure_ascii=False)
                        win.sendStudentReport(p_str)
                        return
            except Exception:
                pass

        url = self._read_webhook_url()
        if not url:
            return
        import threading
        worker = threading.Thread(
            target=self._post_payload, args=(url, summary), daemon=True
        )
        worker.start()

    def save_session_report(self) -> str:
        """Serialize session data to JSON file in reports directory."""
        summary = self.get_session_summary()
        summary["events"] = [asdict(e) for e in self._events]
        safe_name = "".join(
            c for c in self._profile.name if c.isalnum() or c in (" ", "_")
        ).strip().replace(" ", "_")
        filename = f"{self._profile.session_id}_{safe_name}.json"
        target_path = os.path.join(self._sessions_dir, filename)
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        self.update_class_summary()
        self.sync_to_cloud(summary)
        return target_path

    def update_class_summary(self) -> str:
        """Append or update session summary row in class CSV file."""
        csv_path = os.path.join(self._reports_dir, "class_summary.csv")
        file_exists = os.path.isfile(csv_path)
        summary = self.get_session_summary()
        row = [
            summary["date"], summary["student_name"], summary["section"],
            summary["final_score"], summary["levels_cleared"],
            f"{summary['accuracy_percentage']}%",
            "; ".join(summary["misconceptions"]),
        ]
        headers = [
            "التاريخ والوقت", "اسم الطالب", "الشعبة", "النقاط",
            "المراحل المنجزة", "نسبة الدقة", "المفاهيم الخاطئة المرصودة",
        ]
        with open(csv_path, "a", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(headers)
            writer.writerow(row)
        return csv_path
