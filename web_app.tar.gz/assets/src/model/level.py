"""Level model coordinating maze, collectibles, player, and ghosts."""

from src.model.config import GameConfig
from src.model.maze import Maze
from src.model.player import Player
from src.model.ghost import Ghost
from src.model.ghost_behavior import (
    BlinkyBehavior,
    PinkyBehavior,
    InkyBehavior,
    ClydeBehavior,
)
from src.model.collectible import CollectibleManager
from src.model.math_mission import MathMission, get_curriculum_mission
from src.model.floating_text import FloatingText


class Level:
    """Encapsulates a single game level instance."""

    def __init__(
        self,
        level_number: int,
        config: GameConfig,
        shared_player: Player | None = None,
    ) -> None:
        """Initialize Level entities and layout."""
        self._level_number: int = level_number
        self._config: GameConfig = config
        lvl_cfg = config.get_level_config(level_number)
        self._width: int = lvl_cfg["width"]
        self._height: int = lvl_cfg["height"]
        self._seed: int = lvl_cfg["seed"]
        self._time_remaining: float = float(config.get_level_max_time())
        mission_data = config.get_level_mission_data(level_number)
        self._mission: MathMission = get_curriculum_mission(
            level_number, mission_data
        )
        self._intro_timer: float = config.get_intro_countdown()
        self._floating_texts: list[FloatingText] = []
        self._init_components(shared_player)

    def _init_components(self, shared_player: Player | None) -> None:
        """Initialize maze, collectibles, player, and ghosts."""
        self._maze: Maze = Maze(self._width, self._height, self._seed)
        self._collectibles: CollectibleManager = CollectibleManager()
        self._player: Player = self._init_player(shared_player)
        self._ghosts: list[Ghost] = self._init_ghosts()
        self._init_collectibles()

    def _init_player(self, shared: Player | None) -> Player:
        """Create or reposition player at center of maze."""
        cx, cy = self._maze.get_center()
        lives = shared.get_lives() if shared else self._config.get_lives()
        return Player(cx, cy, lives)

    def _init_ghosts(self) -> list[Ghost]:
        """Spawn the 4 ghosts in the 4 corners with distinct AI strategies."""
        corners = self._maze.get_corners()
        strategies = [
            ("blinky", BlinkyBehavior()),
            ("pinky", PinkyBehavior()),
            ("inky", InkyBehavior()),
            ("clyde", ClydeBehavior()),
        ]
        ghosts: list[Ghost] = []
        for i, (name, behavior) in enumerate(strategies):
            corner = corners[i % len(corners)]
            ghosts.append(Ghost(name, corner[0], corner[1], behavior, corner))
        return ghosts

    def _init_collectibles(self) -> None:
        """Populate corridor pacgums, super pacgums, and math tiles."""
        corners = self._maze.get_corners()
        dots_count = self._config.get_dots_count(self._level_number)
        self._collectibles.populate_from_maze(
            self._maze, corners, dots_count, self._mission
        )

    def get_mission(self) -> MathMission:
        """Return the curriculum mission for this level."""
        return self._mission

    def get_level_number(self) -> int:
        """Return the level index."""
        return self._level_number

    def get_maze(self) -> Maze:
        """Return the level's Maze instance."""
        return self._maze

    def get_player(self) -> Player:
        """Return the Player instance."""
        return self._player

    def get_ghosts(self) -> list[Ghost]:
        """Return list of Ghost instances."""
        return self._ghosts

    def get_collectibles(self) -> CollectibleManager:
        """Return the CollectibleManager instance."""
        return self._collectibles

    def get_time_remaining(self) -> float:
        """Return remaining seconds for the level."""
        return max(0.0, self._time_remaining)

    def update_time(self, delta_time: float) -> bool:
        """Deduct elapsed time and return False if expired."""
        self._time_remaining -= delta_time
        return self._time_remaining > 0.0

    def is_completed(self) -> bool:
        """Check if all collectibles eaten or math mission finished."""
        return self._collectibles.is_cleared() or self._mission.is_completed()

    def is_intro_active(self) -> bool:
        """Check if level start intro countdown is ongoing."""
        return self._intro_timer > 0.0

    def get_intro_timer(self) -> float:
        """Return remaining seconds of intro countdown."""
        return max(0.0, self._intro_timer)

    def update_intro(self, delta_time: float) -> None:
        """Decrement intro timer."""
        self._intro_timer = max(0.0, self._intro_timer - delta_time)

    def skip_intro(self) -> None:
        """Immediately conclude intro countdown."""
        self._intro_timer = 0.0

    def add_floating_text(
        self, text: str, grid_x: int, grid_y: int, color: tuple[int, int, int]
    ) -> None:
        """Add temporary floating score notification."""
        self._floating_texts.append(
            FloatingText(text, grid_x, grid_y, color)
        )

    def get_floating_texts(self) -> list[FloatingText]:
        """Return active floating notifications."""
        return list(self._floating_texts)

    def update_floating_texts(self, delta_time: float) -> None:
        """Advance floating texts and remove expired ones."""
        self._floating_texts = [
            ft for ft in self._floating_texts if ft.update(delta_time)
        ]
