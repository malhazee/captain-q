"""Ghost entity model with smooth sub-tile movement and state transitions."""

from src.model.direction import Direction
from src.model.ghost_behavior import GhostBehavior, FrightenedBehavior
from src.model.maze import Maze


class Ghost:
    """Represents an autonomous ghost navigating with smooth movement."""

    DEFAULT_FRIGHTENED_DURATION: float = 7.0
    DEFAULT_RESPAWN_DURATION: float = 6.0
    CHASE_DURATION: float = 20.0
    SCATTER_DURATION: float = 6.0
    BASE_SPEED: float = (60.0 / 28.0) * 0.85
    FRIGHTENED_SPEED: float = (60.0 / 28.0) * 0.50

    def __init__(
        self,
        name: str,
        start_x: int,
        start_y: int,
        behavior: GhostBehavior,
        corner: tuple[int, int],
    ) -> None:
        """Initialize Ghost with role, spawn position, and strategy."""
        self._name: str = name
        self._start_x: int = start_x
        self._start_y: int = start_y
        self._x: int = start_x
        self._y: int = start_y
        self._target_x: int = start_x
        self._target_y: int = start_y
        self._progress: float = 0.0
        self._corner: tuple[int, int] = corner
        self._direction: Direction = Direction.NONE
        self._normal_behavior: GhostBehavior = behavior
        self._frightened_behavior: GhostBehavior = FrightenedBehavior()
        self._init_state_flags()

    def _init_state_flags(self) -> None:
        """Initialize transient state flags and countdown timers."""
        self._is_frightened: bool = False
        self._frightened_timer: float = 0.0
        self._is_eaten: bool = False
        self._respawn_timer: float = 0.0
        self._is_frozen: bool = False
        self._wave_timer: float = 0.0
        self._is_scattering: bool = False

    def get_name(self) -> str:
        """Return the ghost's identifier name."""
        return self._name

    def get_position(self) -> tuple[int, int]:
        """Return closest integer grid coordinates (x, y)."""
        rx, ry = self.get_render_position()
        return (round(rx), round(ry))

    def get_render_position(self) -> tuple[float, float]:
        """Return exact sub-tile coordinates for smooth rendering."""
        if self._progress <= 0.0 or self._direction == Direction.NONE:
            return (float(self._x), float(self._y))
        dx, dy = self._direction.delta()
        return (
            self._x + dx * self._progress,
            self._y + dy * self._progress,
        )

    def set_position(self, x: int, y: int) -> None:
        """Set ghost coordinates and reset transition progress."""
        self._x = x
        self._y = y
        self._target_x = x
        self._target_y = y
        self._progress = 0.0

    def get_direction(self) -> Direction:
        """Return current direction."""
        return self._direction

    def set_direction(self, direction: Direction) -> None:
        """Set active movement direction."""
        self._direction = direction

    def is_frightened(self) -> bool:
        """Check if ghost is in vulnerable edible state."""
        return self._is_frightened and not self._is_eaten

    def set_frightened(
        self, duration: float = DEFAULT_FRIGHTENED_DURATION
    ) -> None:
        """Trigger frightened mode for specified duration."""
        if not self._is_eaten:
            self._is_frightened = True
            self._frightened_timer = max(1.0, duration)

    def is_eaten(self) -> bool:
        """Check if ghost has been eaten and is respawning."""
        return self._is_eaten

    def eat(self) -> None:
        """Mark ghost as eaten and initiate respawn timer."""
        self._is_eaten = True
        self._is_frightened = False
        self._frightened_timer = 0.0
        self._respawn_timer = self.DEFAULT_RESPAWN_DURATION

    def is_frozen(self) -> bool:
        """Check if ghost freeze cheat is active."""
        return self._is_frozen

    def set_frozen(self, status: bool) -> None:
        """Toggle freeze cheat mode."""
        self._is_frozen = status

    def is_scattering(self) -> bool:
        """Check if ghost is in periodic scatter wave mode."""
        return self._is_scattering and not self._is_frightened

    def respawn(self) -> None:
        """Respawn ghost back to its assigned corner."""
        self.set_position(self._start_x, self._start_y)
        self._direction = Direction.NONE
        self._is_eaten = False
        self._is_frightened = False
        self._frightened_timer = 0.0
        self._respawn_timer = 0.0
        self._wave_timer = 0.0
        self._is_scattering = False

    def update_timers(self, delta_time: float) -> None:
        """Update timers for wave modes, frightened state, and respawning."""
        self._update_wave_timer(delta_time)
        if self._is_frightened:
            self._frightened_timer -= delta_time
            if self._frightened_timer <= 0.0:
                self._is_frightened = False
        if self._is_eaten:
            self._respawn_timer -= delta_time
            if self._respawn_timer <= 0.0:
                self.respawn()

    def _update_wave_timer(self, delta_time: float) -> None:
        """Alternate between chase and scatter periods."""
        self._wave_timer += delta_time
        limit = (
            self.SCATTER_DURATION
            if self._is_scattering
            else self.CHASE_DURATION
        )
        if self._wave_timer >= limit:
            self._wave_timer = 0.0
            self._is_scattering = not self._is_scattering

    def update(
        self,
        player_pos: tuple[int, int],
        player_dir: Direction,
        maze: Maze,
        delta_time: float = 0.0,
    ) -> None:
        """Advance ghost AI navigation and step along computed path."""
        self.update_timers(delta_time)
        if not self._is_frozen and not self._is_eaten:
            self._step_ai(player_pos, player_dir, maze, delta_time)

    def _step_ai(
        self,
        player_pos: tuple[int, int],
        player_dir: Direction,
        maze: Maze,
        delta_time: float,
    ) -> None:
        """Advance smooth sub-tile movement or perform discrete step."""
        if delta_time <= 0.0:
            self._pick_next_direction(player_pos, player_dir, maze)
            self._x, self._y = self._target_x, self._target_y
            self._progress = 0.0
            return
        self._advance_progress(player_pos, player_dir, maze, delta_time)

    def _advance_progress(
        self,
        player_pos: tuple[int, int],
        player_dir: Direction,
        maze: Maze,
        delta_time: float,
    ) -> None:
        """Advance smooth transition between grid cells."""
        if self._direction == Direction.NONE:
            self._pick_next_direction(player_pos, player_dir, maze)
        if self._direction == Direction.NONE:
            return

        is_fright = self.is_frightened()
        speed = self.FRIGHTENED_SPEED if is_fright else self.BASE_SPEED
        self._progress += speed * delta_time
        if self._progress >= 1.0:
            self._x = self._target_x
            self._y = self._target_y
            self._progress = 0.0
            self._pick_next_direction(player_pos, player_dir, maze)

    def _pick_next_direction(
        self, player_pos: tuple[int, int], player_dir: Direction, maze: Maze
    ) -> None:
        """Select next corridor step based on active behavior strategy."""
        behavior = (
            self._frightened_behavior
            if self.is_frightened()
            else self._normal_behavior
        )
        target = (
            self._corner
            if self._is_scattering and not self.is_frightened()
            else behavior.calculate_target(
                (self._x, self._y), player_pos, player_dir, self._corner
            )
        )
        best_dir = behavior.select_best_direction(
            (self._x, self._y), target, self._direction, maze
        )
        self._apply_direction(best_dir)

    def _apply_direction(self, best_dir: Direction) -> None:
        """Apply selected direction and set target cell coordinates."""
        if best_dir != Direction.NONE:
            self._direction = best_dir
            dx, dy = best_dir.delta()
            self._target_x, self._target_y = self._x + dx, self._y + dy
        else:
            self._target_x, self._target_y = self._x, self._y
