"""Model package containing game state, entities, and business logic."""
