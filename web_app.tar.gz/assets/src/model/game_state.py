"""Game state model managing transitions, levels, and persistent score."""

from src.model.config import GameConfig
from src.model.score import Score
from src.model.highscore import HighscoreManager
from src.model.level import Level
from src.model.analytics_tracker import AnalyticsTracker


class GameState:
    """Manages the lifecycle and state transitions of the Pacman game."""

    STATE_MENU = "MENU"
    STATE_NAME_ENTRY = "NAME_ENTRY"
    STATE_PLAYING = "PLAYING"
    STATE_PAUSED = "PAUSED"
    STATE_GAME_OVER = "GAME_OVER"
    STATE_VICTORY = "VICTORY"
    STATE_HIGHSCORES = "HIGHSCORES"
    STATE_INSTRUCTIONS = "INSTRUCTIONS"
    MAX_LEVELS = 6
    SECTIONS = ["سابع أ", "سابع ب", "سابع ج"]

    def __init__(
        self,
        config: GameConfig | None = None,
        analytics: AnalyticsTracker | None = None,
    ) -> None:
        """Initialize GameState in the main menu."""
        self._config: GameConfig = config if config else GameConfig()
        self._score: Score = Score(0)
        self._highscore_mgr: HighscoreManager = HighscoreManager(
            self._config.get_highscore_filename()
        )
        self._state: str = self.STATE_MENU
        self._current_level_num: int = 1
        self._level: Level | None = None
        self._menu_index: int = 0
        self._pause_index: int = 0
        self._name_buffer: str = ""
        self._analytics: AnalyticsTracker = (
            analytics if analytics else AnalyticsTracker()
        )
        self._section_index: int = 0
        self._student_section: str = self.SECTIONS[0]

    def get_state(self) -> str:
        """Return the current active state identifier."""
        return self._state

    def set_state(self, new_state: str) -> None:
        """Set active game state."""
        self._state = new_state

    def get_config(self) -> GameConfig:
        """Return the GameConfig instance."""
        return self._config

    def get_score(self) -> Score:
        """Return the persistent Score instance."""
        return self._score

    def get_highscore_manager(self) -> HighscoreManager:
        """Return the HighscoreManager instance."""
        return self._highscore_mgr

    def get_level(self) -> Level | None:
        """Return the current active Level instance."""
        return self._level

    def get_level_number(self) -> int:
        """Return current level index (1-based)."""
        return self._current_level_num

    def get_menu_index(self) -> int:
        """Return currently selected main menu option index."""
        return self._menu_index

    def set_menu_index(self, index: int) -> None:
        """Set selected main menu option index."""
        self._menu_index = max(0, min(3, index))

    def get_pause_index(self) -> int:
        """Return currently selected pause menu option index."""
        return self._pause_index

    def set_pause_index(self, index: int) -> None:
        """Set selected pause menu option index."""
        self._pause_index = max(0, min(1, index))

    def get_name_buffer(self) -> str:
        """Return buffered player name string for highscore entry."""
        return self._name_buffer

    def set_name_buffer(self, name: str) -> None:
        """Set buffered player name string."""
        self._name_buffer = name[: HighscoreManager.MAX_NAME_LENGTH]

    def get_analytics_tracker(self) -> AnalyticsTracker:
        """Return diagnostic assessment tracker."""
        return self._analytics

    def get_student_section(self) -> str:
        """Return current student classroom section."""
        return self._student_section

    def set_student_section(self, section: str) -> None:
        """Set current student classroom section."""
        self._student_section = section

    def get_section_index(self) -> int:
        """Return index of the current classroom section."""
        return self._section_index

    def cycle_section(self, delta: int = 1) -> str:
        """Cycle classroom section forward or backward."""
        total = len(self.SECTIONS)
        self._section_index = (self._section_index + delta) % total
        self._student_section = self.SECTIONS[self._section_index]
        return self._student_section

    def start_new_game(self) -> None:
        """Reset score, configure student profile, and launch level 1."""
        self._score.reset()
        self._current_level_num = 1
        name = self._name_buffer.strip()
        sec = self._student_section
        try:
            import platform
            win = getattr(platform, "window", None)
            if win:
                js_name = getattr(win, "activeStudentName", "")
                js_sec = getattr(win, "activeStudentSection", "")
                if js_name and isinstance(js_name, str) and js_name.strip():
                    name = js_name.strip()
                if js_sec and isinstance(js_sec, str) and js_sec.strip():
                    sec = js_sec.strip()
                    self._student_section = sec
        except Exception:
            pass
        if not name:
            name = "طالب متميز"
        self._analytics.set_student(name, sec)
        self._level = Level(self._current_level_num, self._config)
        self._state = self.STATE_PLAYING
        self._name_buffer = ""

    def advance_level(self) -> bool:
        """Advance to next level or trigger victory after max level."""
        self._analytics.record_level_completion(
            self._current_level_num, self._score.get_score()
        )
        if self._current_level_num >= self.MAX_LEVELS:
            self.trigger_victory()
            return False
        self._current_level_num += 1
        prev_player = self._level.get_player() if self._level else None
        self._level = Level(
            self._current_level_num, self._config, prev_player
        )
        self._state = self.STATE_PLAYING
        return True

    def toggle_pause(self) -> None:
        """Toggle between PLAYING and PAUSED states."""
        if self._state == self.STATE_PLAYING:
            self._state = self.STATE_PAUSED
            self._pause_index = 0
        elif self._state == self.STATE_PAUSED:
            self._state = self.STATE_PLAYING

    def is_paused(self) -> bool:
        """Return True if currently in PAUSED state."""
        return self._state == self.STATE_PAUSED

    def _finalize_analytics(self) -> None:
        """Save diagnostic assessment logs and regenerate dashboard."""
        try:
            self._analytics.save_session_report()
            from src.utils.report_generator import ReportGenerator
            ReportGenerator().generate_html_dashboard()
        except Exception:
            pass

    def trigger_game_over(self) -> None:
        """Switch state to GAME_OVER and finalize logs."""
        self._state = self.STATE_GAME_OVER
        self._finalize_analytics()

    def trigger_victory(self) -> None:
        """Switch state to VICTORY and finalize logs."""
        self._state = self.STATE_VICTORY
        self._finalize_analytics()
