"""Math mission module for 7th-grade Rational Numbers curriculum."""

from typing import Any
from dataclasses import dataclass


@dataclass(frozen=True)
class MathTile:
    """Represents an individual mathematical item on the maze grid."""

    label: str
    is_target: bool
    points: int = 100
    misconception: str = ""


_DEFAULT_MISCONCEPTIONS: dict[str, str] = {
    "1/3": "الخلط بين كسر الثلث والنصف",
    "0.05": "خطأ القيمة المنزلية العشرية (0.05 بدلاً من 0.5)",
    "-0.5": "إهمال الإشارة السالبة (العدد سالب والنصف موجب)",
    "2/5": "كسر اعتيادي لا يكافئ النصف (قيمته 0.4)",
    "+0.5": "اختيار عدد موجب بدلاً من السالب",
    "3/4": "عدم التمييز بين الكسر الموجب والسالب",
    "0": "اعتبار الصفر عدداً سالباً (الصفر عدد محايد)",
    "1.2": "اختيار كسر عشري موجب أكبر من الصفر",
    "3/5": "الخلط في حساب النسبة المئوية (3/5 = 60% وليس 75%)",
    "0.34": "الخلط بين الكسر 3/4 والكسر العشري 0.34",
    "4/3": "اختيار مقلوب الكسر بدلاً من مكافئه",
    "7/10": "تقدير غير دقيق للنسبة 75% (7/10 = 70%)",
    "-2.5": "مقارنة العدد السالب مباشرة بدلاً من قيمته المطلقة",
    "5/2": "كسر غير فعلي قيمته 2.5 وقيمته المطلقة أكبر من 1",
    "-3": "نسيان أن القيمة المطلقة موجبة |-3| = 3 وهي أكبر من 1",
    "1.8": "العدد العشري 1.8 قيمته المطلقة أكبر من 1",
    "5/4": "الخلط بين الكسر الفعلي وغير الفعلي (5/4 أكبر من 1)",
    "1.5": "العدد العشري 1.5 أكبر من الواحد الصحيح",
    "-1/2": "العدد النسبي السالب يقع يسار الصفر وليس بين 0 و 1",
    "3/2": "كسر غير فعلي مقداره 1.5 وهو أكبر من 1",
    "1/0": "القسمة على صفر كمية غير معرّفة وليست عدداً نسبياً",
    "5/0": "مقام العدد النسبي لا يجوز أن يساوي صفراً",
    "0/0": "كمية غير معينة وليست عدداً نسبياً",
    "pi": "العدد باي (π) عدد غير نسبي",
}


class MathMission:
    """Defines curriculum questions and tile payloads for a level."""

    def __init__(
        self,
        level_num: int,
        title: str,
        prompt: str,
        targets: list[str],
        traps: list[str],
        needed_count: int = 4,
        trap_misconceptions: dict[str, str] | None = None,
    ) -> None:
        """Initialize mission details, answer banks, and misconceptions."""
        self._level_num: int = level_num
        self._title: str = title
        self._prompt: str = prompt
        self._targets: list[str] = targets
        self._traps: list[str] = traps
        self._needed_count: int = needed_count
        self._collected_count: int = 0
        self._misconceptions: dict[str, str] = dict(_DEFAULT_MISCONCEPTIONS)
        if trap_misconceptions:
            self._misconceptions.update(trap_misconceptions)

    def get_title(self) -> str:
        """Return the Arabic title of the level mission."""
        return self._title

    def get_prompt(self) -> str:
        """Return the instruction text displayed to the student."""
        return self._prompt

    def get_needed_count(self) -> int:
        """Return required target count to clear mission."""
        return self._needed_count

    def set_needed_count(self, count: int) -> None:
        """Set dynamic target count matching targets placed on board."""
        self._needed_count = max(1, count)

    def get_targets(self) -> list[str]:
        """Return target answers list."""
        return list(self._targets)

    def get_traps(self) -> list[str]:
        """Return trap distractors list."""
        return list(self._traps)

    def get_collected_count(self) -> int:
        """Return count of correct targets collected so far."""
        return self._collected_count

    def is_completed(self) -> bool:
        """Check if required targets have been collected."""
        return self._collected_count >= self._needed_count

    def get_misconception_for(self, label: str) -> str:
        """Return educational misconception explanation for a trap label."""
        return self._misconceptions.get(
            label, "مفهوم رياضي بحاجة لمراجعة وتدريب"
        )

    def record_collection(self, tile: MathTile) -> int:
        """Update mission state on eating a math tile and return points."""
        if tile.is_target:
            self._collected_count += 1
            return tile.points
        return -30

    def generate_tile_pool(self, total_needed: int) -> list[MathTile]:
        """Generate balanced pool alternating targets and distractors."""
        pool: list[MathTile] = []
        limit = max(len(self._targets), len(self._traps), 1)
        for i in range(limit):
            if i < len(self._targets):
                pool.append(MathTile(self._targets[i], True, 100))
            if i < len(self._traps):
                lbl = self._traps[i]
                misc = self.get_misconception_for(lbl)
                pool.append(MathTile(lbl, False, -30, misc))
        while len(pool) < total_needed:
            idx = len(pool) % max(1, len(self._targets))
            pool.append(MathTile(self._targets[idx], True, 100))
        return pool[:total_needed]


_CURRICULUM_DATA: dict[int, tuple[str, str, list[str], list[str], int]] = {
    1: (
        "بوابة الأعداد النسبية", "التقط مكافئات النصف 1/2 (0.5)",
        ["1/2", "2/4", "3/6", "5/10", "0.5"],
        ["1/3", "0.05", "-0.5", "2/5"], 4,
    ),
    2: (
        "وادي السوالب وخط الأعداد",
        "التقط الأعداد النسبية السالبة (أقل من صفر)",
        ["-1/2", "-0.75", "-3/4", "-1.5", "-2"],
        ["+0.5", "3/4", "0", "1.2"], 4,
    ),
    3: (
        "مملكة الكسور المتكافئة", "التقط مكافئات 3/4 والنسب المئوية (75%)",
        ["6/8", "9/12", "75%", "0.75", "15/20"],
        ["3/5", "0.34", "4/3", "7/10"], 4,
    ),
    4: (
        "حصن القيمة المطلقة", "التقط أعداداً قيمتها المطلقة |س| <= 1",
        ["|-1/2|", "-0.8", "-3/4", "0.25", "1"],
        ["-2.5", "5/2", "-3", "1.8"], 4,
    ),
    5: (
        "مملكة الكسور الفعلية", "التقط الكسور الفعلية التي تقع بين 0 و 1",
        ["1/4", "2/3", "4/5", "3/8", "0.6"],
        ["5/4", "1.5", "-1/2", "3/2"], 4,
    ),

    6: (
        "تحدي العباقرة الختامي", "التقط أعداداً نسبية (تجنب القسمة على 0)",
        ["3/4", "-0.6", "12/5", "50%", "|-2|"],
        ["1/0", "5/0", "0/0", "pi"], 4,
    ),
}


def get_curriculum_mission(
    level_num: int, custom_data: dict[str, Any] | None = None
) -> MathMission:
    """Factory creating math mission, using custom config if provided."""
    if custom_data:
        title = str(custom_data.get("title", f"المستوى {level_num}"))
        prompt = str(custom_data.get("prompt", "COLLECT TARGET TILES"))
        targets = list(custom_data.get("targets", ["1/2"]))
        traps = list(custom_data.get("traps", ["1/3"]))
        needed = int(custom_data.get("needed_count", len(targets)))
        miscs = custom_data.get("misconceptions")
        return MathMission(
            level_num, title, prompt, targets, traps, needed, miscs
        )
    idx = ((level_num - 1) % 6) + 1
    title, prompt, targets, traps, needed = _CURRICULUM_DATA[idx]
    return MathMission(idx, title, prompt, targets, traps, needed)
