"""Configuration management with validation, comments, and safe defaults."""

from typing import Any
from src.utils.json_parser import parse_json_with_comments


class GameConfig:
    """Manages game configuration parameters with fallback defaults."""

    DEFAULT_HIGHSCORE_FILE = "highscores.json"
    DEFAULT_LIVES = 3
    DEFAULT_PACGUM_POINTS = 10
    DEFAULT_SUPER_PACGUM_POINTS = 50
    DEFAULT_GHOST_POINTS = 200
    DEFAULT_MAX_TIME = 90
    DEFAULT_SEED = 42
    DEFAULT_WIDTH = 21
    DEFAULT_HEIGHT = 21
    MIN_WIDTH = 10
    MAX_WIDTH = 27
    MIN_HEIGHT = 10
    MAX_HEIGHT = 25

    def __init__(self, filepath: str = "config.json") -> None:
        """Initialize GameConfig and load values from the JSON file.

        Args:
            filepath: Path to the JSON configuration file.
        """
        self._filepath: str = filepath
        self._data: dict[str, Any] = {}
        self.load_config()

    def load_config(self) -> None:
        """Load configuration from JSON file or apply defaults."""
        loaded = parse_json_with_comments(self._filepath)
        self._data = loaded if isinstance(loaded, dict) else {}
        self._validate_and_sanitize()

    def _validate_and_sanitize(self) -> None:
        """Validate loaded keys and assign safe defaults for invalid values."""
        self._sanitize_lives()
        self._sanitize_points()
        self._sanitize_dots_count()
        self._sanitize_time_and_seed()
        self._sanitize_levels()

    def _sanitize_lives(self) -> None:
        """Ensure lives count is at least 1."""
        lives = self._data.get("lives")
        if not isinstance(lives, int) or lives <= 0:
            self._data["lives"] = self.DEFAULT_LIVES

    def _sanitize_points(self) -> None:
        """Ensure point awards are non-negative integers."""
        p_pac = self._data.get("points_per_pacgum")
        if not isinstance(p_pac, int) or p_pac < 0:
            self._data["points_per_pacgum"] = self.DEFAULT_PACGUM_POINTS

        p_super = self._data.get("points_per_super_pacgum")
        if not isinstance(p_super, int) or p_super < 0:
            self._data["points_per_super_pacgum"] = (
                self.DEFAULT_SUPER_PACGUM_POINTS
            )

        p_ghost = self._data.get("points_per_ghost")
        if not isinstance(p_ghost, int) or p_ghost < 0:
            self._data["points_per_ghost"] = self.DEFAULT_GHOST_POINTS

    def _sanitize_dots_count(self) -> None:
        """Ensure dots_count is a positive integer or None."""
        key = "dots_count" if "dots_count" in self._data else "dots"
        val = self._data.get(key)
        if val is not None and (not isinstance(val, int) or val <= 0):
            self._data["dots_count"] = None
        elif isinstance(val, int) and val > 0:
            self._data["dots_count"] = val

    def _sanitize_time_and_seed(self) -> None:
        """Ensure level max time and seed are valid."""
        time_limit = self._data.get("level_max_time")
        if not isinstance(time_limit, int) or time_limit <= 0:
            self._data["level_max_time"] = self.DEFAULT_MAX_TIME

        seed = self._data.get("seed")
        if not isinstance(seed, int):
            self._data["seed"] = self.DEFAULT_SEED

    def _sanitize_levels(self) -> None:
        """Ensure levels list is valid with minimum dimensions."""
        levels = self._data.get("levels")
        if not isinstance(levels, list) or len(levels) == 0:
            self._data["levels"] = [
                {
                    "width": self.DEFAULT_WIDTH,
                    "height": self.DEFAULT_HEIGHT,
                    "seed": self.get_seed(),
                }
            ]
            return
        for lvl in self._data["levels"]:
            self._sanitize_single_level(lvl)

    def _sanitize_single_level(self, lvl: dict[str, Any]) -> None:
        """Sanitize dimensions, seed, and dots of a single level."""
        w = lvl.get("width")
        if (
            not isinstance(w, int)
            or w < self.MIN_WIDTH
            or w > self.MAX_WIDTH
        ):
            lvl["width"] = self.DEFAULT_WIDTH
        h = lvl.get("height")
        if (
            not isinstance(h, int)
            or h < self.MIN_HEIGHT
            or h > self.MAX_HEIGHT
        ):
            lvl["height"] = self.DEFAULT_HEIGHT
        if not isinstance(lvl.get("seed"), int):
            lvl["seed"] = self.get_seed()
        key = "dots_count" if "dots_count" in lvl else "dots"
        if key in lvl and (not isinstance(lvl[key], int) or lvl[key] <= 0):
            lvl["dots_count"] = None

    def get_value(self, key: str, default: Any = None) -> Any:
        """Retrieve a raw config value by key with a fallback default.

        Args:
            key: Config dictionary key.
            default: Fallback value if key is not found.

        Returns:
            The associated configuration value or the fallback default.
        """
        return self._data.get(key, default)

    def get_lives(self) -> int:
        """Return the starting number of lives."""
        return int(self._data.get("lives", self.DEFAULT_LIVES))

    def get_points_per_pacgum(self) -> int:
        """Return points awarded for a regular pacgum."""
        return int(
            self._data.get("points_per_pacgum", self.DEFAULT_PACGUM_POINTS)
        )

    def get_points_per_super_pacgum(self) -> int:
        """Return points awarded for a super pacgum."""
        return int(
            self._data.get(
                "points_per_super_pacgum", self.DEFAULT_SUPER_PACGUM_POINTS
            )
        )

    def get_points_per_ghost(self) -> int:
        """Return points awarded for eating a frightened ghost."""
        return int(
            self._data.get("points_per_ghost", self.DEFAULT_GHOST_POINTS)
        )

    def get_level_max_time(self) -> int:
        """Return maximum time allowed per level in seconds."""
        return int(self._data.get("level_max_time", self.DEFAULT_MAX_TIME))

    def get_seed(self) -> int:
        """Return random generation seed."""
        return int(self._data.get("seed", self.DEFAULT_SEED))

    def get_highscore_filename(self) -> str:
        """Return highscore JSON filename."""
        name = self._data.get("highscore_filename")
        if isinstance(name, str) and name.strip():
            return name.strip()
        return self.DEFAULT_HIGHSCORE_FILE

    def get_level_config(self, level_number: int) -> dict[str, Any]:
        """Return configuration for a given 1-based level index.

        Args:
            level_number: 1-based index of the level.

        Returns:
            Dictionary with width, height, and seed for the level.
        """
        levels: list[dict[str, Any]] = self._data.get("levels", [])
        if not levels:
            return {
                "width": self.DEFAULT_WIDTH,
                "height": self.DEFAULT_HEIGHT,
                "seed": self.get_seed() + level_number - 1,
            }
        base_idx = (level_number - 1) % len(levels)
        lvl = dict(levels[base_idx])
        # Level 1 keeps its seed. Subsequent levels increment seed
        # to ensure variation across levels.
        if level_number > 1 and lvl.get("seed") == self.get_seed():
            lvl["seed"] = self.get_seed() + level_number - 1
        return lvl

    def get_dots_count(self, level_number: int = 1) -> int | None:
        """Return target dots count for a level or global setting."""
        lvl = self.get_level_config(level_number)
        key = "dots_count" if "dots_count" in lvl else "dots"
        if key in lvl and isinstance(lvl[key], int) and lvl[key] > 0:
            return int(lvl[key])
        g_key = "dots_count" if "dots_count" in self._data else "dots"
        val = self._data.get(g_key)
        if isinstance(val, int) and val > 0:
            return val
        return None

    def get_intro_countdown(self) -> float:
        """Return countdown seconds before level gameplay starts."""
        val = self._data.get("intro_countdown_seconds")
        if isinstance(val, (int, float)) and val >= 0:
            return float(val)
        return 10.0

    def get_level_mission_data(
        self, level_number: int = 1
    ) -> dict[str, Any] | None:
        """Return custom math mission config for a level if defined."""
        lvl = self.get_level_config(level_number)
        mission = lvl.get("mission")
        if isinstance(mission, dict):
            return dict(mission)
        return None

    def get_max_levels(self) -> int:
        """Return total number of configured levels."""
        levels = self._data.get("levels")
        if isinstance(levels, list) and len(levels) > 0:
            return len(levels)
        return 6
