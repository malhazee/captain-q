"""Maze model integrating the external mazegenerator package."""

from typing import Any
from mazegenerator import MazeGenerator  # type: ignore
from src.model.direction import Direction


class Maze:
    """Encapsulates a grid-based maze generated with A-Maze-ing."""

    WALL_BLOCK_VALUE = 15

    def __init__(
        self, width: int = 21, height: int = 21, seed: int = 42
    ) -> None:
        """Initialize and generate the maze grid.

        Args:
            width: Grid width (at least 10).
            height: Grid height (at least 10).
            seed: Pseudo-random generator seed.
        """
        self._width: int = max(10, width)
        self._height: int = max(10, height)
        self._seed: int = seed
        self._sanctuary_rect = self._init_sanctuary_rect()
        self._grid: list[list[int]] = []
        self._generator: Any = None
        self.generate()

    def _init_sanctuary_rect(self) -> tuple[int, int, int, int]:
        """Define central sanctuary room boundaries."""
        cx, cy = self._width // 2, self._height // 2
        return (cx - 1, cx + 1, cy - 1, cy + 1)

    def generate(self) -> None:
        """Generate a new playable (braided) maze without dead ends."""
        try:
            self._generator = MazeGenerator(
                size=(self._width, self._height),
                perfect=False,
                entry_cell=(0, 0),
                exit_cell=(self._width - 1, self._height - 1),
                seed=self._seed,
            )
            self._grid = self._generator.maze
            self._carve_sanctuary()
        except Exception as gen_err:
            print(f"Warning: Maze generation failed ({gen_err}). Using empty.")
            self._grid = [
                [0 for _ in range(self._width)] for _ in range(self._height)
            ]

    def get_width(self) -> int:
        """Return the grid width."""
        return self._width

    def get_height(self) -> int:
        """Return the grid height."""
        return self._height

    def get_grid(self) -> list[list[int]]:
        """Return the internal 2D grid matrix."""
        return self._grid

    def is_in_bounds(self, x: int, y: int) -> bool:
        """Check if grid coordinates lie within maze dimensions."""
        return 0 <= x < self._width and 0 <= y < self._height

    def get_cell(self, x: int, y: int) -> int:
        """Return the wall encoding bitmask at (x, y)."""
        if not self.is_in_bounds(x, y):
            return self.WALL_BLOCK_VALUE
        return self._grid[y][x]

    def is_wall_block(self, x: int, y: int) -> bool:
        """Check if cell is a solid obstacle block (e.g. 42 pattern)."""
        return self.get_cell(x, y) == self.WALL_BLOCK_VALUE

    def is_corridor(self, x: int, y: int) -> bool:
        """Check if a cell is an open traversable corridor."""
        return self.is_in_bounds(x, y) and not self.is_wall_block(x, y)

    def can_move(self, x: int, y: int, direction: Direction) -> bool:
        """Check whether movement in a direction is unobstructed by a wall.

        Args:
            x: Starting column index.
            y: Starting row index.
            direction: Candidate movement direction.

        Returns:
            True if path is open, False otherwise.
        """
        if not self.is_in_bounds(x, y) or direction == Direction.NONE:
            return False
        if self.is_wall_block(x, y):
            return False
        if (self.get_cell(x, y) & direction.value) != 0:
            return False
        dx, dy = direction.delta()
        nx, ny = x + dx, y + dy
        return self.is_in_bounds(nx, ny) and not self.is_wall_block(nx, ny)

    def get_center(self) -> tuple[int, int]:
        """Return the grid center coordinates, ensuring it's a corridor."""
        cx = self._width // 2
        cy = self._height // 2
        if self.is_corridor(cx, cy):
            return (cx, cy)
        return self._find_nearest_corridor(cx, cy)

    def _find_nearest_corridor(
        self, start_x: int, start_y: int
    ) -> tuple[int, int]:
        """Find the closest open corridor to a target coordinate."""
        for radius in range(1, max(self._width, self._height)):
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    cand_x, cand_y = start_x + dx, start_y + dy
                    if self.is_corridor(cand_x, cand_y):
                        return (cand_x, cand_y)
        return (0, 0)

    def get_corners(self) -> list[tuple[int, int]]:
        """Return the 4 corner coordinates adjusted to valid corridors."""
        raw_corners = [
            (0, 0),
            (self._width - 1, 0),
            (0, self._height - 1),
            (self._width - 1, self._height - 1),
        ]
        return [
            pos if self.is_corridor(*pos)
            else self._find_nearest_corridor(*pos)
            for pos in raw_corners
        ]

    def get_corridors(self) -> list[tuple[int, int]]:
        """Return all open corridor coordinates in the maze."""
        coords: list[tuple[int, int]] = []
        for y in range(self._height):
            for x in range(self._width):
                if self.is_corridor(x, y):
                    coords.append((x, y))
        return coords

    def _carve_sanctuary(self) -> None:
        """Carve open central sanctuary room with 4 perimeter doorways."""
        x1, x2, y1, y2 = self._sanctuary_rect
        cx, cy = self._width // 2, self._height // 2
        for y in range(y1, y2 + 1):
            for x in range(x1, x2 + 1):
                mask = 0
                if y == y1 and x != cx:
                    mask |= Direction.NORTH.value
                if y == y2 and x != cx:
                    mask |= Direction.SOUTH.value
                if x == x1 and y != cy:
                    mask |= Direction.WEST.value
                if x == x2 and y != cy:
                    mask |= Direction.EAST.value
                self._grid[y][x] = mask
        self._connect_doorways(x1, x2, y1, y2, cx, cy)

    def _connect_doorways(
        self, x1: int, x2: int, y1: int, y2: int, cx: int, cy: int
    ) -> None:
        """Ensure external cells facing doors have matching openings."""
        if y1 > 0:
            self._grid[y1 - 1][cx] &= ~Direction.SOUTH.value
        if y2 < self._height - 1:
            self._grid[y2 + 1][cx] &= ~Direction.NORTH.value
        if x1 > 0:
            self._grid[cy][x1 - 1] &= ~Direction.EAST.value
        if x2 < self._width - 1:
            self._grid[cy][x2 + 1] &= ~Direction.WEST.value

    def is_sanctuary(self, x: int, y: int) -> bool:
        """Check if coordinates fall inside the safe sanctuary."""
        x1, x2, y1, y2 = self._sanctuary_rect
        return x1 <= x <= x2 and y1 <= y <= y2

    def get_sanctuary_rect(self) -> tuple[int, int, int, int]:
        """Return (min_x, max_x, min_y, max_y) bounding box of sanctuary."""
        return self._sanctuary_rect

    def can_ghost_move(self, x: int, y: int, direction: Direction) -> bool:
        """Check movement validity for ghosts, strictly barring sanctuary."""
        if not self.can_move(x, y, direction):
            return False
        dx, dy = direction.delta()
        nx, ny = x + dx, y + dy
        return not self.is_sanctuary(nx, ny)
