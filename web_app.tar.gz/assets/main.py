"""Main entry point for Captain Q (Pac-Man Math) with WebAssembly support."""

import asyncio
import os
import sys
import pygame
from src.model.config import GameConfig
from src.model.game_state import GameState
from src.view.renderer import Renderer
from src.controller.game_controller import GameController
from src.controller.event_loop import EventLoop


def _resolve_base_path(rel_path: str) -> str:
    """Resolve file path relative to script directory."""
    base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel_path)


def initialize_web_display(config: GameConfig) -> pygame.Surface | None:
    """Initialize Pygame display surface for desktop or web canvas."""
    try:
        os.environ["SDL_RENDER_SCALE_QUALITY"] = "linear"
        os.environ["SDL_VIDEO_CENTERED"] = "1"
        pygame.init()
        win_w, win_h = (960, 960)
        flags = pygame.SCALED
        try:
            screen = pygame.display.set_mode((win_w, win_h), flags, vsync=1)
        except Exception:
            screen = pygame.display.set_mode((win_w, win_h), flags)
        pygame.display.set_caption("Captain Q - Rational Numbers Adventure")
        return screen
    except Exception as err:
        print(f"Error initializing display: {err}")
        return None


async def main() -> None:
    """Asynchronous main loop compatible with Pygbag and WebAssembly."""
    cfg_path = _resolve_base_path("config.json")
    config = GameConfig(cfg_path)
    screen = initialize_web_display(config)
    if not screen:
        return

    assets = _resolve_base_path("pacman-assets")
    state = GameState(config)
    renderer = Renderer(screen, assets_root=assets)
    controller = GameController(state, renderer)
    event_loop = EventLoop(state, renderer, controller)

    try:
        await event_loop.start_async()
    finally:
        try:
            renderer.cleanup()
            pygame.quit()
        except Exception:
            pass


if __name__ == "__main__":
    asyncio.run(main())
